<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$productModel  = new Product();
$categoryModel = new Category();
$categories    = $categoryModel->getAll(false);

$productId = (int) ($_GET['id'] ?? 0);
$isEdit    = $productId > 0;
$product   = $isEdit ? $productModel->findById($productId) : null;
$errors    = [];

if ($isEdit && !$product) {
    setFlash('error', 'Product not found.');
    redirect('admin/products.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token.';
    } else {
        $data = [
            'category_id'        => (int) $_POST['category_id'],
            'name'               => $_POST['name'] ?? '',
            'sku'                => $_POST['sku'] ?? '',
            'description'        => $_POST['description'] ?? '',
            'short_desc'         => $_POST['short_desc'] ?? '',
            'price'              => (float) ($_POST['price'] ?? 0),
            'sale_price'         => !empty($_POST['sale_price']) ? (float) $_POST['sale_price'] : null,
            'cost_price'         => !empty($_POST['cost_price']) ? (float) $_POST['cost_price'] : null,
            'stock_count'        => (int) ($_POST['stock_count'] ?? 0),
            'low_stock_threshold'=> (int) ($_POST['low_stock_threshold'] ?? 5),
            'weight'             => !empty($_POST['weight']) ? (float) $_POST['weight'] : null,
            'origin_country'     => $_POST['origin_country'] ?? '',
            'hs_code'            => $_POST['hs_code'] ?? '',
            'is_featured'        => isset($_POST['is_featured']) ? 1 : 0,
            'is_active'          => isset($_POST['is_active']) ? 1 : 0,
        ];

        // Handle image upload
        if (!empty($_FILES['image']['name'])) {
            $imgPath = uploadImage($_FILES['image'], PRODUCT_IMG_PATH, 'prod_');
            if ($imgPath) {
                $data['image'] = $imgPath;
                // Delete old image if editing
                if ($isEdit && $product['image']) {
                    deleteFile($product['image']);
                }
            }
        }

        // Validation
        if (empty($data['name'])) $errors[] = 'Product name is required.';
        if (empty($data['sku'])) $errors[] = 'SKU is required.';
        if ($data['price'] <= 0) $errors[] = 'Price must be greater than 0.';
        if (empty($data['category_id'])) $errors[] = 'Category is required.';

        if (empty($errors)) {
            try {
                if ($isEdit) {
                    $productModel->update($productId, $data);
                    setFlash('success', 'Product updated successfully!');
                } else {
                    $productModel->create($data);
                    setFlash('success', 'Product created successfully!');
                }
                redirect('admin/products.php');
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
}

$pageTitle = $isEdit ? 'Edit Product' : 'Add Product';
include INCLUDES_PATH . 'admin-header.php';
?>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger"><?php foreach ($errors as $e): echo sanitize($e) . '<br>'; endforeach; ?></div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="bi bi-<?= $isEdit ? 'pencil' : 'plus-circle' ?> me-2"></i><?= $pageTitle ?></h5>
    <a href="<?= url('admin/products.php') ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" enctype="multipart/form-data">
    <?= csrfField() ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Basic Information</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label small fw-bold">Product Name *</label>
                            <input type="text" class="form-control" name="name" value="<?= sanitize($product['name'] ?? $_POST['name'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">SKU *</label>
                            <input type="text" class="form-control" name="sku" value="<?= sanitize($product['sku'] ?? $_POST['sku'] ?? '') ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Short Description</label>
                            <input type="text" class="form-control" name="short_desc" maxlength="500" value="<?= sanitize($product['short_desc'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Full Description</label>
                            <textarea class="form-control" name="description" rows="5"><?= sanitize($product['description'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Pricing & Inventory</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Price (<?= CURRENCY_SYMBOL ?>) *</label>
                            <input type="number" class="form-control" name="price" step="0.01" min="0" value="<?= $product['price'] ?? '' ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Sale Price</label>
                            <input type="number" class="form-control" name="sale_price" step="0.01" min="0" value="<?= $product['sale_price'] ?? '' ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Cost Price</label>
                            <input type="number" class="form-control" name="cost_price" step="0.01" min="0" value="<?= $product['cost_price'] ?? '' ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Stock Count *</label>
                            <input type="number" class="form-control" name="stock_count" min="0" value="<?= $product['stock_count'] ?? 0 ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Low Stock Alert</label>
                            <input type="number" class="form-control" name="low_stock_threshold" min="0" value="<?= $product['low_stock_threshold'] ?? 5 ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Weight (kg)</label>
                            <input type="number" class="form-control" name="weight" step="0.01" min="0" value="<?= $product['weight'] ?? '' ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Origin Country</label>
                            <input type="text" class="form-control" name="origin_country" value="<?= sanitize($product['origin_country'] ?? '') ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">HS Code</label>
                            <input type="text" class="form-control" name="hs_code" value="<?= sanitize($product['hs_code'] ?? '') ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Category & Status</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Category *</label>
                        <select class="form-select" name="category_id" required>
                            <option value="">Select category</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= ($product['category_id'] ?? '') == $c['id'] ? 'selected' : '' ?>>
                                    <?= sanitize($c['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="is_active" id="isActive" <?= ($product['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label small" for="isActive">Active (visible in shop)</label>
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="is_featured" id="isFeatured" <?= ($product['is_featured'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label small" for="isFeatured">Featured product</label>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Product Image</div>
                <div class="card-body">
                    <?php if ($isEdit && $product['image']): ?>
                        <img src="<?= productImageUrl($product['image']) ?>" class="img-fluid rounded mb-3" style="max-height:200px;">
                    <?php endif; ?>
                    <input type="file" class="form-control form-control-sm" name="image" accept="image/*">
                    <small class="text-muted">JPG, PNG, WebP. Max 5MB.</small>
                </div>
            </div>

            <button type="submit" class="btn btn-success w-100 fw-bold py-2" style="background:#2d6a4f;border-color:#2d6a4f;">
                <i class="bi bi-check-lg me-1"></i><?= $isEdit ? 'Update Product' : 'Create Product' ?>
            </button>
        </div>
    </div>
</form>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>