<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$categoryModel = new Category();
$errors = [];

// Handle Create/Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (validateCsrfToken()) {
        $action = $_POST['action'] ?? '';
        $data = [
            'name'        => $_POST['name'] ?? '',
            'description' => $_POST['description'] ?? '',
            'sort_order'  => (int) ($_POST['sort_order'] ?? 0),
            'is_active'   => isset($_POST['is_active']) ? 1 : 0,
            'parent_id'   => !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null,
        ];

        if (!empty($_FILES['image']['name'])) {
            $data['image'] = uploadImage($_FILES['image'], 'uploads/categories/', 'cat_');
        }

        try {
            if ($action === 'create') {
                $categoryModel->create($data);
                setFlash('success', 'Category created!');
            } elseif ($action === 'update' && !empty($_POST['id'])) {
                $categoryModel->update((int) $_POST['id'], $data);
                setFlash('success', 'Category updated!');
            }
        } catch (RuntimeException $e) {
            setFlash('error', $e->getMessage());
        }
        redirect('admin/categories.php');
    }
}

// Handle Delete
if (isset($_GET['delete'])) {
    try {
        $categoryModel->delete((int) $_GET['delete']);
        setFlash('success', 'Category deleted!');
    } catch (RuntimeException $e) {
        setFlash('error', $e->getMessage());
    }
    redirect('admin/categories.php');
}

$categories = $categoryModel->getAll(false);
$editCat = isset($_GET['edit']) ? $categoryModel->findById((int) $_GET['edit']) : null;

$pageTitle = 'Categories';
include INCLUDES_PATH . 'admin-header.php';
?>

<div class="row g-4">
    <!-- Form -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold">
                <i class="bi bi-<?= $editCat ? 'pencil' : 'plus-circle' ?> me-2"></i>
                <?= $editCat ? 'Edit Category' : 'Add Category' ?>
            </div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="<?= $editCat ? 'update' : 'create' ?>">
                    <?php if ($editCat): ?>
                        <input type="hidden" name="id" value="<?= $editCat['id'] ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Name *</label>
                        <input type="text" class="form-control" name="name" value="<?= sanitize($editCat['name'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Description</label>
                        <textarea class="form-control" name="description" rows="3"><?= sanitize($editCat['description'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Sort Order</label>
                        <input type="number" class="form-control" name="sort_order" value="<?= $editCat['sort_order'] ?? 0 ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Image</label>
                        <input type="file" class="form-control form-control-sm" name="image" accept="image/*">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="is_active" <?= ($editCat['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label small">Active</label>
                    </div>
                    <button class="btn btn-success w-100" style="background:#2d6a4f;border-color:#2d6a4f;">
                        <i class="bi bi-check-lg me-1"></i><?= $editCat ? 'Update' : 'Create' ?>
                    </button>
                    <?php if ($editCat): ?>
                        <a href="<?= url('admin/categories.php') ?>" class="btn btn-outline-secondary w-100 mt-2">Cancel</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <!-- List -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold"><i class="bi bi-grid me-2"></i>Categories (<?= count($categories) ?>)</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small align-middle">
                    <thead class="bg-light"><tr><th>Name</th><th>Products</th><th>Order</th><th>Status</th><th class="text-center">Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($categories as $c): ?>
                            <tr>
                                <td class="fw-bold"><?= sanitize($c['name']) ?></td>
                                <td><span class="badge bg-light text-dark"><?= $c['product_count'] ?></span></td>
                                <td><?= $c['sort_order'] ?></td>
                                <td><?= $c['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?></td>
                                <td class="text-center">
                                    <a href="?edit=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                                    <a href="?delete=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this category?');"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>