<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$settingsModel = new SiteSettings();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCsrfToken()) {
    foreach ($_POST['settings'] ?? [] as $key => $value) {
        $settingsModel->set($key, $value);
    }
    setFlash('success', 'Settings saved successfully!');
    redirect('admin/settings.php');
}

$settings = $settingsModel->getAll();
$grouped = [];
foreach ($settings as $s) {
    $grouped[$s['setting_group']][] = $s;
}

$pageTitle = 'Settings';
include INCLUDES_PATH . 'admin-header.php';
?>

<h5 class="fw-bold mb-4"><i class="bi bi-gear me-2"></i>Site Settings</h5>

<form method="POST">
    <?= csrfField() ?>

    <?php foreach ($grouped as $group => $fields): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-bold"><i class="bi bi-sliders me-2"></i><?= ucfirst($group) ?> Settings</div>
            <div class="card-body">
                <div class="row g-3">
                    <?php foreach ($fields as $field): ?>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold"><?= sanitize($field['description'] ?? $field['setting_key']) ?></label>
                            <?php if ($field['setting_type'] === 'boolean'): ?>
                                <select class="form-select form-select-sm" name="settings[<?= $field['setting_key'] ?>]">
                                    <option value="1" <?= $field['setting_value'] ? 'selected' : '' ?>>Enabled</option>
                                    <option value="0" <?= !$field['setting_value'] ? 'selected' : '' ?>>Disabled</option>
                                </select>
                            <?php else: ?>
                                <input type="text" class="form-control form-control-sm" name="settings[<?= $field['setting_key'] ?>]"
                                       value="<?= sanitize($field['setting_value'] ?? '') ?>">
                            <?php endif; ?>
                            <small class="text-muted"><?= sanitize($field['setting_key']) ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>

    <button class="btn btn-success px-5 fw-bold" style="background:#2d6a4f;border-color:#2d6a4f;">
        <i class="bi bi-check-lg me-1"></i>Save All Settings
    </button>
</form>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>