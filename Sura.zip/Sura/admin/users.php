<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$userModel = new User();

if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $userModel->toggleActive((int) $_GET['toggle']);
    setFlash('success', 'User status updated.');
    redirect('admin/users.php');
}

$filters = ['search' => $_GET['search'] ?? '', 'role' => $_GET['role'] ?? ''];
$page = max(1, (int) ($_GET['page'] ?? 1));
$result = $userModel->getAllUsers($page, USERS_PER_PAGE, $filters);

$pageTitle = 'Users';
include INCLUDES_PATH . 'admin-header.php';
?>

<h5 class="fw-bold mb-4"><i class="bi bi-people me-2"></i>Users (<?= $result['pagination']['total_items'] ?>)</h5>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-4"><input type="text" class="form-control form-control-sm" name="search" placeholder="Search name, email, phone..." value="<?= sanitize($filters['search']) ?>"></div>
            <div class="col-md-2">
                <select class="form-select form-select-sm" name="role">
                    <option value="">All Roles</option>
                    <option value="customer" <?= $filters['role'] === 'customer' ? 'selected' : '' ?>>Customer</option>
                    <option value="admin" <?= $filters['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                </select>
            </div>
            <div class="col-md-2"><button class="btn btn-primary btn-sm w-100"><i class="bi bi-search me-1"></i>Search</button></div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="bg-light"><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Joined</th><th>Last Login</th><th class="text-center">Action</th></tr></thead>
            <tbody>
                <?php foreach ($result['users'] as $u): ?>
                    <tr>
                        <td class="fw-bold"><?= sanitize($u['first_name'] . ' ' . $u['last_name']) ?></td>
                        <td><?= sanitize($u['email']) ?></td>
                        <td><?= sanitize($u['phone'] ?? 'N/A') ?></td>
                        <td><span class="badge <?= $u['role'] === 'admin' ? 'bg-dark' : 'bg-info text-dark' ?>"><?= ucfirst($u['role']) ?></span></td>
                        <td><?= $u['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Banned</span>' ?></td>
                        <td><?= formatDate($u['created_at']) ?></td>
                        <td><?= $u['last_login'] ? formatDate($u['last_login'], 'M d, H:i') : 'Never' ?></td>
                        <td class="text-center">
                            <a href="?toggle=<?= $u['id'] ?>" class="btn btn-sm <?= $u['is_active'] ? 'btn-outline-danger' : 'btn-outline-success' ?>"
                               onclick="return confirm('<?= $u['is_active'] ? 'Ban' : 'Activate' ?> this user?');">
                                <i class="bi bi-<?= $u['is_active'] ? 'slash-circle' : 'check-circle' ?>"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-4"><?= renderPagination($result['pagination'], 'admin/users.php', array_filter($filters)) ?></div>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>