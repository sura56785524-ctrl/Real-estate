<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$orderModel = new Order();
$report = new Report();

$dateFrom = $_GET['date_from'] ?? date('Y-m-01');
$dateTo   = $_GET['date_to'] ?? date('Y-m-d');

// Handle Export
if (isset($_GET['export'])) {
    $exportType = $_GET['export'];
    $data = $report->getSalesReport($dateFrom, $dateTo);

    if ($exportType === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="sales_report_' . date('Ymd') . '.csv"');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Order #', 'Customer', 'Date', 'Status', 'Payment', 'Total (ETB)']);
        foreach ($data as $row) {
            fputcsv($output, [
                $row['order_number'],
                $row['customer_name'],
                $row['created_at'],
                $row['status'],
                $row['payment_status'],
                $row['total_amount'],
            ]);
        }
        fclose($output);
        exit;
    }
}

$stats = $orderModel->getStats();
$monthlySales = $orderModel->getMonthlySales();
$topProducts = $orderModel->getTopProducts(10);

$pageTitle = 'Reports';
include INCLUDES_PATH . 'admin-header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="bi bi-graph-up me-2"></i>Sales Reports</h5>
    <div class="d-flex gap-2">
        <a href="?date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>&export=csv" class="btn btn-outline-success btn-sm">
            <i class="bi bi-filetype-csv me-1"></i>Export CSV
        </a>
    </div>
</div>

<!-- Date Filter -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-3"><label class="form-label small fw-bold">From</label><input type="date" class="form-control form-control-sm" name="date_from" value="<?= $dateFrom ?>"></div>
            <div class="col-md-3"><label class="form-label small fw-bold">To</label><input type="date" class="form-control form-control-sm" name="date_to" value="<?= $dateTo ?>"></div>
            <div class="col-md-2"><button class="btn btn-primary btn-sm w-100 mt-4"><i class="bi bi-search me-1"></i>Generate</button></div>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card border-0 shadow-sm text-center py-3"><h5 class="fw-bold text-success mb-0"><?= formatPrice($stats['total_revenue']) ?></h5><small class="text-muted">Total Revenue</small></div></div>
    <div class="col-md-3"><div class="card border-0 shadow-sm text-center py-3"><h5 class="fw-bold text-primary mb-0"><?= $stats['total_orders'] ?></h5><small class="text-muted">Total Orders</small></div></div>
    <div class="col-md-3"><div class="card border-0 shadow-sm text-center py-3"><h5 class="fw-bold text-info mb-0"><?= formatPrice($stats['month_revenue']) ?></h5><small class="text-muted">This Month Revenue</small></div></div>
    <div class="col-md-3"><div class="card border-0 shadow-sm text-center py-3"><h5 class="fw-bold text-warning mb-0"><?= $stats['month_orders'] ?></h5><small class="text-muted">This Month Orders</small></div></div>
</div>

<div class="row g-4">
    <!-- Monthly Chart Data -->
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold"><i class="bi bi-bar-chart me-2"></i>Monthly Sales (Last 12 Months)</div>
            <div class="card-body">
                <table class="table table-sm small">
                    <thead><tr><th>Month</th><th>Orders</th><th>Revenue</th></tr></thead>
                    <tbody>
                        <?php foreach ($monthlySales as $ms): ?>
                            <tr>
                                <td><?= $ms['month'] ?></td>
                                <td><?= $ms['order_count'] ?></td>
                                <td class="fw-bold text-success"><?= formatPrice($ms['revenue']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Top Products -->
    <div class="col-lg-5">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold"><i class="bi bi-trophy me-2"></i>Top 10 Products</div>
            <div class="card-body p-0">
                <?php foreach ($topProducts as $i => $tp): ?>
                    <div class="d-flex align-items-center gap-2 p-3 border-bottom">
                        <span class="badge bg-dark">#<?= $i + 1 ?></span>
                        <img src="<?= productImageUrl($tp['product_image']) ?>" class="rounded" style="width:35px;height:35px;object-fit:cover;">
                        <div class="flex-grow-1"><div class="small fw-bold"><?= sanitize(truncateText($tp['product_name'], 25)) ?></div><small class="text-muted"><?= $tp['total_qty'] ?> sold</small></div>
                        <span class="small fw-bold text-success"><?= formatPrice($tp['total_revenue']) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>