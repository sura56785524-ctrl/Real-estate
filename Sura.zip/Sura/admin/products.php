<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$productModel  = new Product();
$categoryModel = new Category();

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $productModel->delete((int) $_GET['delete']);
    setFlash('success', 'Product deactivated successfully.');
    redirect('admin/products.php');
}

$filters = [
    'search'      => $_GET['search'] ?? '',
    'category_id' => $_GET['category_id'] ?? '',
    'is_active'   => $_GET['is_active'] ?? null,
];
$page = max(1, (int) ($_GET['page'] ?? 1));

$result     = $productModel->getAdminList($page, 20, $filters);
$products   = $result['products'];
$pagination = $result['pagination'];
$categories = $categoryModel->getAll(false);

$pageTitle = 'Products';
include INCLUDES_PATH . 'admin-header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="bi bi-box-seam me-2"></i>Products (<?= $pagination['total_items'] ?>)</h5>
    <a href="<?= url('admin/product-form.php') ?>" class="btn btn-success" style="background:#2d6a4f;border-color:#2d6a4f;">
        <i class="bi bi-plus-circle me-1"></i>Add Product
    </a>
</div>

<!-- Filters -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <input type="text" class="form-control form-control-sm" name="search" placeholder="Search products..." value="<?= sanitize($filters['search']) ?>">
            </div>
            <div class="col-md-3">
                <select class="form-select form-select-sm" name="category_id">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $filters['category_id'] == $c['id'] ? 'selected' : '' ?>><?= sanitize($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary btn-sm w-100"><i class="bi bi-search me-1"></i>Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="bg-light">
                <tr><th style="width:50px;">Img</th><th>Name</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th class="text-center">Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($products as $p): ?>
                    <tr>
                        <td><img src="<?= productImageUrl($p['image']) ?>" class="rounded" style="width:40px;height:40px;object-fit:cover;"></td>
                        <td class="fw-bold"><?= sanitize(truncateText($p['name'], 40)) ?></td>
                        <td><code><?= sanitize($p['sku']) ?></code></td>
                        <td><?= sanitize($p['category_name'] ?? 'N/A') ?></td>
                        <td>
                            <?php if ($p['sale_price']): ?>
                                <span class="text-success fw-bold"><?= formatPrice($p['sale_price']) ?></span>
                                <small class="text-muted text-decoration-line-through d-block"><?= formatPrice($p['price']) ?></small>
                            <?php else: ?>
                                <span class="fw-bold"><?= formatPrice($p['price']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?= stockStatus($p['stock_count'], $p['low_stock_threshold']) ?></td>
                        <td><?= $p['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?></td>
                        <td class="text-center">
                            <a href="<?= url('admin/product-form.php?id=' . $p['id']) ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                            <a href="<?= url('admin/products.php?delete=' . $p['id']) ?>" class="btn btn-sm btn-outline-danger" title="Delete" onclick="return confirm('Deactivate this product?');"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-4"><?= renderPagination($pagination, 'admin/products.php', array_filter($filters)) ?></div>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>