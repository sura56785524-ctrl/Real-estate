<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$orderModel = new Order();
$orderId = (int) ($_GET['id'] ?? 0);
$order = $orderModel->findById($orderId);

if (!$order) {
    setFlash('error', 'Order not found.');
    redirect('admin/orders.php');
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCsrfToken()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_status') {
        $newStatus = $_POST['status'] ?? '';
        $adminNotes = $_POST['admin_notes'] ?? '';
        $orderModel->updateStatus($orderId, $newStatus, $adminNotes);
        setFlash('success', 'Order status updated to: ' . ucfirst(str_replace('_', ' ', $newStatus)));
        redirect('admin/order-detail.php?id=' . $orderId);
    }

    if ($action === 'verify_payment') {
        $orderModel->updatePaymentStatus($orderId, 'paid', 'MANUAL-' . date('YmdHis'));
        $orderModel->updateStatus($orderId, 'confirmed');
        setFlash('success', 'Payment verified and order confirmed!');
        redirect('admin/order-detail.php?id=' . $orderId);
    }

    if ($action === 'reject_payment') {
        $orderModel->updatePaymentStatus($orderId, 'failed');
        setFlash('warning', 'Payment rejected.');
        redirect('admin/order-detail.php?id=' . $orderId);
    }
}

$items = $orderModel->getOrderItems($orderId);
$pageTitle = 'Order ' . $order['order_number'];
include INCLUDES_PATH . 'admin-header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="bi bi-receipt me-2"></i><?= sanitize($order['order_number']) ?></h5>
    <a href="<?= url('admin/orders.php') ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <!-- Order Items -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-bold"><i class="bi bi-bag me-2"></i>Order Items</div>
            <div class="table-responsive">
                <table class="table mb-0 small">
                    <thead class="bg-light"><tr><th>Product</th><th class="text-center">Qty</th><th class="text-end">Unit Price</th><th class="text-end">Total</th></tr></thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td><div class="d-flex align-items-center gap-2"><img src="<?= productImageUrl($item['product_image']) ?>" class="rounded" style="width:40px;height:40px;object-fit:cover;"><div><strong><?= sanitize($item['product_name']) ?></strong><br><small class="text-muted"><?= sanitize($item['product_sku']) ?></small></div></div></td>
                                <td class="text-center"><?= $item['quantity'] ?></td>
                                <td class="text-end"><?= formatPrice($item['unit_price']) ?></td>
                                <td class="text-end fw-bold"><?= formatPrice($item['total_price']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="bg-light">
                        <tr><td colspan="3" class="text-end fw-bold">Subtotal:</td><td class="text-end fw-bold"><?= formatPrice($order['subtotal']) ?></td></tr>
                        <?php if ($order['discount_amount'] > 0): ?><tr class="text-success"><td colspan="3" class="text-end">Discount:</td><td class="text-end">-<?= formatPrice($order['discount_amount']) ?></td></tr><?php endif; ?>
                        <tr><td colspan="3" class="text-end">Shipping:</td><td class="text-end"><?= $order['shipping_amount'] > 0 ? formatPrice($order['shipping_amount']) : 'Free' ?></td></tr>
                        <tr><td colspan="3" class="text-end">Tax:</td><td class="text-end"><?= formatPrice($order['tax_amount']) ?></td></tr>
                        <tr><td colspan="3" class="text-end fw-bold fs-6">Total:</td><td class="text-end fw-bold fs-6 text-success"><?= formatPrice($order['total_amount']) ?></td></tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Shipping Info -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold"><i class="bi bi-truck me-2"></i>Shipping Details</div>
            <div class="card-body small">
                <div class="row">
                    <div class="col-md-6">
                        <strong>Name:</strong> <?= sanitize($order['shipping_first_name'] . ' ' . $order['shipping_last_name']) ?><br>
                        <strong>Phone:</strong> <?= sanitize($order['shipping_phone']) ?><br>
                        <strong>Email:</strong> <?= sanitize($order['shipping_email'] ?? 'N/A') ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Address:</strong> <?= sanitize($order['shipping_address']) ?><br>
                        <strong>City:</strong> <?= sanitize($order['shipping_city']) ?><br>
                        <strong>Country:</strong> <?= sanitize($order['shipping_country']) ?>
                    </div>
                </div>
                <?php if ($order['notes']): ?>
                    <hr><strong>Customer Notes:</strong> <?= sanitize($order['notes']) ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <!-- Status Update -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-dark text-white fw-bold"><i class="bi bi-gear me-2"></i>Update Status</div>
            <div class="card-body">
                <div class="mb-3">
                    <strong>Current:</strong> <?= orderStatusBadge($order['status']) ?> <?= paymentStatusBadge($order['payment_status']) ?>
                </div>
                <form method="POST">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="update_status">
                    <div class="mb-3">
                        <select class="form-select form-select-sm" name="status">
                            <?php foreach (['pending','confirmed','processing','in_transit','delivered','cancelled'] as $s): ?>
                                <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <textarea class="form-control form-control-sm" name="admin_notes" rows="2" placeholder="Admin notes..."><?= sanitize($order['admin_notes'] ?? '') ?></textarea>
                    </div>
                    <button class="btn btn-primary btn-sm w-100"><i class="bi bi-check me-1"></i>Update</button>
                </form>
            </div>
        </div>

        <!-- Payment Verification (for bank transfers) -->
        <?php if ($order['payment_status'] === 'pending_verification'): ?>
            <div class="card border-0 shadow-sm mb-4 border-warning border-2">
                <div class="card-header bg-warning text-dark fw-bold"><i class="bi bi-credit-card me-2"></i>Verify Payment</div>
                <div class="card-body">
                    <p class="small"><strong>Method:</strong> <?= ucwords(str_replace('_', ' ', $order['payment_method'])) ?></p>
                    <?php if ($order['receipt_image']): ?>
                        <img src="<?= url($order['receipt_image']) ?>" class="img-fluid rounded mb-3 shadow-sm">
                    <?php endif; ?>
                    <div class="d-flex gap-2">
                        <form method="POST" class="flex-fill">
                            <?= csrfField() ?>
                            <input type="hidden" name="action" value="verify_payment">
                            <button class="btn btn-success btn-sm w-100"><i class="bi bi-check-circle me-1"></i>Approve</button>
                        </form>
                        <form method="POST" class="flex-fill">
                            <?= csrfField() ?>
                            <input type="hidden" name="action" value="reject_payment">
                            <button class="btn btn-danger btn-sm w-100"><i class="bi bi-x-circle me-1"></i>Reject</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Order Timeline -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold"><i class="bi bi-clock-history me-2"></i>Timeline</div>
            <div class="card-body small">
                <div class="mb-2"><i class="bi bi-circle-fill text-primary me-2" style="font-size:0.5rem;"></i>Created: <?= formatDateTime($order['created_at']) ?></div>
                <?php if ($order['shipped_at']): ?><div class="mb-2"><i class="bi bi-circle-fill text-info me-2" style="font-size:0.5rem;"></i>Shipped: <?= formatDateTime($order['shipped_at']) ?></div><?php endif; ?>
                <?php if ($order['delivered_at']): ?><div class="mb-2"><i class="bi bi-circle-fill text-success me-2" style="font-size:0.5rem;"></i>Delivered: <?= formatDateTime($order['delivered_at']) ?></div><?php endif; ?>
                <?php if ($order['cancelled_at']): ?><div class="mb-2"><i class="bi bi-circle-fill text-danger me-2" style="font-size:0.5rem;"></i>Cancelled: <?= formatDateTime($order['cancelled_at']) ?></div><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>