<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$orderModel = new Order();

$filters = [
    'status'         => $_GET['status'] ?? '',
    'payment_status' => $_GET['payment_status'] ?? '',
    'search'         => $_GET['search'] ?? '',
    'date_from'      => $_GET['date_from'] ?? '',
    'date_to'        => $_GET['date_to'] ?? '',
];
$page = max(1, (int) ($_GET['page'] ?? 1));

$result     = $orderModel->getAllOrders($page, ORDERS_PER_PAGE, $filters);
$orders     = $result['orders'];
$pagination = $result['pagination'];

$pageTitle = 'Orders';
include INCLUDES_PATH . 'admin-header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="bi bi-cart-check me-2"></i>Orders (<?= $pagination['total_items'] ?>)</h5>
</div>

<!-- Filters -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-2">
                <input type="text" class="form-control form-control-sm" name="search" placeholder="Order # / Name / Phone" value="<?= sanitize($filters['search']) ?>">
            </div>
            <div class="col-md-2">
                <select class="form-select form-select-sm" name="status">
                    <option value="">All Statuses</option>
                    <?php foreach (['pending','confirmed','processing','in_transit','delivered','cancelled'] as $s): ?>
                        <option value="<?= $s ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select class="form-select form-select-sm" name="payment_status">
                    <option value="">All Payments</option>
                    <?php foreach (['unpaid','pending_verification','paid','failed'] as $ps): ?>
                        <option value="<?= $ps ?>" <?= $filters['payment_status'] === $ps ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$ps)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2"><input type="date" class="form-control form-control-sm" name="date_from" value="<?= $filters['date_from'] ?>"></div>
            <div class="col-md-2"><input type="date" class="form-control form-control-sm" name="date_to" value="<?= $filters['date_to'] ?>"></div>
            <div class="col-md-1"><button class="btn btn-primary btn-sm w-100"><i class="bi bi-search"></i></button></div>
            <div class="col-md-1"><a href="<?= url('admin/orders.php') ?>" class="btn btn-outline-secondary btn-sm w-100">Clear</a></div>
        </form>
    </div>
</div>

<!-- Orders Table -->
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="bg-light"><tr><th>Order #</th><th>Customer</th><th>Total</th><th>Status</th><th>Payment</th><th>Method</th><th>Date</th><th class="text-center">Action</th></tr></thead>
            <tbody>
                <?php foreach ($orders as $o): ?>
                    <tr>
                        <td class="fw-bold"><?= sanitize($o['order_number']) ?></td>
                        <td><?= sanitize(($o['user_first_name'] ?? '') . ' ' . ($o['user_last_name'] ?? '')) ?></td>
                        <td class="fw-bold"><?= formatPrice($o['total_amount']) ?></td>
                        <td><?= orderStatusBadge($o['status']) ?></td>
                        <td><?= paymentStatusBadge($o['payment_status']) ?></td>
                        <td><small><?= ucwords(str_replace('_', ' ', $o['payment_method'] ?? 'N/A')) ?></small></td>
                        <td><?= formatDate($o['created_at'], 'M d, H:i') ?></td>
                        <td class="text-center">
                            <a href="<?= url('admin/order-detail.php?id=' . $o['id']) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye me-1"></i>View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-4"><?= renderPagination($pagination, 'admin/orders.php', array_filter($filters)) ?></div>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>