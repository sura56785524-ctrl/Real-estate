<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$orderModel   = new Order();
$productModel = new Product();
$userModel    = new User();

$orderStats   = $orderModel->getStats();
$productStats = $productModel->getStats();
$userStats    = $userModel->getStats();
$recentOrders = $orderModel->getRecent(10);
$lowStock     = $productModel->getLowStock();
$monthlySales = $orderModel->getMonthlySales();
$topProducts  = $orderModel->getTopProducts(5);

$pageTitle = 'Dashboard';
include INCLUDES_PATH . 'admin-header.php';
?>

<!-- Stats Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-xl-3">
        <div class="card border-0 shadow-sm border-start border-4 border-success">
            <div class="card-body">
                <div class="d-flex justify-content-between"><div><small class="text-muted">Total Revenue</small><h4 class="fw-bold mb-0 text-success"><?= formatPrice($orderStats['total_revenue']) ?></h4></div><i class="bi bi-currency-exchange fs-2 text-success opacity-25"></i></div>
                <small class="text-muted">This month: <?= formatPrice($orderStats['month_revenue']) ?></small>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="card border-0 shadow-sm border-start border-4 border-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between"><div><small class="text-muted">Total Orders</small><h4 class="fw-bold mb-0 text-primary"><?= $orderStats['total_orders'] ?></h4></div><i class="bi bi-box-seam fs-2 text-primary opacity-25"></i></div>
                <small class="text-muted">Today: <?= $orderStats['today_orders'] ?> | Month: <?= $orderStats['month_orders'] ?></small>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="card border-0 shadow-sm border-start border-4 border-info">
            <div class="card-body">
                <div class="d-flex justify-content-between"><div><small class="text-muted">Products</small><h4 class="fw-bold mb-0 text-info"><?= $productStats['active'] ?></h4></div><i class="bi bi-bag fs-2 text-info opacity-25"></i></div>
                <small class="text-muted">Low stock: <?= $productStats['low_stock'] ?> | Out: <?= $productStats['out_of_stock'] ?></small>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="card border-0 shadow-sm border-start border-4 border-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between"><div><small class="text-muted">Customers</small><h4 class="fw-bold mb-0 text-warning"><?= $userStats['total_customers'] ?></h4></div><i class="bi bi-people fs-2 text-warning opacity-25"></i></div>
                <small class="text-muted">New this month: <?= $userStats['new_this_month'] ?></small>
            </div>
        </div>
    </div>
</div>

<!-- Pending Actions -->
<?php if ($orderStats['pending'] > 0 || $orderStats['pending_payments'] > 0): ?>
    <div class="row g-3 mb-4">
        <?php if ($orderStats['pending'] > 0): ?>
            <div class="col-md-6"><div class="alert alert-warning mb-0"><i class="bi bi-exclamation-triangle me-2"></i><strong><?= $orderStats['pending'] ?></strong> orders pending confirmation. <a href="<?= url('admin/orders.php?status=pending') ?>">View</a></div></div>
        <?php endif; ?>
        <?php if ($orderStats['pending_payments'] > 0): ?>
            <div class="col-md-6"><div class="alert alert-info mb-0"><i class="bi bi-credit-card me-2"></i><strong><?= $orderStats['pending_payments'] ?></strong> payments need verification. <a href="<?= url('admin/payments.php') ?>">Verify</a></div></div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Recent Orders -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0"><i class="bi bi-clock-history me-2"></i>Recent Orders</h6>
                <a href="<?= url('admin/orders.php') ?>" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="bg-light"><tr><th>Order #</th><th>Customer</th><th>Total</th><th>Status</th><th>Payment</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php foreach ($recentOrders as $o): ?>
                            <tr>
                                <td><a href="<?= url('admin/order-detail.php?id=' . $o['id']) ?>" class="fw-bold text-decoration-none"><?= sanitize($o['order_number']) ?></a></td>
                                <td><?= sanitize(($o['user_first_name'] ?? '') . ' ' . ($o['user_last_name'] ?? '')) ?></td>
                                <td class="fw-bold"><?= formatPrice($o['total_amount']) ?></td>
                                <td><?= orderStatusBadge($o['status']) ?></td>
                                <td><?= paymentStatusBadge($o['payment_status']) ?></td>
                                <td><?= formatDate($o['created_at'], 'M d, H:i') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Top Products & Low Stock -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-bold"><i class="bi bi-trophy me-2"></i>Top Selling</div>
            <div class="card-body p-0">
                <?php foreach ($topProducts as $tp): ?>
                    <div class="d-flex align-items-center gap-2 p-3 border-bottom">
                        <img src="<?= productImageUrl($tp['product_image']) ?>" class="rounded" style="width:40px;height:40px;object-fit:cover;">
                        <div class="flex-grow-1">
                            <div class="small fw-bold"><?= sanitize(truncateText($tp['product_name'], 30)) ?></div>
                            <small class="text-muted"><?= $tp['total_qty'] ?> sold</small>
                        </div>
                        <span class="fw-bold small text-success"><?= formatPrice($tp['total_revenue']) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (!empty($lowStock)): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-bold text-warning"><i class="bi bi-exclamation-triangle me-2"></i>Low Stock Alert</div>
                <div class="card-body p-0">
                    <?php foreach (array_slice($lowStock, 0, 5) as $ls): ?>
                        <div class="d-flex justify-content-between p-3 border-bottom small">
                            <span><?= sanitize(truncateText($ls['name'], 25)) ?></span>
                            <span class="badge bg-warning text-dark"><?= $ls['stock_count'] ?> left</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>