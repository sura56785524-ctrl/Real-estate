<?php
/**
 * ================================================================
 * Admin Login Page — Restricted to admin role accounts
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';

// If already logged in as admin, redirect to dashboard
if (isAdmin()) {
    redirect('admin/index.php');
}
// If logged in as customer, redirect to user dashboard
if (isLoggedIn() && !isAdmin()) {
    setFlash('error', 'Access denied. Admins only.');
    redirect('user/dashboard.php');
}

$errors = [];
$email  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token.';
    } else {
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $errors[] = 'Please enter both email and password.';
        }

        if (empty($errors)) {
            try {
                $userModel = new User();
                $user = $userModel->authenticate($email, $password);

                if ($user) {
                    // Verify admin role
                    if ($user['role'] !== 'admin') {
                        $errors[] = 'Access denied. This portal is for administrators only.';
                    } else {
                        $userModel->createSession($user);
                        setFlash('success', 'Welcome to Admin Dashboard, ' . sanitize($user['first_name']) . '!');
                        redirect('admin/index.php');
                    }
                } else {
                    $errors[] = 'Invalid email or password.';
                }
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
}

$pageTitle = 'Admin Login — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .admin-login-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
            max-width: 460px;
            width: 100%;
            padding: 3rem;
        }
        .admin-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #f8d7da;
            color: #842029;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        .admin-icon {
            width: 80px; height: 80px; border-radius: 50%;
            background: linear-gradient(135deg, #1a1a2e, #0f3460);
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 1rem;
        }
        .admin-icon i { font-size: 2rem; color: #e0e1dd; }
        .btn-admin-login {
            background: linear-gradient(135deg, #1a1a2e, #0f3460);
            border: none; padding: 0.75rem; font-weight: 600;
            border-radius: 8px; transition: all 0.3s ease;
        }
        .btn-admin-login:hover {
            background: linear-gradient(135deg, #0f3460, #1a5276);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(15,52,96,0.4);
        }
        .form-floating > .form-control:focus {
            border-color: #0f3460;
            box-shadow: 0 0 0 0.2rem rgba(15,52,96,0.25);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="admin-login-card mx-auto text-center">
            <div class="admin-icon">
                <i class="bi bi-shield-lock"></i>
            </div>

            <span class="admin-badge">
                <i class="bi bi-lock-fill"></i> ADMIN PORTAL
            </span>

            <h3 class="fw-bold mb-1" style="color:#1a1a2e;">Admin Sign In</h3>
            <p class="text-muted small mb-3">Authorized personnel only</p>

            <!-- Logo -->
            <div class="mb-3">
                <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>" style="max-width: 90px; opacity: 0.8;">
            </div>

            <!-- Errors -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger text-start py-2">
                    <i class="bi bi-exclamation-triangle-fill me-1"></i>
                    <?php foreach ($errors as $error): ?>
                        <?= sanitize($error) ?><br>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?= renderFlash() ?>

            <form method="POST" action="" novalidate class="text-start">
                <?= csrfField() ?>

                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="email" name="email"
                           placeholder="Admin Email" value="<?= sanitize($email) ?>" required autofocus>
                    <label for="email"><i class="bi bi-envelope me-1"></i> Admin Email</label>
                </div>

                <div class="form-floating mb-3 position-relative">
                    <input type="password" class="form-control" id="password" name="password"
                           placeholder="Password" required>
                    <label for="password"><i class="bi bi-lock me-1"></i> Password</label>
                    <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;z-index:5;color:#6c757d;"
                          onclick="togglePwdVis()">
                        <i class="bi bi-eye" id="toggleIcon"></i>
                    </span>
                </div>

                <button type="submit" class="btn btn-admin-login text-white w-100 mb-3">
                    <i class="bi bi-box-arrow-in-right me-1"></i> Sign In to Dashboard
                </button>
            </form>

            <div class="mt-2">
                <a href="<?= url() ?>" class="small text-muted text-decoration-none">
                    <i class="bi bi-arrow-left me-1"></i> Back to Shop
                </a>
            </div>

            <!-- Default Credentials Notice (DEV ONLY) -->
            <div class="alert alert-secondary mt-3 small text-start py-2" style="font-size:0.8rem;">
                <strong><i class="bi bi-code-slash me-1"></i> Dev Credentials:</strong><br>
                Email: <code>admin@stationeryshop.et</code><br>
                Password: <code>Admin@123</code>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePwdVis() {
            const inp = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (inp.type === 'password') {
                inp.type = 'text';
                icon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                inp.type = 'password';
                icon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        }
    </script>
</body>
</html>