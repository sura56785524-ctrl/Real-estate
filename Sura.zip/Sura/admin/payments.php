<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireAdmin();

$orderModel = new Order();
$db = Database::getInstance();

$pendingOrders = $db->fetchAll(
    "SELECT o.*, u.first_name, u.last_name, u.email
     FROM orders o
     LEFT JOIN users u ON u.id = o.user_id
     WHERE o.payment_status = 'pending_verification'
     ORDER BY o.created_at DESC"
);

$pageTitle = 'Payment Verification';
include INCLUDES_PATH . 'admin-header.php';
?>

<h5 class="fw-bold mb-4"><i class="bi bi-credit-card me-2"></i>Pending Payment Verification (<?= count($pendingOrders) ?>)</h5>

<?php if (empty($pendingOrders)): ?>
    <div class="text-center py-5"><i class="bi bi-check-circle display-1 text-success"></i><h5 class="mt-3 text-muted">All payments verified! No pending verifications.</h5></div>
<?php else: ?>
    <div class="row g-4">
        <?php foreach ($pendingOrders as $o): ?>
            <div class="col-md-6 col-xl-4">
                <div class="card border-0 shadow-sm border-start border-4 border-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <strong><?= sanitize($o['order_number']) ?></strong>
                            <span class="badge bg-warning text-dark"><?= ucwords(str_replace('_', ' ', $o['payment_method'])) ?></span>
                        </div>
                        <p class="small mb-1"><strong>Customer:</strong> <?= sanitize($o['first_name'] . ' ' . $o['last_name']) ?></p>
                        <p class="small mb-1"><strong>Amount:</strong> <span class="text-success fw-bold"><?= formatPrice($o['total_amount']) ?></span></p>
                        <p class="small mb-2"><strong>Date:</strong> <?= formatDateTime($o['created_at']) ?></p>

                        <?php if ($o['receipt_image']): ?>
                            <a href="<?= url($o['receipt_image']) ?>" target="_blank">
                                <img src="<?= url($o['receipt_image']) ?>" class="img-fluid rounded shadow-sm mb-3" style="max-height:150px;">
                            </a>
                        <?php else: ?>
                            <div class="alert alert-secondary py-2 small mb-3"><i class="bi bi-image me-1"></i>No receipt uploaded yet</div>
                        <?php endif; ?>

                        <div class="d-flex gap-2">
                            <form method="POST" action="<?= url('admin/order-detail.php?id=' . $o['id']) ?>" class="flex-fill">
                                <?= csrfField() ?>
                                <input type="hidden" name="action" value="verify_payment">
                                <button class="btn btn-success btn-sm w-100"><i class="bi bi-check me-1"></i>Approve</button>
                            </form>
                            <form method="POST" action="<?= url('admin/order-detail.php?id=' . $o['id']) ?>" class="flex-fill">
                                <?= csrfField() ?>
                                <input type="hidden" name="action" value="reject_payment">
                                <button class="btn btn-danger btn-sm w-100"><i class="bi bi-x me-1"></i>Reject</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php include INCLUDES_PATH . 'admin-footer.php'; ?>