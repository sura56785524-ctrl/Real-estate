<?php
/**
 * ================================================================
 * Payment Callback — Handles responses from Chapa & SantimPay
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';

$gateway  = $_GET['gateway'] ?? '';
$action   = $_GET['action'] ?? 'verify';
$txRef    = $_GET['tx_ref'] ?? $_GET['trx_ref'] ?? '';
$orderId  = (int) ($_GET['order_id'] ?? $_SESSION['pending_order_id'] ?? 0);

$orderModel = new Order();
$db = Database::getInstance();

try {
    // ── INITIATE: Redirect user to payment gateway ──────────
    if ($action === 'initiate' && $orderId > 0) {
        $order = $orderModel->findById($orderId);
        if (!$order) throw new RuntimeException('Order not found.');

        $user = (new User())->findById((int) $order['user_id']);

        $orderData = [
            'order_id'     => $orderId,
            'order_number' => $order['order_number'],
            'total_amount' => $order['total_amount'],
            'first_name'   => $order['shipping_first_name'],
            'last_name'    => $order['shipping_last_name'],
            'email'        => $order['shipping_email'] ?? $user['email'] ?? '',
            'phone'        => $order['shipping_phone'],
        ];

        if ($gateway === 'chapa') {
            $gw = new ChapaGateway();
        } elseif ($gateway === 'santimpay') {
            $gw = new SantimPayGateway();
        } else {
            throw new RuntimeException('Invalid gateway.');
        }

        $result = $gw->initiate($orderData);

        // Log transaction
        $db->insert('payment_transactions', [
            'order_id'        => $orderId,
            'user_id'         => $order['user_id'],
            'gateway'         => $gateway,
            'transaction_ref' => $result['tx_ref'],
            'amount'          => $order['total_amount'],
            'currency'        => 'ETB',
            'status'          => 'initiated',
        ]);

        // Update order with payment ref
        $orderModel->updatePaymentStatus($orderId, 'unpaid', $result['tx_ref']);

        // Redirect to checkout page
        header('Location: ' . $result['checkout_url']);
        exit;
    }

    // ── VERIFY: Callback from gateway ───────────────────────
    if (!empty($txRef)) {
        // Find the transaction
        $transaction = $db->fetchOne(
            "SELECT * FROM payment_transactions WHERE transaction_ref = ? LIMIT 1",
            [$txRef]
        );

        if (!$transaction) {
            // Try to find order by payment ref
            $order = $db->fetchOne("SELECT * FROM orders WHERE payment_ref = ? LIMIT 1", [$txRef]);
            if (!$order) throw new RuntimeException('Transaction not found.');
            $orderId = $order['id'];
        } else {
            $orderId = $transaction['order_id'];
        }

        // Verify with gateway
        if ($gateway === 'chapa') {
            $gw = new ChapaGateway();
        } elseif ($gateway === 'santimpay') {
            $gw = new SantimPayGateway();
        } else {
            throw new RuntimeException('Invalid gateway.');
        }

        $verification = $gw->verify($txRef);

        // Update transaction
        if ($transaction) {
            $db->update('payment_transactions', [
                'status'           => $verification['status'] === 'success' ? 'success' : 'failed',
                'gateway_response' => json_encode($verification['raw'] ?? []),
            ], '`id` = ?', [$transaction['id']]);
        }

        // Update order
        if ($verification['status'] === 'success') {
            $orderModel->updatePaymentStatus($orderId, 'paid', $txRef);
            $orderModel->updateStatus($orderId, 'confirmed');
            setFlash('success', 'Payment successful! Your order has been confirmed.');
        } else {
            $orderModel->updatePaymentStatus($orderId, 'failed');
            setFlash('error', 'Payment verification failed. Please try again or contact support.');
        }

        redirect('user/order-detail.php?id=' . $orderId);
    }

    throw new RuntimeException('Invalid callback request.');

} catch (RuntimeException $e) {
    error_log('Payment Callback Error: ' . $e->getMessage());
    setFlash('error', 'Payment Error: ' . $e->getMessage());
    redirect($orderId ? 'user/order-detail.php?id=' . $orderId : 'cart.php');
}