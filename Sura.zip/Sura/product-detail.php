<?php
/**
 * ================================================================
 * Product Detail Page — Single product view
 * Features: Gallery, quantity selector, add-to-cart, related items
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';

$productModel = new Product();

$productId = (int) ($_GET['id'] ?? 0);
$product = $productModel->findById($productId);

if (!$product || !$product['is_active']) {
    setFlash('error', 'Product not found.');
    redirect('shop.php');
}

// Increment view count
$productModel->incrementViews($productId);

// Get related products
$relatedProducts = $productModel->getRelated($productId, (int) $product['category_id'], 4);

$effectivePrice = (float) $product['effective_price'];
$discount       = (int) $product['discount_percent'];
$inStock        = (int) $product['stock_count'] > 0;

$pageTitle = sanitize($product['name']) . ' — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>
    <div class="container mt-3"><?= renderFlash() ?></div>

    <!-- Breadcrumb -->
    <div class="bg-light py-3 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="<?= url() ?>" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('shop.php') ?>" class="text-decoration-none">Shop</a></li>
                    <?php if (!empty($product['category_name'])): ?>
                        <li class="breadcrumb-item">
                            <a href="<?= url('shop.php?category=' . sanitize($product['category_slug'])) ?>" class="text-decoration-none">
                                <?= sanitize($product['category_name']) ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="breadcrumb-item active"><?= sanitize(truncateText($product['name'], 40)) ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Product Detail -->
    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <!-- Product Image -->
                <div class="col-lg-5">
                    <div class="position-relative">
                        <img src="<?= productImageUrl($product['image']) ?>"
                             alt="<?= sanitize($product['name']) ?>"
                             class="img-fluid rounded shadow-sm w-100"
                             style="max-height:500px; object-fit:cover;" id="mainImage">

                        <?php if ($discount > 0): ?>
                            <span class="position-absolute top-0 start-0 m-3 badge bg-danger fs-6 px-3">
                                -<?= $discount ?>% OFF
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Product Info -->
                <div class="col-lg-7">
                    <!-- Category & SKU -->
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <a href="<?= url('shop.php?category=' . sanitize($product['category_slug'] ?? '')) ?>"
                           class="badge bg-light text-dark text-decoration-none">
                            <i class="bi bi-folder2 me-1"></i><?= sanitize($product['category_name'] ?? '') ?>
                        </a>
                        <small class="text-muted">SKU: <?= sanitize($product['sku']) ?></small>
                    </div>

                    <!-- Name -->
                    <h2 class="fw-bold mb-3"><?= sanitize($product['name']) ?></h2>

                    <!-- Price -->
                    <div class="mb-3">
                        <?php if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']): ?>
                            <span class="fs-3 fw-bold text-success"><?= formatPrice($product['sale_price']) ?></span>
                            <span class="fs-5 text-muted text-decoration-line-through ms-2"><?= formatPrice($product['price']) ?></span>
                            <span class="badge bg-danger ms-2 fs-6">Save <?= formatPrice($product['price'] - $product['sale_price']) ?></span>
                        <?php else: ?>
                            <span class="fs-3 fw-bold text-success"><?= formatPrice($product['price']) ?></span>
                        <?php endif; ?>
                    </div>

                    <!-- Short Description -->
                    <?php if (!empty($product['short_desc'])): ?>
                        <p class="text-muted mb-3"><?= sanitize($product['short_desc']) ?></p>
                    <?php endif; ?>

                    <!-- Stock Status -->
                    <div class="mb-3">
                        <?= stockStatus((int) $product['stock_count'], (int) $product['low_stock_threshold']) ?>
                        <?php if (!empty($product['origin_country'])): ?>
                            <span class="badge bg-info text-dark ms-2">
                                <i class="bi bi-globe me-1"></i>Origin: <?= sanitize($product['origin_country']) ?>
                            </span>
                        <?php endif; ?>
                    </div>

                    <hr>

                    <!-- Quantity & Add to Cart -->
                    <?php if ($inStock): ?>
                        <div class="d-flex align-items-center gap-3 mb-4">
                            <label class="fw-bold small">Quantity:</label>
                            <div class="input-group" style="width:140px;">
                                <button class="btn btn-outline-secondary" type="button" id="qtyMinus">
                                    <i class="bi bi-dash"></i>
                                </button>
                                <input type="number" class="form-control text-center" id="productQty"
                                       value="1" min="1" max="<?= (int) $product['stock_count'] ?>">
                                <button class="btn btn-outline-secondary" type="button" id="qtyPlus">
                                    <i class="bi bi-plus"></i>
                                </button>
                            </div>
                            <small class="text-muted">(<?= (int) $product['stock_count'] ?> available)</small>
                        </div>

                        <div class="d-flex gap-3 mb-4">
                            <button class="btn btn-success btn-lg px-5 add-to-cart-detail"
                                    data-product-id="<?= $productId ?>"
                                    style="background:#2d6a4f; border-color:#2d6a4f; border-radius:10px;">
                                <i class="bi bi-cart-plus me-2"></i> Add to Cart
                            </button>
                            <a href="<?= url('checkout.php') ?>" class="btn btn-warning btn-lg px-4"
                               style="border-radius:10px;" id="buyNowBtn"
                               onclick="addAndRedirect(<?= $productId ?>); return false;">
                                <i class="bi bi-lightning me-1"></i> Buy Now
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            This product is currently out of stock. Please check back later.
                        </div>
                    <?php endif; ?>

                    <!-- Product Meta -->
                    <div class="card border-0 bg-light">
                        <div class="card-body small">
                            <div class="row g-2">
                                <?php if (!empty($product['weight'])): ?>
                                    <div class="col-6">
                                        <i class="bi bi-box me-1 text-muted"></i>
                                        <strong>Weight:</strong> <?= $product['weight'] ?> kg
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($product['hs_code'])): ?>
                                    <div class="col-6">
                                        <i class="bi bi-upc me-1 text-muted"></i>
                                        <strong>HS Code:</strong> <?= sanitize($product['hs_code']) ?>
                                    </div>
                                <?php endif; ?>
                                <div class="col-6">
                                    <i class="bi bi-truck me-1 text-muted"></i>
                                    <strong>Shipping:</strong>
                                    <?= $effectivePrice >= FREE_SHIPPING_MINIMUM ? '<span class="text-success">Free</span>' : formatPrice(SHIPPING_FLAT_RATE) ?>
                                </div>
                                <div class="col-6">
                                    <i class="bi bi-eye me-1 text-muted"></i>
                                    <strong>Views:</strong> <?= number_format((int) $product['view_count']) ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Full Description -->
            <?php if (!empty($product['description'])): ?>
                <div class="mt-5">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active fw-bold" data-bs-toggle="tab" data-bs-target="#descTab">
                                <i class="bi bi-file-text me-1"></i> Description
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link fw-bold" data-bs-toggle="tab" data-bs-target="#shippingTab">
                                <i class="bi bi-truck me-1"></i> Shipping Info
                            </button>
                        </li>
                    </ul>
                    <div class="tab-content border border-top-0 p-4 rounded-bottom">
                        <div class="tab-pane fade show active" id="descTab">
                            <p><?= nl2br(sanitize($product['description'])) ?></p>
                        </div>
                        <div class="tab-pane fade" id="shippingTab">
                            <h6>Shipping Information</h6>
                            <ul>
                                <li>Free shipping on orders over <?= formatPrice(FREE_SHIPPING_MINIMUM) ?></li>
                                <li>Standard delivery: 3-5 business days within Addis Ababa</li>
                                <li>Regional delivery: 5-10 business days</li>
                                <li>Flat rate shipping: <?= formatPrice(SHIPPING_FLAT_RATE) ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Related Products -->
            <?php if (!empty($relatedProducts)): ?>
                <div class="mt-5">
                    <h4 class="fw-bold mb-4"><i class="bi bi-collection me-2"></i>Related Products</h4>
                    <div class="row g-3">
                        <?php foreach ($relatedProducts as $product): ?>
                            <div class="col-6 col-md-3">
                                <?php include INCLUDES_PATH . '../includes/product-card.php'; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include INCLUDES_PATH . 'footer.php'; ?>

    <script>
        // Quantity controls
        const qtyInput = document.getElementById('productQty');
        const maxStock = <?= (int) $product['stock_count'] ?>;

        document.getElementById('qtyMinus')?.addEventListener('click', () => {
            qtyInput.value = Math.max(1, parseInt(qtyInput.value) - 1);
        });
        document.getElementById('qtyPlus')?.addEventListener('click', () => {
            qtyInput.value = Math.min(maxStock, parseInt(qtyInput.value) + 1);
        });

        // Add to cart from detail page (uses quantity input)
        document.querySelector('.add-to-cart-detail')?.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const qty = parseInt(qtyInput.value) || 1;
            addToCart(productId, qty);
        });

        // Buy Now
        function addAndRedirect(productId) {
            const qty = parseInt(qtyInput?.value) || 1;
            addToCart(productId, qty, true);
        }
    </script>
</body>
</html>