-- ================================================================
-- DATABASE SCHEMA: Import & Export Full Pack Stationery
-- Engine: MySQL 8.x | Charset: utf8mb4
-- ================================================================

CREATE DATABASE IF NOT EXISTS `stationery_shop`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE `stationery_shop`;

-- ================================================================
-- TABLE 1: users
-- Handles both customers and admin accounts
-- ================================================================
CREATE TABLE `users` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `first_name`      VARCHAR(100) NOT NULL,
    `last_name`       VARCHAR(100) NOT NULL,
    `email`           VARCHAR(255) NOT NULL UNIQUE,
    `phone`           VARCHAR(20) DEFAULT NULL,
    `password`        VARCHAR(255) NOT NULL,
    `role`            ENUM('customer', 'admin') NOT NULL DEFAULT 'customer',
    `address`         TEXT DEFAULT NULL,
    `city`            VARCHAR(100) DEFAULT NULL,
    `state`           VARCHAR(100) DEFAULT NULL,
    `zip_code`        VARCHAR(20) DEFAULT NULL,
    `country`         VARCHAR(100) DEFAULT 'Ethiopia',
    `avatar`          VARCHAR(255) DEFAULT NULL,
    `email_verified`  TINYINT(1) NOT NULL DEFAULT 0,
    `verify_token`    VARCHAR(255) DEFAULT NULL,
    `reset_token`     VARCHAR(255) DEFAULT NULL,
    `reset_expires`   DATETIME DEFAULT NULL,
    `is_active`       TINYINT(1) NOT NULL DEFAULT 1,
    `last_login`      DATETIME DEFAULT NULL,
    `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX `idx_users_email` (`email`),
    INDEX `idx_users_role` (`role`),
    INDEX `idx_users_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- TABLE 2: categories
-- Product categories with hierarchy support
-- ================================================================
CREATE TABLE `categories` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `parent_id`       INT UNSIGNED DEFAULT NULL,
    `name`            VARCHAR(255) NOT NULL,
    `slug`            VARCHAR(255) NOT NULL UNIQUE,
    `description`     TEXT DEFAULT NULL,
    `image`           VARCHAR(255) DEFAULT NULL,
    `sort_order`      INT NOT NULL DEFAULT 0,
    `is_active`       TINYINT(1) NOT NULL DEFAULT 1,
    `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX `idx_categories_slug` (`slug`),
    INDEX `idx_categories_parent` (`parent_id`),
    INDEX `idx_categories_active` (`is_active`),
    CONSTRAINT `fk_categories_parent`
        FOREIGN KEY (`parent_id`) REFERENCES `categories`(`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- TABLE 3: products
-- Full product inventory with stock_count for import/export tracking
-- ================================================================
CREATE TABLE `products` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `category_id`     INT UNSIGNED NOT NULL,
    `name`            VARCHAR(255) NOT NULL,
    `slug`            VARCHAR(255) NOT NULL UNIQUE,
    `sku`             VARCHAR(50) NOT NULL UNIQUE,
    `description`     TEXT DEFAULT NULL,
    `short_desc`      VARCHAR(500) DEFAULT NULL,
    `price`           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `sale_price`      DECIMAL(10,2) DEFAULT NULL,
    `cost_price`      DECIMAL(10,2) DEFAULT NULL,
    `stock_count`     INT NOT NULL DEFAULT 0 COMMENT 'Import/Export inventory tracking',
    `low_stock_threshold` INT NOT NULL DEFAULT 5,
    `image`           VARCHAR(255) DEFAULT NULL,
    `gallery`         JSON DEFAULT NULL COMMENT 'Array of additional image paths',
    `weight`          DECIMAL(8,2) DEFAULT NULL COMMENT 'Weight in kg for shipping',
    `origin_country`  VARCHAR(100) DEFAULT NULL COMMENT 'Country of origin for import/export',
    `hs_code`         VARCHAR(20) DEFAULT NULL COMMENT 'Harmonized System code for customs',
    `is_featured`     TINYINT(1) NOT NULL DEFAULT 0,
    `is_active`       TINYINT(1) NOT NULL DEFAULT 1,
    `total_sold`      INT NOT NULL DEFAULT 0,
    `view_count`      INT NOT NULL DEFAULT 0,
    `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX `idx_products_category` (`category_id`),
    INDEX `idx_products_slug` (`slug`),
    INDEX `idx_products_sku` (`sku`),
    INDEX `idx_products_price` (`price`),
    INDEX `idx_products_stock` (`stock_count`),
    INDEX `idx_products_featured` (`is_featured`),
    INDEX `idx_products_active` (`is_active`),
    FULLTEXT `ft_products_search` (`name`, `description`, `short_desc`),

    CONSTRAINT `fk_products_category`
        FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- TABLE 4: orders
-- Customer orders with full tracking
-- ================================================================
CREATE TABLE `orders` (
    `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`           INT UNSIGNED NOT NULL,
    `order_number`      VARCHAR(50) NOT NULL UNIQUE,
    `status`            ENUM('pending','confirmed','processing','in_transit','delivered','cancelled','refunded')
                        NOT NULL DEFAULT 'pending',
    `payment_status`    ENUM('unpaid','pending_verification','paid','failed','refunded')
                        NOT NULL DEFAULT 'unpaid',
    `payment_method`    ENUM('chapa','santimpay','bank_transfer_cbe','bank_transfer_dashen','cash_on_delivery')
                        DEFAULT NULL,
    `payment_ref`       VARCHAR(255) DEFAULT NULL COMMENT 'Transaction ref from gateway',
    `receipt_image`     VARCHAR(255) DEFAULT NULL COMMENT 'Bank transfer screenshot path',

    `subtotal`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `tax_amount`        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `shipping_amount`   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `discount_amount`   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `total_amount`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,

    `shipping_first_name` VARCHAR(100) DEFAULT NULL,
    `shipping_last_name`  VARCHAR(100) DEFAULT NULL,
    `shipping_email`    VARCHAR(255) DEFAULT NULL,
    `shipping_phone`    VARCHAR(20) DEFAULT NULL,
    `shipping_address`  TEXT DEFAULT NULL,
    `shipping_city`     VARCHAR(100) DEFAULT NULL,
    `shipping_state`    VARCHAR(100) DEFAULT NULL,
    `shipping_zip`      VARCHAR(20) DEFAULT NULL,
    `shipping_country`  VARCHAR(100) DEFAULT 'Ethiopia',

    `notes`             TEXT DEFAULT NULL,
    `admin_notes`       TEXT DEFAULT NULL,
    `shipped_at`        DATETIME DEFAULT NULL,
    `delivered_at`      DATETIME DEFAULT NULL,
    `cancelled_at`      DATETIME DEFAULT NULL,
    `created_at`        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX `idx_orders_user` (`user_id`),
    INDEX `idx_orders_number` (`order_number`),
    INDEX `idx_orders_status` (`status`),
    INDEX `idx_orders_payment_status` (`payment_status`),
    INDEX `idx_orders_created` (`created_at`),

    CONSTRAINT `fk_orders_user`
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- TABLE 5: order_items
-- Line items for each order
-- ================================================================
CREATE TABLE `order_items` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `order_id`        INT UNSIGNED NOT NULL,
    `product_id`      INT UNSIGNED NOT NULL,
    `product_name`    VARCHAR(255) NOT NULL COMMENT 'Snapshot at time of order',
    `product_sku`     VARCHAR(50) NOT NULL COMMENT 'Snapshot at time of order',
    `product_image`   VARCHAR(255) DEFAULT NULL,
    `quantity`        INT UNSIGNED NOT NULL DEFAULT 1,
    `unit_price`      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total_price`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX `idx_oi_order` (`order_id`),
    INDEX `idx_oi_product` (`product_id`),

    CONSTRAINT `fk_oi_order`
        FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_oi_product`
        FOREIGN KEY (`product_id`) REFERENCES `products`(`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- TABLE 6: site_settings
-- Key-value store for global site configuration
-- ================================================================
CREATE TABLE `site_settings` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `setting_key`     VARCHAR(100) NOT NULL UNIQUE,
    `setting_value`   TEXT DEFAULT NULL,
    `setting_type`    ENUM('text','number','boolean','json','html') DEFAULT 'text',
    `setting_group`   VARCHAR(50) DEFAULT 'general',
    `description`     VARCHAR(255) DEFAULT NULL,
    `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX `idx_settings_key` (`setting_key`),
    INDEX `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- TABLE 7: payment_transactions
-- Detailed log of all payment attempts
-- ================================================================
CREATE TABLE `payment_transactions` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `order_id`        INT UNSIGNED NOT NULL,
    `user_id`         INT UNSIGNED NOT NULL,
    `gateway`         VARCHAR(50) NOT NULL COMMENT 'chapa, santimpay, manual_cbe, manual_dashen',
    `transaction_ref` VARCHAR(255) NOT NULL,
    `amount`          DECIMAL(12,2) NOT NULL,
    `currency`        VARCHAR(10) NOT NULL DEFAULT 'ETB',
    `status`          ENUM('initiated','pending','success','failed','cancelled','refunded')
                      NOT NULL DEFAULT 'initiated',
    `gateway_response` JSON DEFAULT NULL,
    `receipt_image`   VARCHAR(255) DEFAULT NULL,
    `verified_by`     INT UNSIGNED DEFAULT NULL COMMENT 'Admin who verified manual payment',
    `verified_at`     DATETIME DEFAULT NULL,
    `metadata`        JSON DEFAULT NULL,
    `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX `idx_pt_order` (`order_id`),
    INDEX `idx_pt_user` (`user_id`),
    INDEX `idx_pt_ref` (`transaction_ref`),
    INDEX `idx_pt_status` (`status`),

    CONSTRAINT `fk_pt_order`
        FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_pt_user`
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- DEFAULT DATA INSERTS
-- ================================================================

-- Default Admin User (password: Admin@123)
INSERT INTO `users` (`first_name`, `last_name`, `email`, `phone`, `password`, `role`, `email_verified`, `is_active`)
VALUES ('System', 'Admin', 'admin@stationeryshop.et', '+251911000000',
        '$2y$12$LJ3m4yPHBg0RNBZRhKjQOeSvDJMwLSM0yGp1B3xqzQIhNg/X.rVyW',
        'admin', 1, 1);

-- Default Site Settings
INSERT INTO `site_settings` (`setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`) VALUES
('site_name',           'Import & Export Full Pack Stationery', 'text',    'general', 'Website name'),
('site_tagline',        'Your One-Stop Shop for Quality Stationery', 'text', 'general', 'Site tagline'),
('site_email',          'info@stationeryshop.et',               'text',    'general', 'Contact email'),
('site_phone',          '+251-111-234567',                      'text',    'general', 'Contact phone'),
('site_address',        'Bole Sub City, Addis Ababa, Ethiopia', 'text',    'general', 'Physical address'),
('site_currency',       'ETB',                                  'text',    'general', 'Default currency'),
('site_currency_symbol','Br',                                   'text',    'general', 'Currency symbol (Birr)'),
('tax_rate',            '15',                                   'number',  'payment', 'Tax percentage (VAT)'),
('shipping_flat_rate',  '50.00',                                'number',  'payment', 'Flat shipping rate in ETB'),
('free_shipping_min',   '1000.00',                              'number',  'payment', 'Min order for free shipping'),
('chapa_secret_key',    '',                                     'text',    'payment', 'Chapa API secret key'),
('chapa_public_key',    '',                                     'text',    'payment', 'Chapa API public key'),
('santimpay_api_key',   '',                                     'text',    'payment', 'SantimPay API key'),
('santimpay_merchant_id','',                                    'text',    'payment', 'SantimPay merchant ID'),
('cbe_account_number',  '1000XXXXXXXXXX',                       'text',    'payment', 'CBE account number'),
('cbe_account_name',    'Import Export Stationery PLC',         'text',    'payment', 'CBE account holder name'),
('dashen_account_number','0XXXXXXXXXXX',                        'text',    'payment', 'Dashen Bank account number'),
('dashen_account_name', 'Import Export Stationery PLC',         'text',    'payment', 'Dashen account holder name'),
('enable_chapa',        '1',                                    'boolean', 'payment', 'Enable Chapa payment'),
('enable_santimpay',    '0',                                    'boolean', 'payment', 'Enable SantimPay payment'),
('enable_bank_transfer','1',                                    'boolean', 'payment', 'Enable manual bank transfer');

-- Default Categories
INSERT INTO `categories` (`name`, `slug`, `description`, `sort_order`, `is_active`) VALUES
('Writing Instruments',  'writing-instruments',  'Pens, pencils, markers, highlighters and more',     1, 1),
('Paper Products',       'paper-products',       'Notebooks, notepads, printing paper, envelopes',    2, 1),
('Filing & Storage',     'filing-storage',       'Folders, binders, file cabinets, organizers',       3, 1),
('Office Supplies',      'office-supplies',      'Staplers, tape, scissors, glue, clips',             4, 1),
('Art Supplies',         'art-supplies',          'Paints, brushes, canvases, sketch pads',           5, 1),
('Desk Accessories',     'desk-accessories',     'Desk organizers, pen holders, calendars',           6, 1),
('Printing & Tech',      'printing-tech',        'Ink cartridges, toner, USB drives, calculators',   7, 1),
('School Supplies',      'school-supplies',       'Backpacks, geometry sets, crayons, erasers',       8, 1);

-- Sample Products
INSERT INTO `products` (`category_id`, `name`, `slug`, `sku`, `description`, `short_desc`, `price`, `sale_price`, `cost_price`, `stock_count`, `origin_country`, `is_featured`, `is_active`) VALUES
(1, 'BIC Cristal Ballpoint Pen (Box of 50)', 'bic-cristal-ballpoint-50', 'WI-BIC-001',
   'Classic BIC Cristal medium point ballpoint pens. Smooth writing, long-lasting ink. Imported from France. Box contains 50 pens.',
   'Classic BIC ballpoint pen - Box of 50', 450.00, 399.00, 250.00, 500, 'France', 1, 1),
(1, 'Pilot G2 Gel Pen (Pack of 12)', 'pilot-g2-gel-12', 'WI-PLT-002',
   'Premium Pilot G2 retractable gel ink pens with comfortable rubber grip. Fine 0.7mm point. Imported from Japan.',
   'Premium gel pen - Pack of 12', 380.00, NULL, 200.00, 300, 'Japan', 1, 1),
(2, 'A4 Copy Paper - 80gsm (5 Reams)', 'a4-copy-paper-5-reams', 'PP-A4-001',
   'High quality A4 white copy paper. 80gsm weight, 500 sheets per ream. Bundle of 5 reams (2,500 sheets total).',
   'Premium A4 paper - 5 Reams bundle', 850.00, 799.00, 500.00, 1000, 'Indonesia', 1, 1),
(2, 'Hardcover Notebook A5 (Pack of 10)', 'hardcover-notebook-a5-10', 'PP-NB-002',
   'Professional hardcover notebooks, A5 size, 200 pages each, ruled. Pack of 10.',
   'A5 hardcover notebook - Pack of 10', 620.00, NULL, 350.00, 400, 'China', 0, 1),
(3, 'Lever Arch File A4 (Box of 20)', 'lever-arch-file-a4-20', 'FS-LAF-001',
   'Heavy-duty lever arch files. A4 size, 75mm spine. Assorted colors. Box of 20 files.',
   'A4 Lever arch files - Box of 20', 1200.00, 1099.00, 700.00, 200, 'China', 1, 1),
(4, 'Heavy Duty Stapler + 5000 Staples', 'heavy-duty-stapler-combo', 'OS-STP-001',
   'Industrial heavy-duty stapler capable of stapling up to 100 sheets. Comes with 5000 26/6 staples.',
   'Heavy duty stapler combo', 350.00, NULL, 180.00, 150, 'China', 0, 1),
(5, 'Faber-Castell Watercolor Set (48 Colors)', 'faber-castell-watercolor-48', 'AS-FC-001',
   'Premium Faber-Castell watercolor paint set with 48 vibrant colors. Includes mixing palette and 2 brushes.',
   'Professional watercolor set - 48 colors', 1500.00, 1350.00, 800.00, 100, 'Germany', 1, 1),
(8, 'Complete School Supply Kit - Grade 1-6', 'school-supply-kit-g1-6', 'SS-KIT-001',
   'All-in-one school supply kit. Includes exercise books, pencils, eraser, sharpener, ruler, crayons, and a school bag.',
   'Complete school supply kit', 950.00, 850.00, 500.00, 250, 'Mixed', 1, 1);