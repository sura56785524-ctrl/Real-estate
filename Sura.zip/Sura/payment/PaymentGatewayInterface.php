<?php
/**
 * ================================================================
 * Payment Gateway Interface
 * All payment gateways must implement this contract
 * ================================================================
 */

interface PaymentGatewayInterface
{
    /**
     * Initialize a payment transaction.
     * Returns ['checkout_url' => '...', 'tx_ref' => '...'] or throws exception.
     */
    public function initiate(array $orderData): array;

    /**
     * Verify a payment transaction.
     * Returns ['status' => 'success|failed', 'tx_ref' => '...', 'amount' => ...]
     */
    public function verify(string $transactionRef): array;

    /**
     * Get the gateway name.
     */
    public function getName(): string;
}