<?php
/**
 * ================================================================
 * Chapa Payment Gateway Integration
 * API Docs: https://developer.chapa.co/docs
 * ================================================================
 */

class ChapaGateway implements PaymentGatewayInterface
{
    private string $secretKey;
    private string $apiUrl;

    public function __construct()
    {
        $this->secretKey = CHAPA_SECRET_KEY;
        $this->apiUrl    = CHAPA_API_URL;
    }

    public function getName(): string
    {
        return 'Chapa';
    }

    /**
     * Initiate a payment with Chapa.
     */
    public function initiate(array $orderData): array
    {
        $txRef = 'CHAPA-' . $orderData['order_number'] . '-' . time();

        $payload = [
            'amount'       => (string) $orderData['total_amount'],
            'currency'     => 'ETB',
            'email'        => $orderData['email'],
            'first_name'   => $orderData['first_name'],
            'last_name'    => $orderData['last_name'],
            'phone_number' => $orderData['phone'] ?? '',
            'tx_ref'       => $txRef,
            'callback_url' => CHAPA_CALLBACK_URL . '&tx_ref=' . $txRef,
            'return_url'   => url('user/order-detail.php?id=' . $orderData['order_id']),
            'customization' => [
                'title'       => SITE_NAME,
                'description' => 'Payment for Order #' . $orderData['order_number'],
                'logo'        => logoUrl(),
            ],
        ];

        $response = $this->makeRequest('transaction/initialize', $payload);

        if (isset($response['status']) && $response['status'] === 'success') {
            return [
                'checkout_url' => $response['data']['checkout_url'],
                'tx_ref'       => $txRef,
            ];
        }

        throw new RuntimeException('Chapa Error: ' . ($response['message'] ?? 'Failed to initiate payment.'));
    }

    /**
     * Verify a Chapa transaction.
     */
    public function verify(string $transactionRef): array
    {
        $response = $this->makeRequest('transaction/verify/' . $transactionRef, null, 'GET');

        if (isset($response['status']) && $response['status'] === 'success') {
            $data = $response['data'];
            return [
                'status'  => ($data['status'] === 'success') ? 'success' : 'failed',
                'tx_ref'  => $data['tx_ref'] ?? $transactionRef,
                'amount'  => (float) ($data['amount'] ?? 0),
                'currency'=> $data['currency'] ?? 'ETB',
                'raw'     => $data,
            ];
        }

        return ['status' => 'failed', 'tx_ref' => $transactionRef, 'amount' => 0, 'raw' => $response];
    }

    /**
     * Make an HTTP request to the Chapa API.
     */
    private function makeRequest(string $endpoint, ?array $data = null, string $method = 'POST'): array
    {
        $url = $this->apiUrl . $endpoint;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $this->secretKey,
                'Content-Type: application/json',
            ],
        ]);

        if ($method === 'POST' && $data) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            error_log("Chapa cURL Error: {$error}");
            throw new RuntimeException('Payment gateway connection failed.');
        }

        curl_close($ch);

        $decoded = json_decode($response, true);
        return $decoded ?? ['status' => 'error', 'message' => 'Invalid response', 'http_code' => $httpCode];
    }
}