<?php
/**
 * ================================================================
 * SantimPay Payment Gateway Integration
 * ================================================================
 */

class SantimPayGateway implements PaymentGatewayInterface
{
    private string $apiKey;
    private string $merchantId;
    private string $apiUrl;

    public function __construct()
    {
        $this->apiKey     = SANTIMPAY_API_KEY;
        $this->merchantId = SANTIMPAY_MERCHANT_ID;
        $this->apiUrl     = SANTIMPAY_API_URL;
    }

    public function getName(): string
    {
        return 'SantimPay';
    }

    public function initiate(array $orderData): array
    {
        $txRef = 'SANTIM-' . $orderData['order_number'] . '-' . time();

        $payload = [
            'merchant_id' => $this->merchantId,
            'amount'      => (float) $orderData['total_amount'],
            'currency'    => 'ETB',
            'reason'      => 'Payment for Order #' . $orderData['order_number'],
            'reference'   => $txRef,
            'success_url' => url('user/order-detail.php?id=' . $orderData['order_id']),
            'cancel_url'  => url('cart.php'),
            'notify_url'  => SANTIMPAY_CALLBACK_URL . '&tx_ref=' . $txRef,
            'customer'    => [
                'name'  => $orderData['first_name'] . ' ' . $orderData['last_name'],
                'email' => $orderData['email'],
                'phone' => $orderData['phone'] ?? '',
            ],
        ];

        $response = $this->makeRequest('payments/initialize', $payload);

        if (!empty($response['checkout_url'])) {
            return [
                'checkout_url' => $response['checkout_url'],
                'tx_ref'       => $txRef,
            ];
        }

        throw new RuntimeException('SantimPay Error: ' . ($response['message'] ?? 'Failed to initiate payment.'));
    }

    public function verify(string $transactionRef): array
    {
        $response = $this->makeRequest('payments/verify/' . $transactionRef, null, 'GET');

        $status = ($response['status'] ?? '') === 'completed' ? 'success' : 'failed';

        return [
            'status'  => $status,
            'tx_ref'  => $transactionRef,
            'amount'  => (float) ($response['amount'] ?? 0),
            'currency'=> 'ETB',
            'raw'     => $response,
        ];
    }

    private function makeRequest(string $endpoint, ?array $data = null, string $method = 'POST'): array
    {
        $url = $this->apiUrl . $endpoint;
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $this->apiKey,
                'Content-Type: application/json',
            ],
        ]);

        if ($method === 'POST' && $data) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            curl_close($ch);
            throw new RuntimeException('SantimPay connection failed.');
        }
        curl_close($ch);

        return json_decode($response, true) ?? [];
    }
}