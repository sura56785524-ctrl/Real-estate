<?php
/**
 * ================================================================
 * Manual Bank Transfer Handler
 * Handles CBE and Dashen bank transfer payments
 * ================================================================
 */

class ManualTransfer
{
    /**
     * Get bank details for a specific bank.
     */
    public static function getBankDetails(string $bank): array
    {
        return match($bank) {
            'cbe', 'bank_transfer_cbe' => [
                'bank_name'      => 'Commercial Bank of Ethiopia (CBE)',
                'account_name'   => CBE_ACCOUNT_NAME,
                'account_number' => CBE_ACCOUNT_NUMBER,
                'instructions'   => [
                    'Transfer the exact order amount to the account above.',
                    'Use your Order Number as the transfer reference/note.',
                    'Take a screenshot of the payment confirmation.',
                    'Upload the screenshot in your order detail page.',
                    'Your order will be confirmed once we verify the payment.',
                ],
            ],
            'dashen', 'bank_transfer_dashen' => [
                'bank_name'      => 'Dashen Bank',
                'account_name'   => DASHEN_ACCOUNT_NAME,
                'account_number' => DASHEN_ACCOUNT_NUMBER,
                'instructions'   => [
                    'Transfer the exact order amount to the Dashen Bank account above.',
                    'Use your Order Number as the transfer reference.',
                    'Screenshot your payment receipt.',
                    'Upload the receipt screenshot on your order page.',
                    'Order will be processed after payment verification.',
                ],
            ],
            default => throw new RuntimeException('Invalid bank selection.'),
        };
    }

    /**
     * Log a manual transfer payment attempt.
     */
    public static function logTransaction(int $orderId, int $userId, string $bank, float $amount, ?string $receiptPath = null): int
    {
        $db = Database::getInstance();
        $txRef = 'MANUAL-' . strtoupper(substr($bank, -3)) . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(4));

        return $db->insert('payment_transactions', [
            'order_id'        => $orderId,
            'user_id'         => $userId,
            'gateway'         => 'manual_' . $bank,
            'transaction_ref' => $txRef,
            'amount'          => $amount,
            'currency'        => 'ETB',
            'status'          => $receiptPath ? 'pending' : 'initiated',
            'receipt_image'   => $receiptPath,
            'metadata'        => json_encode(['bank' => $bank, 'uploaded_at' => date('Y-m-d H:i:s')]),
        ]);
    }
}