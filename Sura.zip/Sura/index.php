<?php
/**
 * ================================================================
 * Homepage — Import & Export Full Pack Stationery
 * Features: Hero, featured products, categories, latest products
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';

$productModel  = new Product();
$categoryModel = new Category();

$featuredProducts = $productModel->getFeatured(8);
$latestProducts   = $productModel->getLatest(8);
$bestSellers      = $productModel->getBestSellers(4);
$categories       = $categoryModel->getNavCategories();

$pageTitle = SITE_NAME . ' — ' . SITE_TAGLINE;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= sanitize(SITE_TAGLINE) ?> - Premium stationery import & export in Ethiopia.">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>

    <!-- Flash Messages -->
    <div class="container mt-3"><?= renderFlash() ?></div>

    <!-- ══════════════════════════════════════════════════════════
         HERO SECTION
         ══════════════════════════════════════════════════════════ -->
    <section class="hero-section position-relative overflow-hidden"
             style="background: linear-gradient(135deg, #1b4332 0%, #2d6a4f 50%, #40916c 100%); min-height: 500px;">
        <div class="container py-5">
            <div class="row align-items-center min-vh-50">
                <div class="col-lg-6 text-white py-5">
                    <span class="badge bg-warning text-dark px-3 py-2 mb-3 fs-6">
                        <i class="bi bi-globe me-1"></i> Import & Export Quality Stationery
                    </span>
                    <h1 class="display-4 fw-bold mb-3">
                        Premium Stationery<br>
                        <span style="color:#b7e4c7;">Delivered to Your Door</span>
                    </h1>
                    <p class="lead mb-4" style="opacity:0.9;">
                        Discover thousands of quality stationery products imported from around the world.
                        Office supplies, school essentials, art materials — all at the best prices in Ethiopia.
                    </p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="<?= url('shop.php') ?>" class="btn btn-warning btn-lg px-4 fw-bold">
                            <i class="bi bi-bag me-2"></i> Shop Now
                        </a>
                        <a href="<?= url('shop.php?featured=1') ?>" class="btn btn-outline-light btn-lg px-4">
                            <i class="bi bi-star me-2"></i> Featured Items
                        </a>
                    </div>

                    <!-- Quick Stats -->
                    <div class="row mt-5 g-3">
                        <div class="col-4">
                            <div class="text-center">
                                <h3 class="fw-bold mb-0">500+</h3>
                                <small style="opacity:0.8;">Products</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="text-center">
                                <h3 class="fw-bold mb-0">50+</h3>
                                <small style="opacity:0.8;">Brands</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="text-center">
                                <h3 class="fw-bold mb-0">10K+</h3>
                                <small style="opacity:0.8;">Happy Customers</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 text-center d-none d-lg-block">
                    <img src="<?= logoUrl() ?>" alt="Stationery" class="img-fluid"
                         style="max-height: 400px; filter: drop-shadow(0 20px 40px rgba(0,0,0,0.3));">
                </div>
            </div>
        </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         FEATURES BAR
         ══════════════════════════════════════════════════════════ -->
    <section class="py-4 bg-light border-bottom">
        <div class="container">
            <div class="row g-3 text-center">
                <div class="col-6 col-md-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-truck fs-3 text-success"></i>
                        <div class="text-start">
                            <strong class="small d-block">Free Shipping</strong>
                            <small class="text-muted">Over <?= formatPrice(FREE_SHIPPING_MINIMUM) ?></small>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-shield-check fs-3 text-success"></i>
                        <div class="text-start">
                            <strong class="small d-block">Secure Payment</strong>
                            <small class="text-muted">Chapa & Bank Transfer</small>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-arrow-repeat fs-3 text-success"></i>
                        <div class="text-start">
                            <strong class="small d-block">Easy Returns</strong>
                            <small class="text-muted">30-day policy</small>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-headset fs-3 text-success"></i>
                        <div class="text-start">
                            <strong class="small d-block">24/7 Support</strong>
                            <small class="text-muted">Dedicated help</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         SHOP BY CATEGORY
         ══════════════════════════════════════════════════════════ -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-4">
                <h2 class="fw-bold">Shop by Category</h2>
                <p class="text-muted">Browse our wide selection of stationery categories</p>
            </div>
            <div class="row g-3">
                <?php
                $catIcons = ['bi-pen', 'bi-journal', 'bi-folder', 'bi-paperclip', 'bi-palette', 'bi-lamp', 'bi-printer', 'bi-backpack'];
                $catColors = ['#e8f5e9', '#e3f2fd', '#fff3e0', '#fce4ec', '#f3e5f5', '#e0f7fa', '#fff8e1', '#f1f8e9'];
                foreach ($categories as $i => $cat):
                    $icon = $catIcons[$i % count($catIcons)];
                    $bgColor = $catColors[$i % count($catColors)];
                ?>
                    <div class="col-6 col-md-3">
                        <a href="<?= url('shop.php?category=' . sanitize($cat['slug'])) ?>"
                           class="card border-0 shadow-sm h-100 text-decoration-none category-card"
                           style="transition: transform 0.3s;">
                            <div class="card-body text-center py-4">
                                <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3"
                                     style="width:60px;height:60px;background:<?= $bgColor ?>;">
                                    <i class="bi <?= $icon ?> fs-4" style="color:#2d6a4f;"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1"><?= sanitize($cat['name']) ?></h6>
                                <small class="text-muted"><?= (int) $cat['product_count'] ?> Products</small>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         FEATURED PRODUCTS
         ══════════════════════════════════════════════════════════ -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-0"><i class="bi bi-star-fill text-warning me-2"></i>Featured Products</h2>
                    <p class="text-muted mb-0">Handpicked quality stationery for you</p>
                </div>
                <a href="<?= url('shop.php?featured=1') ?>" class="btn btn-outline-success">
                    View All <i class="bi bi-arrow-right"></i>
                </a>
            </div>
            <div class="row g-4">
                <?php foreach ($featuredProducts as $product): ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <?php include INCLUDES_PATH . '../includes/product-card.php'; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         LATEST PRODUCTS
         ══════════════════════════════════════════════════════════ -->
    <section class="py-5">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-0"><i class="bi bi-clock-history text-primary me-2"></i>New Arrivals</h2>
                    <p class="text-muted mb-0">Fresh imports just landed</p>
                </div>
                <a href="<?= url('shop.php?sort=newest') ?>" class="btn btn-outline-primary">
                    View All <i class="bi bi-arrow-right"></i>
                </a>
            </div>
            <div class="row g-4">
                <?php foreach ($latestProducts as $product): ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <?php include INCLUDES_PATH . '../includes/product-card.php'; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         CTA BANNER
         ══════════════════════════════════════════════════════════ -->
    <section class="py-5" style="background: linear-gradient(135deg, #2d6a4f, #40916c);">
        <div class="container text-center text-white py-4">
            <h2 class="fw-bold mb-3">Bulk Orders? We've Got You Covered!</h2>
            <p class="lead mb-4" style="opacity:0.9;">
                Special wholesale pricing for schools, offices, and businesses.
                Contact us for custom quotes on large stationery orders.
            </p>
            <a href="mailto:info@stationeryshop.et" class="btn btn-warning btn-lg px-5 fw-bold">
                <i class="bi bi-envelope me-2"></i> Contact for Wholesale
            </a>
        </div>
    </section>

    <?php include INCLUDES_PATH . 'footer.php'; ?>
</body>
</html>