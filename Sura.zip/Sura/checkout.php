<?php
/**
 * ================================================================
 * Checkout Page — Shipping info, payment selection, place order
 * Features: Address form, payment method choice, order creation
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';

requireLogin();

$cart = new Cart();
if ($cart->isEmpty()) {
    setFlash('warning', 'Your cart is empty. Add some products before checkout.');
    redirect('shop.php');
}

// Validate cart
$issues = $cart->validate();
if (!empty($issues)) {
    foreach ($issues as $issue) {
        setFlash('warning', $issue);
    }
    redirect('cart.php');
}

$userModel = new User();
$user = $userModel->findById(currentUserId());
$summary = $cart->getSummary();
$errors = [];

// ── Handle Checkout Form Submission ────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token.';
    } else {
        // Collect shipping info
        $shippingData = [
            'first_name' => trim($_POST['shipping_first_name'] ?? ''),
            'last_name'  => trim($_POST['shipping_last_name'] ?? ''),
            'email'      => trim($_POST['shipping_email'] ?? ''),
            'phone'      => trim($_POST['shipping_phone'] ?? ''),
            'address'    => trim($_POST['shipping_address'] ?? ''),
            'city'       => trim($_POST['shipping_city'] ?? ''),
            'state'      => trim($_POST['shipping_state'] ?? ''),
            'zip'        => trim($_POST['shipping_zip'] ?? ''),
            'country'    => trim($_POST['shipping_country'] ?? 'Ethiopia'),
        ];
        $paymentMethod = $_POST['payment_method'] ?? '';
        $notes = trim($_POST['notes'] ?? '');

        // Validate
        if (empty($shippingData['first_name'])) $errors[] = 'First name is required.';
        if (empty($shippingData['last_name']))  $errors[] = 'Last name is required.';
        if (empty($shippingData['phone']))      $errors[] = 'Phone number is required.';
        if (empty($shippingData['address']))    $errors[] = 'Shipping address is required.';
        if (empty($shippingData['city']))       $errors[] = 'City is required.';
        if (empty($paymentMethod))              $errors[] = 'Please select a payment method.';

        $validMethods = ['chapa', 'santimpay', 'bank_transfer_cbe', 'bank_transfer_dashen'];
        if (!in_array($paymentMethod, $validMethods)) {
            $errors[] = 'Invalid payment method selected.';
        }

        if (empty($errors)) {
            try {
                $db = Database::getInstance();
                $productModel = new Product();

                $db->beginTransaction();

                // Create order
                $orderNumber = generateOrderNumber();
                $orderId = $db->insert('orders', [
                    'user_id'             => currentUserId(),
                    'order_number'        => $orderNumber,
                    'status'              => 'pending',
                    'payment_status'      => 'unpaid',
                    'payment_method'      => $paymentMethod,
                    'subtotal'            => $summary['subtotal'],
                    'tax_amount'          => $summary['tax_amount'],
                    'shipping_amount'     => $summary['shipping'],
                    'discount_amount'     => $summary['discount'],
                    'total_amount'        => $summary['grand_total'],
                    'shipping_first_name' => clean($shippingData['first_name']),
                    'shipping_last_name'  => clean($shippingData['last_name']),
                    'shipping_email'      => clean($shippingData['email']),
                    'shipping_phone'      => clean($shippingData['phone']),
                    'shipping_address'    => clean($shippingData['address']),
                    'shipping_city'       => clean($shippingData['city']),
                    'shipping_state'      => clean($shippingData['state']),
                    'shipping_zip'        => clean($shippingData['zip']),
                    'shipping_country'    => clean($shippingData['country']),
                    'notes'               => clean($notes),
                ]);

                // Create order items and reduce stock
                foreach ($cart->getItems() as $item) {
                    $db->insert('order_items', [
                        'order_id'      => $orderId,
                        'product_id'    => $item['product_id'],
                        'product_name'  => $item['name'],
                        'product_sku'   => $item['sku'],
                        'product_image' => $item['image'],
                        'quantity'      => $item['quantity'],
                        'unit_price'    => $item['price'],
                        'total_price'   => $item['price'] * $item['quantity'],
                    ]);

                    // Reduce stock
                    if (!$productModel->reduceStock($item['product_id'], $item['quantity'])) {
                        throw new RuntimeException("Insufficient stock for: {$item['name']}");
                    }
                }

                $db->commit();

                // Clear cart
                $cart->clear();

                // Handle payment redirect based on method
                if ($paymentMethod === 'chapa') {
                    $_SESSION['pending_order_id'] = $orderId;
                    redirect('payment-callback.php?gateway=chapa&action=initiate&order_id=' . $orderId);
                } elseif ($paymentMethod === 'santimpay') {
                    $_SESSION['pending_order_id'] = $orderId;
                    redirect('payment-callback.php?gateway=santimpay&action=initiate&order_id=' . $orderId);
                } else {
                    // Bank transfer — redirect to upload receipt page
                    setFlash('success', "Order #{$orderNumber} placed successfully! Please upload your bank transfer receipt.");
                    redirect('user/order-detail.php?id=' . $orderId . '&upload_receipt=1');
                }

            } catch (RuntimeException $e) {
                $db->rollBack();
                $errors[] = $e->getMessage();
            }
        }
    }
}

$pageTitle = 'Checkout — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>
    <div class="container mt-3"><?= renderFlash() ?></div>

    <!-- Breadcrumb -->
    <div class="bg-light py-3 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="<?= url() ?>" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('cart.php') ?>" class="text-decoration-none">Cart</a></li>
                    <li class="breadcrumb-item active">Checkout</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Checkout Steps -->
    <div class="container mt-4">
        <div class="d-flex justify-content-center gap-3 mb-4">
            <div class="text-center">
                <div class="rounded-circle bg-success text-white d-inline-flex align-items-center justify-content-center"
                     style="width:40px;height:40px;">
                    <i class="bi bi-cart-check"></i>
                </div>
                <div class="small mt-1 text-success fw-bold">Cart</div>
            </div>
            <div class="border-top mt-4" style="width:60px;border-color:#2d6a4f!important;border-width:2px!important;"></div>
            <div class="text-center">
                <div class="rounded-circle bg-success text-white d-inline-flex align-items-center justify-content-center"
                     style="width:40px;height:40px;">
                    <i class="bi bi-credit-card"></i>
                </div>
                <div class="small mt-1 text-success fw-bold">Checkout</div>
            </div>
            <div class="border-top mt-4" style="width:60px;border-color:#dee2e6!important;border-width:2px!important;"></div>
            <div class="text-center">
                <div class="rounded-circle bg-secondary text-white d-inline-flex align-items-center justify-content-center"
                     style="width:40px;height:40px;">
                    <i class="bi bi-check-lg"></i>
                </div>
                <div class="small mt-1 text-muted">Complete</div>
            </div>
        </div>
    </div>

    <section class="pb-5">
        <div class="container">
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle-fill me-1"></i>
                    <?php foreach ($errors as $e): ?>
                        <?= sanitize($e) ?><br>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" id="checkoutForm" novalidate>
                <?= csrfField() ?>

                <div class="row g-4">
                    <!-- Left: Shipping & Payment -->
                    <div class="col-lg-7">
                        <!-- Shipping Information -->
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white fw-bold">
                                <i class="bi bi-truck me-2"></i> Shipping Information
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold">First Name *</label>
                                        <input type="text" class="form-control" name="shipping_first_name"
                                               value="<?= sanitize($user['first_name'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold">Last Name *</label>
                                        <input type="text" class="form-control" name="shipping_last_name"
                                               value="<?= sanitize($user['last_name'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold">Email</label>
                                        <input type="email" class="form-control" name="shipping_email"
                                               value="<?= sanitize($user['email'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold">Phone *</label>
                                        <input type="tel" class="form-control" name="shipping_phone"
                                               value="<?= sanitize($user['phone'] ?? '') ?>" required
                                               placeholder="e.g., 0911234567">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label small fw-bold">Address *</label>
                                        <textarea class="form-control" name="shipping_address" rows="2" required
                                                  placeholder="Street address, building, floor..."><?= sanitize($user['address'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold">City *</label>
                                        <input type="text" class="form-control" name="shipping_city"
                                               value="<?= sanitize($user['city'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold">State/Region</label>
                                        <input type="text" class="form-control" name="shipping_state"
                                               value="<?= sanitize($user['state'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold">Country</label>
                                        <select class="form-select" name="shipping_country">
                                            <option value="Ethiopia" selected>Ethiopia</option>
                                            <option value="Kenya">Kenya</option>
                                            <option value="Djibouti">Djibouti</option>
                                            <option value="Somalia">Somalia</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label small fw-bold">Order Notes (optional)</label>
                                        <textarea class="form-control" name="notes" rows="2"
                                                  placeholder="Special delivery instructions, gift wrapping, etc."></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Payment Method -->
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white fw-bold">
                                <i class="bi bi-credit-card me-2"></i> Payment Method
                            </div>
                            <div class="card-body">
                                <!-- Chapa -->
                                <div class="form-check border rounded p-3 mb-3">
                                    <input class="form-check-input" type="radio" name="payment_method" id="payChapa"
                                           value="chapa" checked>
                                    <label class="form-check-label w-100" for="payChapa">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong class="text-success">Chapa</strong>
                                                <p class="mb-0 small text-muted">Pay with Telebirr, CBE Birr, Amole, Credit/Debit Card</p>
                                            </div>
                                            <span class="badge bg-success px-3 py-2"><i class="bi bi-shield-check me-1"></i>Secure</span>
                                        </div>
                                    </label>
                                </div>

                                <!-- SantimPay -->
                                <div class="form-check border rounded p-3 mb-3">
                                    <input class="form-check-input" type="radio" name="payment_method" id="paySantim"
                                           value="santimpay">
                                    <label class="form-check-label w-100" for="paySantim">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong class="text-primary">SantimPay</strong>
                                                <p class="mb-0 small text-muted">Pay with Ethiopian mobile banking and wallets</p>
                                            </div>
                                            <span class="badge bg-primary px-3 py-2"><i class="bi bi-phone me-1"></i>Mobile</span>
                                        </div>
                                    </label>
                                </div>

                                <!-- CBE Bank Transfer -->
                                <div class="form-check border rounded p-3 mb-3">
                                    <input class="form-check-input" type="radio" name="payment_method" id="payCBE"
                                           value="bank_transfer_cbe">
                                    <label class="form-check-label w-100" for="payCBE">
                                        <div>
                                            <strong class="text-info">Commercial Bank of Ethiopia (CBE)</strong>
                                            <p class="mb-0 small text-muted">Transfer to our CBE account and upload receipt</p>
                                        </div>
                                    </label>
                                    <div class="mt-2 p-2 bg-light rounded small d-none" id="cbeDetails">
                                        <strong>Account Name:</strong> <?= sanitize(CBE_ACCOUNT_NAME) ?><br>
                                        <strong>Account Number:</strong>
                                        <code class="user-select-all"><?= sanitize(CBE_ACCOUNT_NUMBER) ?></code><br>
                                        <small class="text-warning"><i class="bi bi-info-circle me-1"></i>Upload your receipt after placing the order.</small>
                                    </div>
                                </div>

                                <!-- Dashen Bank Transfer -->
                                <div class="form-check border rounded p-3">
                                    <input class="form-check-input" type="radio" name="payment_method" id="payDashen"
                                           value="bank_transfer_dashen">
                                    <label class="form-check-label w-100" for="payDashen">
                                        <div>
                                            <strong style="color:#8B4513;">Dashen Bank</strong>
                                            <p class="mb-0 small text-muted">Transfer to our Dashen account and upload receipt</p>
                                        </div>
                                    </label>
                                    <div class="mt-2 p-2 bg-light rounded small d-none" id="dashenDetails">
                                        <strong>Account Name:</strong> <?= sanitize(DASHEN_ACCOUNT_NAME) ?><br>
                                        <strong>Account Number:</strong>
                                        <code class="user-select-all"><?= sanitize(DASHEN_ACCOUNT_NUMBER) ?></code><br>
                                        <small class="text-warning"><i class="bi bi-info-circle me-1"></i>Upload your receipt after placing the order.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right: Order Summary -->
                    <div class="col-lg-5">
                        <div class="card border-0 shadow-sm sticky-top" style="top:80px;">
                            <div class="card-header bg-dark text-white fw-bold">
                                <i class="bi bi-receipt me-2"></i> Order Summary
                            </div>
                            <div class="card-body">
                                <!-- Cart Items List -->
                                <?php foreach ($summary['items'] as $item): ?>
                                    <div class="d-flex gap-3 mb-3 pb-3 border-bottom">
                                        <img src="<?= productImageUrl($item['image']) ?>"
                                             class="rounded" style="width:55px;height:55px;object-fit:cover;">
                                        <div class="flex-grow-1">
                                            <div class="small fw-bold"><?= sanitize(truncateText($item['name'], 35)) ?></div>
                                            <small class="text-muted">Qty: <?= $item['quantity'] ?> × <?= formatPrice($item['price']) ?></small>
                                        </div>
                                        <div class="fw-bold small"><?= formatPrice($item['price'] * $item['quantity']) ?></div>
                                    </div>
                                <?php endforeach; ?>

                                <!-- Totals -->
                                <div class="d-flex justify-content-between mb-2 small">
                                    <span>Subtotal</span>
                                    <span class="fw-bold"><?= formatPrice($summary['subtotal']) ?></span>
                                </div>
                                <?php if ($summary['discount'] > 0): ?>
                                    <div class="d-flex justify-content-between mb-2 small text-success">
                                        <span>Discount</span>
                                        <span>-<?= formatPrice($summary['discount']) ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="d-flex justify-content-between mb-2 small">
                                    <span>Shipping</span>
                                    <span><?= $summary['free_shipping'] ? '<span class="text-success">Free</span>' : formatPrice($summary['shipping']) ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2 small">
                                    <span>Tax (VAT <?= TAX_RATE ?>%)</span>
                                    <span><?= formatPrice($summary['tax_amount']) ?></span>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between mb-3">
                                    <span class="fs-5 fw-bold">Total</span>
                                    <span class="fs-5 fw-bold text-success"><?= formatPrice($summary['grand_total']) ?></span>
                                </div>

                                <button type="submit" class="btn btn-success btn-lg w-100 fw-bold" id="placeOrderBtn"
                                        style="background:#2d6a4f; border-color:#2d6a4f; border-radius:10px;">
                                    <span class="btn-text"><i class="bi bi-lock me-2"></i> Place Order — <?= formatPrice($summary['grand_total']) ?></span>
                                    <span class="spinner-border spinner-border-sm d-none" id="orderSpinner"></span>
                                </button>

                                <div class="text-center mt-3 small text-muted">
                                    <i class="bi bi-shield-lock me-1"></i>
                                    Your information is safe and encrypted
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>

    <?php include INCLUDES_PATH . 'footer.php'; ?>

    <script>
        // Show/hide bank details based on selected payment method
        document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
            radio.addEventListener('change', function() {
                document.getElementById('cbeDetails').classList.add('d-none');
                document.getElementById('dashenDetails').classList.add('d-none');
                if (this.value === 'bank_transfer_cbe') {
                    document.getElementById('cbeDetails').classList.remove('d-none');
                } else if (this.value === 'bank_transfer_dashen') {
                    document.getElementById('dashenDetails').classList.remove('d-none');
                }
            });
        });

        // Form submit spinner
        document.getElementById('checkoutForm').addEventListener('submit', function() {
            const btn = document.getElementById('placeOrderBtn');
            btn.disabled = true;
            btn.querySelector('.btn-text').textContent = ' Processing order...';
            btn.querySelector('#orderSpinner').classList.remove('d-none');
        });
    </script>
</body>
</html>