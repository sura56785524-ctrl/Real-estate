<?php
/**
 * ================================================================
 * Shop Page — Product Catalog with Advanced Filtering
 * Features: Category filter, price range, sorting, pagination
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';

$productModel  = new Product();
$categoryModel = new Category();

// ── Gather Filters from Query String ───────────────────────────
$filters = [
    'category_slug' => $_GET['category'] ?? '',
    'search'        => $_GET['search'] ?? '',
    'min_price'     => $_GET['min_price'] ?? '',
    'max_price'     => $_GET['max_price'] ?? '',
    'sort'          => $_GET['sort'] ?? 'newest',
    'in_stock'      => isset($_GET['in_stock']),
    'featured'      => isset($_GET['featured']),
];

$currentPage = max(1, (int) ($_GET['page'] ?? 1));

// Get catalog data
$catalog    = $productModel->getCatalog($filters, $currentPage);
$products   = $catalog['products'];
$pagination = $catalog['pagination'];

// Get sidebar data
$categories = $categoryModel->getNavCategories();
$priceRange = $productModel->getPriceRange();

// Determine active category for breadcrumb
$activeCategory = null;
if (!empty($filters['category_slug'])) {
    $activeCategory = $categoryModel->findBySlug($filters['category_slug']);
}

$pageTitle = $activeCategory
    ? sanitize($activeCategory['name']) . ' — ' . SITE_NAME
    : 'Shop — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>

    <div class="container mt-3"><?= renderFlash() ?></div>

    <!-- Breadcrumb -->
    <div class="bg-light py-3 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="<?= url() ?>" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item <?= !$activeCategory ? 'active' : '' ?>">
                        <a href="<?= url('shop.php') ?>" class="text-decoration-none">Shop</a>
                    </li>
                    <?php if ($activeCategory): ?>
                        <li class="breadcrumb-item active"><?= sanitize($activeCategory['name']) ?></li>
                    <?php endif; ?>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container py-4">
        <div class="row">
            <!-- ════════════════════════════════════════════════════
                 SIDEBAR FILTERS
                 ════════════════════════════════════════════════════ -->
            <div class="col-lg-3">
                <!-- Mobile Filter Toggle -->
                <button class="btn btn-outline-success w-100 d-lg-none mb-3" type="button"
                        data-bs-toggle="collapse" data-bs-target="#filterSidebar">
                    <i class="bi bi-funnel me-2"></i> Filters
                </button>

                <div class="collapse d-lg-block" id="filterSidebar">
                    <form method="GET" action="<?= url('shop.php') ?>" id="filterForm">
                        <!-- Preserve search if present -->
                        <?php if (!empty($filters['search'])): ?>
                            <input type="hidden" name="search" value="<?= sanitize($filters['search']) ?>">
                        <?php endif; ?>

                        <!-- Categories -->
                        <div class="card border-0 shadow-sm mb-3">
                            <div class="card-header bg-white fw-bold">
                                <i class="bi bi-grid me-1"></i> Categories
                            </div>
                            <div class="card-body p-0">
                                <div class="list-group list-group-flush">
                                    <a href="<?= url('shop.php') ?>"
                                       class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?= empty($filters['category_slug']) ? 'active' : '' ?>"
                                       style="<?= empty($filters['category_slug']) ? 'background:#2d6a4f;border-color:#2d6a4f;' : '' ?>">
                                        All Products
                                        <span class="badge <?= empty($filters['category_slug']) ? 'bg-light text-dark' : 'bg-secondary' ?> rounded-pill">
                                            <?= $pagination['total_items'] ?>
                                        </span>
                                    </a>
                                    <?php foreach ($categories as $cat): ?>
                                        <a href="<?= url('shop.php?category=' . sanitize($cat['slug'])) ?>"
                                           class="list-group-item list-group-item-action d-flex justify-content-between align-items-center small
                                                  <?= $filters['category_slug'] === $cat['slug'] ? 'active' : '' ?>"
                                           style="<?= $filters['category_slug'] === $cat['slug'] ? 'background:#2d6a4f;border-color:#2d6a4f;' : '' ?>">
                                            <?= sanitize($cat['name']) ?>
                                            <span class="badge <?= $filters['category_slug'] === $cat['slug'] ? 'bg-light text-dark' : 'bg-light text-dark' ?> rounded-pill">
                                                <?= (int) $cat['product_count'] ?>
                                            </span>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Price Range -->
                        <div class="card border-0 shadow-sm mb-3">
                            <div class="card-header bg-white fw-bold">
                                <i class="bi bi-currency-exchange me-1"></i> Price Range (<?= CURRENCY_SYMBOL ?>)
                            </div>
                            <div class="card-body">
                                <div class="row g-2">
                                    <div class="col-6">
                                        <input type="number" class="form-control form-control-sm" name="min_price"
                                               placeholder="Min" value="<?= sanitize($filters['min_price']) ?>"
                                               min="0" step="10">
                                    </div>
                                    <div class="col-6">
                                        <input type="number" class="form-control form-control-sm" name="max_price"
                                               placeholder="Max" value="<?= sanitize($filters['max_price']) ?>"
                                               min="0" step="10">
                                    </div>
                                </div>
                                <small class="text-muted mt-2 d-block">
                                    Range: <?= formatPrice($priceRange['min']) ?> — <?= formatPrice($priceRange['max']) ?>
                                </small>

                                <!-- Checkboxes -->
                                <div class="form-check mt-3">
                                    <input type="checkbox" class="form-check-input" name="in_stock" id="inStock"
                                           <?= $filters['in_stock'] ? 'checked' : '' ?>>
                                    <label class="form-check-label small" for="inStock">In Stock Only</label>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="featured" id="featuredOnly"
                                           <?= $filters['featured'] ? 'checked' : '' ?>>
                                    <label class="form-check-label small" for="featuredOnly">Featured Only</label>
                                </div>

                                <?php if (!empty($filters['category_slug'])): ?>
                                    <input type="hidden" name="category" value="<?= sanitize($filters['category_slug']) ?>">
                                <?php endif; ?>

                                <button type="submit" class="btn btn-success btn-sm w-100 mt-3"
                                        style="background:#2d6a4f;border-color:#2d6a4f;">
                                    <i class="bi bi-funnel me-1"></i> Apply Filters
                                </button>

                                <?php if (!empty($filters['min_price']) || !empty($filters['max_price']) || $filters['in_stock'] || $filters['featured']): ?>
                                    <a href="<?= url('shop.php' . (!empty($filters['category_slug']) ? '?category=' . sanitize($filters['category_slug']) : '')) ?>"
                                       class="btn btn-outline-secondary btn-sm w-100 mt-2">
                                        <i class="bi bi-x-circle me-1"></i> Clear Filters
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- ════════════════════════════════════════════════════
                 PRODUCTS GRID
                 ════════════════════════════════════════════════════ -->
            <div class="col-lg-9">
                <!-- Toolbar -->
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
                    <div>
                        <h5 class="fw-bold mb-0">
                            <?php if ($activeCategory): ?>
                                <?= sanitize($activeCategory['name']) ?>
                            <?php elseif (!empty($filters['search'])): ?>
                                Search: "<?= sanitize($filters['search']) ?>"
                            <?php else: ?>
                                All Products
                            <?php endif; ?>
                        </h5>
                        <small class="text-muted">
                            Showing <?= count($products) ?> of <?= $pagination['total_items'] ?> products
                        </small>
                    </div>

                    <!-- Sort Dropdown -->
                    <div class="d-flex align-items-center gap-2">
                        <label class="small text-muted text-nowrap">Sort by:</label>
                        <select class="form-select form-select-sm" id="sortSelect" style="width:auto;">
                            <option value="newest"     <?= $filters['sort'] === 'newest' ? 'selected' : '' ?>>Newest</option>
                            <option value="price_asc"  <?= $filters['sort'] === 'price_asc' ? 'selected' : '' ?>>Price: Low to High</option>
                            <option value="price_desc" <?= $filters['sort'] === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
                            <option value="name_asc"   <?= $filters['sort'] === 'name_asc' ? 'selected' : '' ?>>Name: A-Z</option>
                            <option value="name_desc"  <?= $filters['sort'] === 'name_desc' ? 'selected' : '' ?>>Name: Z-A</option>
                            <option value="popular"    <?= $filters['sort'] === 'popular' ? 'selected' : '' ?>>Most Popular</option>
                        </select>
                    </div>
                </div>

                <?php if (empty($products)): ?>
                    <!-- No Products Found -->
                    <div class="text-center py-5">
                        <i class="bi bi-search display-1 text-muted"></i>
                        <h4 class="mt-3 text-muted">No products found</h4>
                        <p class="text-muted">Try adjusting your search or filter criteria.</p>
                        <a href="<?= url('shop.php') ?>" class="btn btn-success" style="background:#2d6a4f;">
                            <i class="bi bi-arrow-left me-1"></i> Browse All Products
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Product Grid -->
                    <div class="row g-3" id="productGrid">
                        <?php foreach ($products as $product): ?>
                            <div class="col-6 col-md-4">
                                <?php include INCLUDES_PATH . '../includes/product-card.php'; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-4">
                        <?= renderPagination($pagination, 'shop.php', array_filter([
                            'category'  => $filters['category_slug'],
                            'search'    => $filters['search'],
                            'min_price' => $filters['min_price'],
                            'max_price' => $filters['max_price'],
                            'sort'      => $filters['sort'],
                            'in_stock'  => $filters['in_stock'] ? '1' : '',
                            'featured'  => $filters['featured'] ? '1' : '',
                        ])) ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include INCLUDES_PATH . 'footer.php'; ?>

    <script>
        // Sort change handler
        document.getElementById('sortSelect').addEventListener('change', function() {
            const url = new URL(window.location.href);
            url.searchParams.set('sort', this.value);
            url.searchParams.delete('page');
            window.location.href = url.toString();
        });
    </script>
</body>
</html>