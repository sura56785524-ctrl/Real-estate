<?php
/**
 * ================================================================
 * Shopping Cart Page — View, update, remove cart items
 * Features: Quantity update, remove items, cart summary, checkout
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';

$cart = new Cart();

// ── Handle Cart Actions (POST) ─────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action    = $_POST['action'] ?? '';
    $productId = (int) ($_POST['product_id'] ?? 0);
    $quantity  = (int) ($_POST['quantity'] ?? 1);

    // AJAX requests
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
        switch ($action) {
            case 'add':
                $result = $cart->add($productId, $quantity);
                jsonResponse($result);
                break;

            case 'update':
                $result = $cart->updateQuantity($productId, $quantity);
                $result['summary'] = $cart->getSummary();
                jsonResponse($result);
                break;

            case 'remove':
                $result = $cart->remove($productId);
                $result['summary'] = $cart->getSummary();
                jsonResponse($result);
                break;

            case 'clear':
                $cart->clear();
                jsonResponse(['success' => true, 'message' => 'Cart cleared.', 'summary' => $cart->getSummary()]);
                break;

            default:
                jsonResponse(['success' => false, 'message' => 'Invalid action.'], 400);
        }
    }

    // Non-AJAX POST fallback
    switch ($action) {
        case 'add':
            $cart->add($productId, $quantity);
            setFlash('success', 'Item added to cart.');
            break;
        case 'update':
            $cart->updateQuantity($productId, $quantity);
            setFlash('success', 'Cart updated.');
            break;
        case 'remove':
            $cart->remove($productId);
            setFlash('success', 'Item removed from cart.');
            break;
        case 'clear':
            $cart->clear();
            setFlash('success', 'Cart cleared.');
            break;
    }
    redirect('cart.php');
}

// Validate cart items (stock/price changes)
$cartIssues = $cart->validate();
foreach ($cartIssues as $issue) {
    setFlash('warning', $issue);
}

$cartItems  = $cart->getItems();
$summary    = $cart->getSummary();

$pageTitle = 'Shopping Cart — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>
    <div class="container mt-3"><?= renderFlash() ?></div>

    <!-- Breadcrumb -->
    <div class="bg-light py-3 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="<?= url() ?>" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('shop.php') ?>" class="text-decoration-none">Shop</a></li>
                    <li class="breadcrumb-item active">Shopping Cart</li>
                </ol>
            </nav>
        </div>
    </div>

    <section class="py-4">
        <div class="container">
            <h3 class="fw-bold mb-4">
                <i class="bi bi-cart3 me-2"></i>Shopping Cart
                <?php if (!$cart->isEmpty()): ?>
                    <span class="badge bg-success ms-2"><?= $summary['item_count'] ?> items</span>
                <?php endif; ?>
            </h3>

            <?php if ($cart->isEmpty()): ?>
                <!-- Empty Cart -->
                <div class="text-center py-5">
                    <i class="bi bi-cart-x display-1 text-muted"></i>
                    <h4 class="mt-3 text-muted">Your cart is empty</h4>
                    <p class="text-muted">Looks like you haven't added any products yet.</p>
                    <a href="<?= url('shop.php') ?>" class="btn btn-success btn-lg mt-2" style="background:#2d6a4f;">
                        <i class="bi bi-bag me-2"></i> Start Shopping
                    </a>
                </div>

            <?php else: ?>
                <div class="row g-4">
                    <!-- Cart Items -->
                    <div class="col-lg-8">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th class="ps-3" style="width:50%;">Product</th>
                                                <th class="text-center">Price</th>
                                                <th class="text-center">Qty</th>
                                                <th class="text-center">Total</th>
                                                <th class="text-center" style="width:50px;"></th>
                                            </tr>
                                        </thead>
                                        <tbody id="cartTableBody">
                                            <?php foreach ($cartItems as $item): ?>
                                                <tr class="cart-row" data-product-id="<?= $item['product_id'] ?>">
                                                    <!-- Product Info -->
                                                    <td class="ps-3">
                                                        <div class="d-flex align-items-center gap-3">
                                                            <img src="<?= productImageUrl($item['image']) ?>"
                                                                 alt="<?= sanitize($item['name']) ?>"
                                                                 class="rounded" style="width:70px;height:70px;object-fit:cover;">
                                                            <div>
                                                                <a href="<?= url('product-detail.php?id=' . $item['product_id']) ?>"
                                                                   class="fw-bold text-dark text-decoration-none small">
                                                                    <?= sanitize($item['name']) ?>
                                                                </a>
                                                                <br>
                                                                <small class="text-muted">SKU: <?= sanitize($item['sku']) ?></small>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <!-- Price -->
                                                    <td class="text-center">
                                                        <?php if ($item['price'] < $item['original_price']): ?>
                                                            <span class="fw-bold text-success small"><?= formatPrice($item['price']) ?></span>
                                                            <br><small class="text-muted text-decoration-line-through"><?= formatPrice($item['original_price']) ?></small>
                                                        <?php else: ?>
                                                            <span class="fw-bold small"><?= formatPrice($item['price']) ?></span>
                                                        <?php endif; ?>
                                                    </td>

                                                    <!-- Quantity -->
                                                    <td class="text-center">
                                                        <div class="input-group input-group-sm mx-auto" style="width:110px;">
                                                            <button class="btn btn-outline-secondary cart-qty-btn" data-action="decrease"
                                                                    data-product-id="<?= $item['product_id'] ?>">
                                                                <i class="bi bi-dash"></i>
                                                            </button>
                                                            <input type="number" class="form-control text-center cart-qty-input"
                                                                   value="<?= $item['quantity'] ?>" min="1" max="<?= $item['max_stock'] ?>"
                                                                   data-product-id="<?= $item['product_id'] ?>">
                                                            <button class="btn btn-outline-secondary cart-qty-btn" data-action="increase"
                                                                    data-product-id="<?= $item['product_id'] ?>">
                                                                <i class="bi bi-plus"></i>
                                                            </button>
                                                        </div>
                                                    </td>

                                                    <!-- Line Total -->
                                                    <td class="text-center">
                                                        <span class="fw-bold item-total" data-product-id="<?= $item['product_id'] ?>">
                                                            <?= formatPrice($item['price'] * $item['quantity']) ?>
                                                        </span>
                                                    </td>

                                                    <!-- Remove -->
                                                    <td class="text-center">
                                                        <button class="btn btn-sm btn-outline-danger border-0 cart-remove-btn"
                                                                data-product-id="<?= $item['product_id'] ?>"
                                                                title="Remove item">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- Cart Actions -->
                            <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                                <a href="<?= url('shop.php') ?>" class="btn btn-outline-success btn-sm">
                                    <i class="bi bi-arrow-left me-1"></i> Continue Shopping
                                </a>
                                <form method="POST" action="" class="d-inline">
                                    <input type="hidden" name="action" value="clear">
                                    <button type="submit" class="btn btn-outline-danger btn-sm"
                                            onclick="return confirm('Clear all items from your cart?');">
                                        <i class="bi bi-trash me-1"></i> Clear Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Order Summary -->
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm" id="cartSummary">
                            <div class="card-header bg-dark text-white fw-bold">
                                <i class="bi bi-receipt me-2"></i> Order Summary
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Subtotal (<span id="summaryItemCount"><?= $summary['item_count'] ?></span> items)</span>
                                    <span class="fw-bold" id="summarySubtotal"><?= formatPrice($summary['subtotal']) ?></span>
                                </div>

                                <?php if ($summary['discount'] > 0): ?>
                                    <div class="d-flex justify-content-between mb-2 text-success">
                                        <span><i class="bi bi-tag me-1"></i>Discount</span>
                                        <span id="summaryDiscount">-<?= formatPrice($summary['discount']) ?></span>
                                    </div>
                                <?php endif; ?>

                                <div class="d-flex justify-content-between mb-2">
                                    <span>Shipping</span>
                                    <span id="summaryShipping">
                                        <?= $summary['free_shipping'] ? '<span class="text-success">Free</span>' : formatPrice($summary['shipping']) ?>
                                    </span>
                                </div>

                                <?php if (!$summary['free_shipping']): ?>
                                    <small class="text-muted d-block mb-2">
                                        <i class="bi bi-info-circle me-1"></i>
                                        Add <?= formatPrice(FREE_SHIPPING_MINIMUM - $summary['subtotal']) ?> more for free shipping
                                    </small>
                                <?php endif; ?>

                                <div class="d-flex justify-content-between mb-2">
                                    <span>Tax (VAT <?= TAX_RATE ?>%)</span>
                                    <span id="summaryTax"><?= formatPrice($summary['tax_amount']) ?></span>
                                </div>

                                <hr>

                                <div class="d-flex justify-content-between mb-3">
                                    <span class="fs-5 fw-bold">Total</span>
                                    <span class="fs-5 fw-bold text-success" id="summaryTotal"><?= formatPrice($summary['grand_total']) ?></span>
                                </div>

                                <a href="<?= url('checkout.php') ?>"
                                   class="btn btn-success btn-lg w-100 fw-bold"
                                   style="background:#2d6a4f; border-color:#2d6a4f; border-radius:10px;">
                                    <i class="bi bi-lock me-2"></i> Proceed to Checkout
                                </a>

                                <div class="text-center mt-3">
                                    <small class="text-muted">
                                        <i class="bi bi-shield-check me-1"></i> Secure checkout with SSL encryption
                                    </small>
                                </div>

                                <!-- Payment Methods -->
                                <div class="mt-3 text-center">
                                    <small class="text-muted d-block mb-2">We accept:</small>
                                    <div class="d-flex justify-content-center gap-2">
                                        <span class="badge bg-success">Chapa</span>
                                        <span class="badge bg-primary">SantimPay</span>
                                        <span class="badge bg-info text-dark">CBE</span>
                                        <span class="badge bg-warning text-dark">Dashen</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include INCLUDES_PATH . 'footer.php'; ?>
</body>
</html>