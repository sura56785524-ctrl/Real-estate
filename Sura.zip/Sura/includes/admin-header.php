<?php
/**
 * Admin Page Header — top bar with mobile toggle and user info
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle ?? 'Admin') ?> — <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>

<?php include INCLUDES_PATH . 'admin-sidebar.php'; ?>

<div class="admin-content">
    <!-- Top Bar -->
    <div class="bg-white shadow-sm px-4 py-2 d-flex justify-content-between align-items-center sticky-top">
        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-sm btn-outline-secondary d-lg-none" onclick="document.getElementById('adminSidebar').classList.toggle('show');">
                <i class="bi bi-list"></i>
            </button>
            <h6 class="mb-0 fw-bold"><?= sanitize($pageTitle ?? 'Dashboard') ?></h6>
        </div>
        <div class="d-flex align-items-center gap-3">
            <a href="<?= url() ?>" class="btn btn-sm btn-outline-success" target="_blank">
                <i class="bi bi-shop me-1"></i>View Store
            </a>
            <div class="dropdown">
                <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
                    <div class="rounded-circle bg-dark text-white d-flex align-items-center justify-content-center me-2"
                         style="width:32px;height:32px;font-size:0.8rem;">
                        <?= strtoupper(mb_substr($_SESSION['user_first_name'] ?? 'A', 0, 1)) ?>
                    </div>
                    <span class="small d-none d-md-inline"><?= sanitize(currentUserName()) ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow">
                    <li><a class="dropdown-item" href="<?= url('user/profile.php') ?>"><i class="bi bi-person me-2"></i>Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="<?= url('auth/logout.php') ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Page Content Start -->
    <div class="p-4">
        <?= renderFlash() ?>