<?php
/**
 * ================================================================
 * Main Navigation Bar — Shared across all frontend pages
 * Features: Logo, categories dropdown, search, cart badge, auth
 * ================================================================
 */

// Load categories for the navigation dropdown
$navCategoryModel = new Category();
$navCategories = $navCategoryModel->getNavCategories();

// Cart count
$navCart = new Cart();
$cartItemCount = $navCart->getTotalItems();
$cartSubtotal = $navCart->getSubtotal();
?>

<!-- Top Info Bar -->
<div class="top-bar bg-dark text-white py-1">
    <div class="container d-flex justify-content-between align-items-center flex-wrap" style="font-size:0.8rem;">
        <div>
            <i class="bi bi-telephone me-1"></i> +251-111-234567
            <span class="mx-2">|</span>
            <i class="bi bi-envelope me-1"></i> info@stationeryshop.et
        </div>
        <div>
            <i class="bi bi-geo-alt me-1"></i> Bole Sub City, Addis Ababa, Ethiopia
            <span class="mx-2">|</span>
            <i class="bi bi-truck me-1"></i> Free shipping over <?= formatPrice(FREE_SHIPPING_MINIMUM) ?>
        </div>
    </div>
</div>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand d-flex align-items-center" href="<?= url() ?>">
            <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>"
                 height="45" class="me-2" style="object-fit: contain;">
            <div class="d-none d-md-block">
                <strong class="d-block" style="color:#1b4332; font-size:1rem; line-height:1.2;">
                    Import & Export
                </strong>
                <small class="text-muted" style="font-size:0.7rem;">Full Pack Stationery</small>
            </div>
        </a>

        <!-- Mobile Toggle -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Nav Content -->
        <div class="collapse navbar-collapse" id="mainNav">
            <!-- Search Bar (Center) -->
            <form class="d-flex mx-lg-4 my-2 my-lg-0 flex-grow-1" action="<?= url('shop.php') ?>" method="GET" role="search">
                <div class="input-group">
                    <input type="search" class="form-control" name="search"
                           placeholder="Search products, categories, brands..."
                           value="<?= sanitize($_GET['search'] ?? '') ?>"
                           style="border-radius: 8px 0 0 8px;">
                    <button class="btn btn-success px-3" type="submit" style="border-radius: 0 8px 8px 0; background:#2d6a4f; border-color:#2d6a4f;">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </form>

            <!-- Right Nav Items -->
            <ul class="navbar-nav ms-auto align-items-lg-center gap-1">
                <!-- Home -->
                <li class="nav-item">
                    <a class="nav-link" href="<?= url() ?>">
                        <i class="bi bi-house me-1"></i> Home
                    </a>
                </li>

                <!-- Categories Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-grid me-1"></i> Categories
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow border-0" style="min-width:280px;">
                        <li>
                            <a class="dropdown-item py-2" href="<?= url('shop.php') ?>">
                                <i class="bi bi-bag text-success me-2"></i>
                                <strong>All Products</strong>
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <?php foreach ($navCategories as $cat): ?>
                            <li>
                                <a class="dropdown-item py-2 d-flex justify-content-between align-items-center"
                                   href="<?= url('shop.php?category=' . sanitize($cat['slug'])) ?>">
                                    <span><i class="bi bi-folder2 text-muted me-2"></i><?= sanitize($cat['name']) ?></span>
                                    <span class="badge bg-light text-dark"><?= (int) $cat['product_count'] ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </li>

                <!-- Cart -->
                <li class="nav-item">
                    <a class="nav-link position-relative" href="<?= url('cart.php') ?>" id="navCartLink">
                        <i class="bi bi-cart3 fs-5"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
                              id="cartBadge" style="font-size:0.65rem; <?= $cartItemCount === 0 ? 'display:none;' : '' ?>">
                            <?= $cartItemCount ?>
                        </span>
                    </a>
                </li>

                <!-- Auth Links -->
                <?php if (isLoggedIn()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="dropdown">
                            <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center me-1"
                                 style="width:32px;height:32px;font-size:0.85rem;">
                                <?= strtoupper(mb_substr($_SESSION['user_first_name'] ?? 'U', 0, 1)) ?>
                            </div>
                            <span class="d-none d-lg-inline small"><?= sanitize($_SESSION['user_first_name'] ?? 'Account') ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                            <li class="dropdown-header">
                                <strong><?= sanitize(currentUserName()) ?></strong><br>
                                <small class="text-muted"><?= sanitize($_SESSION['user_email'] ?? '') ?></small>
                            </li>
                            <li><hr class="dropdown-divider"></li>

                            <?php if (isAdmin()): ?>
                                <li>
                                    <a class="dropdown-item" href="<?= url('admin/index.php') ?>">
                                        <i class="bi bi-speedometer2 me-2"></i> Admin Dashboard
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>

                            <li>
                                <a class="dropdown-item" href="<?= url('user/dashboard.php') ?>">
                                    <i class="bi bi-person me-2"></i> My Dashboard
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('user/orders.php') ?>">
                                    <i class="bi bi-box-seam me-2"></i> My Orders
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('user/profile.php') ?>">
                                    <i class="bi bi-gear me-2"></i> Settings
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="<?= url('auth/logout.php') ?>">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="btn btn-outline-success btn-sm ms-lg-2" href="<?= url('auth/login.php') ?>">
                            <i class="bi bi-box-arrow-in-right me-1"></i> Login
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-success btn-sm ms-1" href="<?= url('auth/register.php') ?>"
                           style="background:#2d6a4f; border-color:#2d6a4f;">
                            <i class="bi bi-person-plus me-1"></i> Register
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>