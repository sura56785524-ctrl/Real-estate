<?php
/**
 * ================================================================
 * Site Footer — Shared across all frontend pages
 * ================================================================
 */
?>

<!-- Footer -->
<footer class="bg-dark text-white pt-5 pb-3 mt-5">
    <div class="container">
        <div class="row g-4">
            <!-- Company Info -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center mb-3">
                    <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>" height="50" class="me-2"
                         style="filter: brightness(1.5);">
                    <div>
                        <strong class="d-block"><?= sanitize(SITE_NAME) ?></strong>
                        <small class="text-white-50"><?= sanitize(SITE_TAGLINE) ?></small>
                    </div>
                </div>
                <p class="text-white-50 small">
                    Your trusted partner for premium imported stationery, office supplies,
                    and school materials across Ethiopia and East Africa.
                </p>
                <div class="d-flex gap-2 mt-3">
                    <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width:36px;height:36px;">
                        <i class="bi bi-facebook"></i>
                    </a>
                    <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width:36px;height:36px;">
                        <i class="bi bi-telegram"></i>
                    </a>
                    <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width:36px;height:36px;">
                        <i class="bi bi-instagram"></i>
                    </a>
                    <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width:36px;height:36px;">
                        <i class="bi bi-tiktok"></i>
                    </a>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-2 col-md-6">
                <h6 class="fw-bold mb-3">Quick Links</h6>
                <ul class="list-unstyled small">
                    <li class="mb-2"><a href="<?= url() ?>" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right me-1"></i> Home</a></li>
                    <li class="mb-2"><a href="<?= url('shop.php') ?>" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right me-1"></i> Shop</a></li>
                    <li class="mb-2"><a href="<?= url('cart.php') ?>" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right me-1"></i> Cart</a></li>
                    <li class="mb-2"><a href="<?= url('auth/login.php') ?>" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right me-1"></i> My Account</a></li>
                </ul>
            </div>

            <!-- Categories -->
            <div class="col-lg-3 col-md-6">
                <h6 class="fw-bold mb-3">Categories</h6>
                <ul class="list-unstyled small">
                    <?php
                    $footerCats = (new Category())->getNavCategories();
                    foreach (array_slice($footerCats, 0, 6) as $fc):
                    ?>
                        <li class="mb-2">
                            <a href="<?= url('shop.php?category=' . sanitize($fc['slug'])) ?>"
                               class="text-white-50 text-decoration-none">
                                <i class="bi bi-chevron-right me-1"></i> <?= sanitize($fc['name']) ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Contact & Payment -->
            <div class="col-lg-3 col-md-6">
                <h6 class="fw-bold mb-3">Contact Us</h6>
                <ul class="list-unstyled small text-white-50">
                    <li class="mb-2"><i class="bi bi-geo-alt me-2 text-success"></i> Bole Sub City, Addis Ababa, Ethiopia</li>
                    <li class="mb-2"><i class="bi bi-telephone me-2 text-success"></i> +251-111-234567</li>
                    <li class="mb-2"><i class="bi bi-envelope me-2 text-success"></i> info@stationeryshop.et</li>
                    <li class="mb-2"><i class="bi bi-clock me-2 text-success"></i> Mon-Sat: 8:00 AM - 6:00 PM</li>
                </ul>

                <h6 class="fw-bold mb-2 mt-3">We Accept</h6>
                <div class="d-flex gap-2 flex-wrap">
                    <span class="badge bg-success">Chapa</span>
                    <span class="badge bg-primary">SantimPay</span>
                    <span class="badge bg-info text-dark">CBE Transfer</span>
                    <span class="badge bg-warning text-dark">Dashen Bank</span>
                </div>
            </div>
        </div>

        <hr class="my-4 border-secondary">

        <!-- Copyright -->
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <small class="text-white-50">
                    &copy; <?= date('Y') ?> <?= sanitize(SITE_NAME) ?>. All rights reserved.
                </small>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <small class="text-white-50">
                    Built with <i class="bi bi-heart-fill text-danger"></i> in Addis Ababa, Ethiopia
                </small>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->
<button onclick="window.scrollTo({top:0,behavior:'smooth'})"
        class="btn btn-success position-fixed rounded-circle shadow"
        id="backToTop"
        style="bottom:30px;right:30px;width:45px;height:45px;display:none;z-index:1000;background:#2d6a4f;border:none;">
    <i class="bi bi-arrow-up"></i>
</button>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<!-- Custom JS -->
<script src="<?= asset('js/cart.js') ?>"></script>
<script src="<?= asset('js/main.js') ?>"></script>