<?php
/**
 * ================================================================
 * Product Card Component — Reusable card for product listings
 * Expects $product array to be available in scope
 * ================================================================
 */
$pId        = (int) $product['id'];
$pName      = sanitize($product['name']);
$pSlug      = sanitize($product['slug']);
$pPrice     = (float) $product['price'];
$pSalePrice = !empty($product['sale_price']) ? (float) $product['sale_price'] : null;
$pEffective = (float) ($product['effective_price'] ?? ($pSalePrice ?? $pPrice));
$pDiscount  = (int) ($product['discount_percent'] ?? 0);
$pImage     = productImageUrl($product['image'] ?? null);
$pCategory  = sanitize($product['category_name'] ?? '');
$pStock     = (int) ($product['stock_count'] ?? 0);
?>

<div class="card border-0 shadow-sm h-100 product-card" style="border-radius:12px; overflow:hidden; transition: transform 0.3s, box-shadow 0.3s;">
    <!-- Image -->
    <a href="<?= url('product-detail.php?id=' . $pId) ?>" class="text-decoration-none position-relative">
        <img src="<?= $pImage ?>" alt="<?= $pName ?>"
             class="card-img-top" style="height:200px; object-fit:cover;">

        <?php if ($pDiscount > 0): ?>
            <span class="position-absolute top-0 start-0 m-2 badge bg-danger">
                -<?= $pDiscount ?>%
            </span>
        <?php endif; ?>

        <?php if ($pStock <= 0): ?>
            <div class="position-absolute top-0 end-0 bottom-0 start-0 d-flex align-items-center justify-content-center"
                 style="background:rgba(0,0,0,0.5);">
                <span class="badge bg-dark fs-6 px-3 py-2">Out of Stock</span>
            </div>
        <?php endif; ?>
    </a>

    <!-- Body -->
    <div class="card-body d-flex flex-column p-3">
        <!-- Category -->
        <?php if ($pCategory): ?>
            <small class="text-muted mb-1"><i class="bi bi-folder2 me-1"></i><?= $pCategory ?></small>
        <?php endif; ?>

        <!-- Name -->
        <h6 class="fw-bold mb-2" style="line-height:1.3;">
            <a href="<?= url('product-detail.php?id=' . $pId) ?>"
               class="text-dark text-decoration-none product-name">
                <?= truncateText($pName, 55) ?>
            </a>
        </h6>

        <!-- Price -->
        <div class="mt-auto">
            <?php if ($pSalePrice && $pSalePrice < $pPrice): ?>
                <div class="d-flex align-items-center gap-2">
                    <span class="fw-bold text-success fs-6"><?= formatPrice($pSalePrice) ?></span>
                    <small class="text-muted text-decoration-line-through"><?= formatPrice($pPrice) ?></small>
                </div>
            <?php else: ?>
                <span class="fw-bold text-success fs-6"><?= formatPrice($pPrice) ?></span>
            <?php endif; ?>

            <!-- Stock Indicator -->
            <?php if ($pStock > 0 && $pStock <= 5): ?>
                <small class="text-warning d-block mt-1"><i class="bi bi-exclamation-triangle me-1"></i>Only <?= $pStock ?> left!</small>
            <?php endif; ?>
        </div>

        <!-- Add to Cart Button -->
        <button class="btn btn-success btn-sm w-100 mt-2 add-to-cart-btn"
                data-product-id="<?= $pId ?>"
                <?= $pStock <= 0 ? 'disabled' : '' ?>
                style="background:#2d6a4f; border-color:#2d6a4f; border-radius:8px;">
            <i class="bi bi-cart-plus me-1"></i>
            <?= $pStock > 0 ? 'Add to Cart' : 'Out of Stock' ?>
        </button>
    </div>
</div>