<?php
/**
 * Admin Sidebar Navigation
 */
$currentPage = basename($_SERVER['PHP_SELF']);
$pendingPayments = (new Order())->getStats()['pending_payments'] ?? 0;
?>

<div class="admin-sidebar d-flex flex-column" id="adminSidebar">
    <!-- Logo -->
    <div class="p-3 text-center border-bottom border-secondary">
        <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>" height="45" class="mb-2" style="filter:brightness(1.5);">
        <div class="text-white small fw-bold">Admin Panel</div>
    </div>

    <!-- Navigation -->
    <nav class="flex-grow-1 p-2 overflow-auto">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'index.php' ? 'active' : '' ?>" href="<?= url('admin/index.php') ?>">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mt-2"><small class="text-white-50 px-3 text-uppercase" style="font-size:0.7rem;">Catalog</small></li>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'products.php' || $currentPage === 'product-form.php' ? 'active' : '' ?>"
                   href="<?= url('admin/products.php') ?>">
                    <i class="bi bi-box-seam me-2"></i> Products
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'categories.php' ? 'active' : '' ?>" href="<?= url('admin/categories.php') ?>">
                    <i class="bi bi-grid me-2"></i> Categories
                </a>
            </li>
            <li class="nav-item mt-2"><small class="text-white-50 px-3 text-uppercase" style="font-size:0.7rem;">Sales</small></li>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'orders.php' || $currentPage === 'order-detail.php' ? 'active' : '' ?>"
                   href="<?= url('admin/orders.php') ?>">
                    <i class="bi bi-cart-check me-2"></i> Orders
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'payments.php' ? 'active' : '' ?>" href="<?= url('admin/payments.php') ?>">
                    <i class="bi bi-credit-card me-2"></i> Payments
                    <?php if ($pendingPayments > 0): ?>
                        <span class="badge bg-warning text-dark float-end"><?= $pendingPayments ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item mt-2"><small class="text-white-50 px-3 text-uppercase" style="font-size:0.7rem;">Reports</small></li>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'reports.php' ? 'active' : '' ?>" href="<?= url('admin/reports.php') ?>">
                    <i class="bi bi-graph-up me-2"></i> Reports
                </a>
            </li>
            <li class="nav-item mt-2"><small class="text-white-50 px-3 text-uppercase" style="font-size:0.7rem;">System</small></li>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'users.php' ? 'active' : '' ?>" href="<?= url('admin/users.php') ?>">
                    <i class="bi bi-people me-2"></i> Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'settings.php' ? 'active' : '' ?>" href="<?= url('admin/settings.php') ?>">
                    <i class="bi bi-gear me-2"></i> Settings
                </a>
            </li>
        </ul>
    </nav>

    <!-- Footer -->
    <div class="p-3 border-top border-secondary">
        <a href="<?= url() ?>" class="nav-link text-white-50 small"><i class="bi bi-shop me-2"></i>View Store</a>
        <a href="<?= url('auth/logout.php') ?>" class="nav-link text-danger small"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
    </div>
</div>