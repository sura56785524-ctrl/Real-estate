<?php
/**
 * Admin Page Footer
 */
?>
    </div><!-- /p-4 -->

    <!-- Admin Footer -->
    <div class="px-4 py-3 bg-white border-top text-center small text-muted">
        &copy; <?= date('Y') ?> <?= sanitize(SITE_NAME) ?> — Admin Panel
    </div>
</div><!-- /admin-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</body>
</html>