<?php
/**
 * ================================================================
 * SiteSettings Class — Key-value store for configuration
 * ================================================================
 */

class SiteSettings
{
    private Database $db;
    private static array $cache = [];

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Get a setting value by key.
     */
    public function get(string $key, $default = null): mixed
    {
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $result = $this->db->fetchOne(
            "SELECT `setting_value`, `setting_type` FROM `site_settings` WHERE `setting_key` = ?",
            [$key]
        );

        if (!$result) return $default;

        $value = match($result['setting_type']) {
            'number'  => (float) $result['setting_value'],
            'boolean' => (bool) $result['setting_value'],
            'json'    => json_decode($result['setting_value'], true),
            default   => $result['setting_value'],
        };

        self::$cache[$key] = $value;
        return $value;
    }

    /**
     * Set a setting value.
     */
    public function set(string $key, mixed $value): void
    {
        $exists = $this->db->exists('site_settings', '`setting_key` = ?', [$key]);

        $storeValue = is_array($value) ? json_encode($value) : (string) $value;

        if ($exists) {
            $this->db->update('site_settings', ['setting_value' => $storeValue], '`setting_key` = ?', [$key]);
        } else {
            $this->db->insert('site_settings', [
                'setting_key'   => $key,
                'setting_value' => $storeValue,
                'setting_type'  => 'text',
                'setting_group' => 'general',
            ]);
        }

        self::$cache[$key] = $value;
    }

    /**
     * Get all settings.
     */
    public function getAll(): array
    {
        return $this->db->fetchAll("SELECT * FROM `site_settings` ORDER BY `setting_group`, `id`");
    }

    /**
     * Get settings by group.
     */
    public function getByGroup(string $group): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM `site_settings` WHERE `setting_group` = ? ORDER BY `id`",
            [$group]
        );
    }
}