<?php
/**
 * ================================================================
 * Order Class — OOP Model for Order Management
 * Handles order queries, creation, status updates, stats
 * ================================================================
 */

class Order
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Find order by ID.
     */
    public function findById(int $id): ?array
    {
        return $this->db->fetchOne(
            "SELECT o.*, u.first_name AS user_first_name, u.last_name AS user_last_name, u.email AS user_email
             FROM `orders` o
             LEFT JOIN `users` u ON u.id = o.user_id
             WHERE o.id = ? LIMIT 1",
            [$id]
        );
    }

    /**
     * Find order by order number.
     */
    public function findByOrderNumber(string $orderNumber): ?array
    {
        return $this->db->fetchOne(
            "SELECT o.*, u.first_name AS user_first_name, u.last_name AS user_last_name
             FROM `orders` o
             LEFT JOIN `users` u ON u.id = o.user_id
             WHERE o.order_number = ? LIMIT 1",
            [$orderNumber]
        );
    }

    /**
     * Get order items for a specific order.
     */
    public function getOrderItems(int $orderId): array
    {
        return $this->db->fetchAll(
            "SELECT oi.*, p.slug AS product_slug
             FROM `order_items` oi
             LEFT JOIN `products` p ON p.id = oi.product_id
             WHERE oi.order_id = ?
             ORDER BY oi.id ASC",
            [$orderId]
        );
    }

    /**
     * Get orders for a specific user with pagination.
     */
    public function getUserOrders(int $userId, int $page = 1, int $perPage = ORDERS_PER_PAGE, array $filters = []): array
    {
        $where = 'o.user_id = ?';
        $params = [$userId];

        if (!empty($filters['status'])) {
            $where .= ' AND o.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $where .= ' AND o.order_number LIKE ?';
            $params[] = '%' . $filters['search'] . '%';
        }

        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM `orders` o WHERE {$where}", $params
        );
        $pagination = paginate($total, $perPage, $page);

        $orders = $this->db->fetchAll(
            "SELECT o.* FROM `orders` o
             WHERE {$where}
             ORDER BY o.created_at DESC
             LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}",
            $params
        );

        return ['orders' => $orders, 'pagination' => $pagination];
    }

    /**
     * Get all orders for admin with pagination and filters.
     */
    public function getAllOrders(int $page = 1, int $perPage = ORDERS_PER_PAGE, array $filters = []): array
    {
        $where = '1=1';
        $params = [];

        if (!empty($filters['status'])) {
            $where .= ' AND o.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['payment_status'])) {
            $where .= ' AND o.payment_status = ?';
            $params[] = $filters['payment_status'];
        }
        if (!empty($filters['search'])) {
            $where .= ' AND (o.order_number LIKE ? OR o.shipping_first_name LIKE ? OR o.shipping_phone LIKE ?)';
            $s = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$s, $s, $s]);
        }
        if (!empty($filters['date_from'])) {
            $where .= ' AND DATE(o.created_at) >= ?';
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where .= ' AND DATE(o.created_at) <= ?';
            $params[] = $filters['date_to'];
        }

        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM `orders` o WHERE {$where}", $params
        );
        $pagination = paginate($total, $perPage, $page);

        $orders = $this->db->fetchAll(
            "SELECT o.*, u.first_name AS user_first_name, u.last_name AS user_last_name
             FROM `orders` o
             LEFT JOIN `users` u ON u.id = o.user_id
             WHERE {$where}
             ORDER BY o.created_at DESC
             LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}",
            $params
        );

        return ['orders' => $orders, 'pagination' => $pagination];
    }

    /**
     * Update order status.
     */
    public function updateStatus(int $orderId, string $status, ?string $adminNotes = null): bool
    {
        $data = ['status' => $status];

        switch ($status) {
            case 'in_transit':
                $data['shipped_at'] = date('Y-m-d H:i:s');
                break;
            case 'delivered':
                $data['delivered_at'] = date('Y-m-d H:i:s');
                break;
            case 'cancelled':
                $data['cancelled_at'] = date('Y-m-d H:i:s');
                $this->restoreOrderStock($orderId);
                break;
        }

        if ($adminNotes) {
            $data['admin_notes'] = clean($adminNotes);
        }

        return $this->db->update('orders', $data, '`id` = ?', [$orderId]) > 0;
    }

    /**
     * Update payment status.
     */
    public function updatePaymentStatus(int $orderId, string $status, ?string $paymentRef = null): bool
    {
        $data = ['payment_status' => $status];
        if ($paymentRef) {
            $data['payment_ref'] = $paymentRef;
        }
        return $this->db->update('orders', $data, '`id` = ?', [$orderId]) > 0;
    }

    /**
     * Upload receipt image for bank transfer orders.
     */
    public function uploadReceipt(int $orderId, string $imagePath): bool
    {
        return $this->db->update('orders', [
            'receipt_image'  => $imagePath,
            'payment_status' => 'pending_verification',
        ], '`id` = ?', [$orderId]) > 0;
    }

    /**
     * Restore stock for a cancelled order.
     */
    private function restoreOrderStock(int $orderId): void
    {
        $items = $this->getOrderItems($orderId);
        $productModel = new Product();
        foreach ($items as $item) {
            $productModel->restoreStock((int) $item['product_id'], (int) $item['quantity']);
        }
    }

    /**
     * Get order statistics for dashboards.
     */
    public function getStats(?int $userId = null): array
    {
        $where = $userId ? "user_id = {$userId}" : '1=1';

        return [
            'total_orders'    => $this->db->count('orders', $where),
            'pending'         => $this->db->count('orders', "{$where} AND status = 'pending'"),
            'processing'      => $this->db->count('orders', "{$where} AND status = 'processing'"),
            'in_transit'      => $this->db->count('orders', "{$where} AND status = 'in_transit'"),
            'delivered'       => $this->db->count('orders', "{$where} AND status = 'delivered'"),
            'cancelled'       => $this->db->count('orders', "{$where} AND status = 'cancelled'"),
            'total_revenue'   => (float) ($this->db->fetchColumn(
                "SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE {$where} AND payment_status = 'paid'"
            ) ?? 0),
            'today_orders'    => $this->db->count('orders', "{$where} AND DATE(created_at) = CURDATE()"),
            'month_orders'    => $this->db->count('orders', "{$where} AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)"),
            'today_revenue'   => (float) ($this->db->fetchColumn(
                "SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE {$where} AND payment_status = 'paid' AND DATE(created_at) = CURDATE()"
            ) ?? 0),
            'month_revenue'   => (float) ($this->db->fetchColumn(
                "SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE {$where} AND payment_status = 'paid' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)"
            ) ?? 0),
            'pending_payments' => $this->db->count('orders', "{$where} AND payment_status = 'pending_verification'"),
        ];
    }

    /**
     * Get recent orders.
     */
    public function getRecent(int $limit = 5, ?int $userId = null): array
    {
        $where = $userId ? 'o.user_id = ?' : '1=1';
        $params = $userId ? [$userId] : [];

        return $this->db->fetchAll(
            "SELECT o.*, u.first_name AS user_first_name, u.last_name AS user_last_name
             FROM `orders` o
             LEFT JOIN `users` u ON u.id = o.user_id
             WHERE {$where}
             ORDER BY o.created_at DESC
             LIMIT ?",
            array_merge($params, [$limit])
        );
    }

    /**
     * Get monthly sales data for charts (last 12 months).
     */
    public function getMonthlySales(): array
    {
        return $this->db->fetchAll(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month,
                    COUNT(*) AS order_count,
                    COALESCE(SUM(total_amount), 0) AS revenue
             FROM `orders`
             WHERE payment_status = 'paid' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
             GROUP BY month
             ORDER BY month ASC"
        );
    }

    /**
     * Get top-selling products.
     */
    public function getTopProducts(int $limit = 10): array
    {
        return $this->db->fetchAll(
            "SELECT oi.product_id, oi.product_name, oi.product_image,
                    SUM(oi.quantity) AS total_qty,
                    SUM(oi.total_price) AS total_revenue,
                    COUNT(DISTINCT oi.order_id) AS order_count
             FROM `order_items` oi
             JOIN `orders` o ON o.id = oi.order_id AND o.payment_status = 'paid'
             GROUP BY oi.product_id, oi.product_name, oi.product_image
             ORDER BY total_qty DESC
             LIMIT ?",
            [$limit]
        );
    }
}