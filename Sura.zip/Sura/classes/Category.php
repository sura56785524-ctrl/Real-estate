<?php
/**
 * ================================================================
 * Category Class — OOP Model for Product Categories
 * Handles CRUD, hierarchy, and category queries
 * ================================================================
 */

class Category
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Get all active categories.
     */
    public function getAll(bool $activeOnly = true): array
    {
        $where = $activeOnly ? 'WHERE `is_active` = 1' : '';
        return $this->db->fetchAll(
            "SELECT c.*, 
                    (SELECT COUNT(*) FROM `products` p WHERE p.category_id = c.id AND p.is_active = 1) AS product_count
             FROM `categories` c
             {$where}
             ORDER BY c.sort_order ASC, c.name ASC"
        );
    }

    /**
     * Get a single category by ID.
     */
    public function findById(int $id): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM `categories` WHERE `id` = ? LIMIT 1",
            [$id]
        );
    }

    /**
     * Get a single category by slug.
     */
    public function findBySlug(string $slug): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM `categories` WHERE `slug` = ? AND `is_active` = 1 LIMIT 1",
            [$slug]
        );
    }

    /**
     * Create a new category.
     */
    public function create(array $data): int
    {
        return $this->db->insert('categories', [
            'parent_id'   => $data['parent_id'] ?: null,
            'name'        => clean($data['name']),
            'slug'        => createSlug($data['name']),
            'description' => clean($data['description'] ?? ''),
            'image'       => $data['image'] ?? null,
            'sort_order'  => (int) ($data['sort_order'] ?? 0),
            'is_active'   => (int) ($data['is_active'] ?? 1),
        ]);
    }

    /**
     * Update an existing category.
     */
    public function update(int $id, array $data): bool
    {
        $updateData = [];
        $allowed = ['name', 'description', 'image', 'sort_order', 'is_active', 'parent_id'];

        foreach ($allowed as $field) {
            if (array_key_exists($field, $data)) {
                $updateData[$field] = ($field === 'name' || $field === 'description')
                    ? clean($data[$field])
                    : $data[$field];
            }
        }

        if (isset($updateData['name'])) {
            $updateData['slug'] = createSlug($updateData['name']);
        }

        return $this->db->update('categories', $updateData, '`id` = ?', [$id]) > 0;
    }

    /**
     * Delete a category (only if no products are linked).
     */
    public function delete(int $id): bool
    {
        $productCount = $this->db->count('products', '`category_id` = ?', [$id]);
        if ($productCount > 0) {
            throw new RuntimeException("Cannot delete category: {$productCount} products are linked to it.");
        }
        return $this->db->delete('categories', '`id` = ?', [$id]) > 0;
    }

    /**
     * Get categories for navigation dropdown (with product counts).
     */
    public function getNavCategories(): array
    {
        return $this->db->fetchAll(
            "SELECT c.id, c.name, c.slug, c.image,
                    COUNT(p.id) AS product_count
             FROM `categories` c
             LEFT JOIN `products` p ON p.category_id = c.id AND p.is_active = 1
             WHERE c.is_active = 1
             GROUP BY c.id
             ORDER BY c.sort_order ASC, c.name ASC"
        );
    }

    /**
     * Get category statistics for admin.
     */
    public function getStats(): array
    {
        return [
            'total'    => $this->db->count('categories'),
            'active'   => $this->db->count('categories', '`is_active` = 1'),
            'inactive' => $this->db->count('categories', '`is_active` = 0'),
        ];
    }
}