<?php
/**
 * ================================================================
 * Cart Class — Session-Based Shopping Cart
 * Manages cart items, quantities, totals, and shipping
 * ================================================================
 */

class Cart
{
    private const SESSION_KEY = 'shopping_cart';
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
        if (!isset($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = [];
        }
    }

    /**
     * Add a product to the cart.
     */
    public function add(int $productId, int $quantity = 1): array
    {
        if ($quantity < 1) $quantity = 1;

        // Verify product exists and is active
        $product = $this->db->fetchOne(
            "SELECT `id`, `name`, `price`, `sale_price`, `stock_count`, `image`, `sku`, `weight`
             FROM `products`
             WHERE `id` = ? AND `is_active` = 1
             LIMIT 1",
            [$productId]
        );

        if (!$product) {
            return ['success' => false, 'message' => 'Product not found.'];
        }

        $effectivePrice = $product['sale_price'] ?? $product['price'];
        $currentQty = $_SESSION[self::SESSION_KEY][$productId]['quantity'] ?? 0;
        $newQty = $currentQty + $quantity;

        // Check stock
        if ($newQty > $product['stock_count']) {
            return [
                'success' => false,
                'message' => "Only {$product['stock_count']} items available in stock."
            ];
        }

        // Add/update cart item
        $_SESSION[self::SESSION_KEY][$productId] = [
            'product_id' => $productId,
            'name'       => $product['name'],
            'price'      => (float) $effectivePrice,
            'original_price' => (float) $product['price'],
            'image'      => $product['image'],
            'sku'        => $product['sku'],
            'weight'     => (float) ($product['weight'] ?? 0),
            'quantity'   => $newQty,
            'max_stock'  => (int) $product['stock_count'],
        ];

        return [
            'success'    => true,
            'message'    => "{$product['name']} added to cart.",
            'cart_count' => $this->getTotalItems(),
            'cart_total' => $this->getSubtotal(),
        ];
    }

    /**
     * Update the quantity of a cart item.
     */
    public function updateQuantity(int $productId, int $quantity): array
    {
        if (!isset($_SESSION[self::SESSION_KEY][$productId])) {
            return ['success' => false, 'message' => 'Product not in cart.'];
        }

        if ($quantity <= 0) {
            return $this->remove($productId);
        }

        // Re-check stock
        $stock = $this->db->fetchColumn(
            "SELECT `stock_count` FROM `products` WHERE `id` = ?", [$productId]
        );

        if ($quantity > (int) $stock) {
            return ['success' => false, 'message' => "Only {$stock} items available."];
        }

        $_SESSION[self::SESSION_KEY][$productId]['quantity'] = $quantity;

        return [
            'success'    => true,
            'message'    => 'Cart updated.',
            'cart_count' => $this->getTotalItems(),
            'cart_total' => $this->getSubtotal(),
        ];
    }

    /**
     * Remove a product from the cart.
     */
    public function remove(int $productId): array
    {
        $name = $_SESSION[self::SESSION_KEY][$productId]['name'] ?? 'Item';
        unset($_SESSION[self::SESSION_KEY][$productId]);

        return [
            'success'    => true,
            'message'    => "{$name} removed from cart.",
            'cart_count' => $this->getTotalItems(),
            'cart_total' => $this->getSubtotal(),
        ];
    }

    /**
     * Clear the entire cart.
     */
    public function clear(): void
    {
        $_SESSION[self::SESSION_KEY] = [];
    }

    /**
     * Get all cart items.
     */
    public function getItems(): array
    {
        return $_SESSION[self::SESSION_KEY] ?? [];
    }

    /**
     * Get total number of items in cart.
     */
    public function getTotalItems(): int
    {
        $total = 0;
        foreach ($_SESSION[self::SESSION_KEY] as $item) {
            $total += $item['quantity'];
        }
        return $total;
    }

    /**
     * Get cart subtotal (before tax and shipping).
     */
    public function getSubtotal(): float
    {
        $subtotal = 0;
        foreach ($_SESSION[self::SESSION_KEY] as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }
        return round($subtotal, 2);
    }

    /**
     * Calculate tax amount.
     */
    public function getTax(): float
    {
        return round($this->getSubtotal() * (TAX_RATE / 100), 2);
    }

    /**
     * Calculate shipping cost.
     */
    public function getShipping(): float
    {
        if ($this->isEmpty()) return 0;
        if ($this->getSubtotal() >= FREE_SHIPPING_MINIMUM) return 0;
        return SHIPPING_FLAT_RATE;
    }

    /**
     * Get total weight of items.
     */
    public function getTotalWeight(): float
    {
        $weight = 0;
        foreach ($_SESSION[self::SESSION_KEY] as $item) {
            $weight += ($item['weight'] ?? 0) * $item['quantity'];
        }
        return round($weight, 2);
    }

    /**
     * Calculate total discount.
     */
    public function getTotalDiscount(): float
    {
        $discount = 0;
        foreach ($_SESSION[self::SESSION_KEY] as $item) {
            if ($item['price'] < $item['original_price']) {
                $discount += ($item['original_price'] - $item['price']) * $item['quantity'];
            }
        }
        return round($discount, 2);
    }

    /**
     * Get grand total (subtotal + tax + shipping).
     */
    public function getGrandTotal(): float
    {
        return round($this->getSubtotal() + $this->getTax() + $this->getShipping(), 2);
    }

    /**
     * Check if the cart is empty.
     */
    public function isEmpty(): bool
    {
        return empty($_SESSION[self::SESSION_KEY]);
    }

    /**
     * Get a complete cart summary.
     */
    public function getSummary(): array
    {
        return [
            'items'          => $this->getItems(),
            'item_count'     => $this->getTotalItems(),
            'subtotal'       => $this->getSubtotal(),
            'discount'       => $this->getTotalDiscount(),
            'tax_rate'       => TAX_RATE,
            'tax_amount'     => $this->getTax(),
            'shipping'       => $this->getShipping(),
            'free_shipping'  => $this->getSubtotal() >= FREE_SHIPPING_MINIMUM,
            'grand_total'    => $this->getGrandTotal(),
            'total_weight'   => $this->getTotalWeight(),
        ];
    }

    /**
     * Validate all cart items still exist and have stock.
     */
    public function validate(): array
    {
        $issues = [];

        foreach ($_SESSION[self::SESSION_KEY] as $productId => $item) {
            $product = $this->db->fetchOne(
                "SELECT `id`, `name`, `stock_count`, `is_active`,
                        COALESCE(`sale_price`, `price`) AS current_price
                 FROM `products` WHERE `id` = ?",
                [$productId]
            );

            if (!$product || !$product['is_active']) {
                unset($_SESSION[self::SESSION_KEY][$productId]);
                $issues[] = "{$item['name']} is no longer available and was removed.";
                continue;
            }

            if ($item['quantity'] > $product['stock_count']) {
                if ($product['stock_count'] <= 0) {
                    unset($_SESSION[self::SESSION_KEY][$productId]);
                    $issues[] = "{$item['name']} is out of stock and was removed.";
                } else {
                    $_SESSION[self::SESSION_KEY][$productId]['quantity'] = $product['stock_count'];
                    $issues[] = "{$item['name']} quantity adjusted to {$product['stock_count']} (stock limit).";
                }
            }

            // Update price if changed
            if ((float) $product['current_price'] !== $item['price']) {
                $_SESSION[self::SESSION_KEY][$productId]['price'] = (float) $product['current_price'];
                $issues[] = "Price for {$item['name']} has been updated.";
            }
        }

        return $issues;
    }
}