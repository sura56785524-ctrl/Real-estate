<?php
/**
 * ================================================================
 * Report Class — Sales reporting and data export
 * ================================================================
 */

class Report
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Get sales report data for a date range.
     */
    public function getSalesReport(string $dateFrom, string $dateTo): array
    {
        return $this->db->fetchAll(
            "SELECT o.order_number, o.total_amount, o.status, o.payment_status,
                    o.payment_method, o.created_at,
                    CONCAT(u.first_name, ' ', u.last_name) AS customer_name,
                    u.email AS customer_email
             FROM `orders` o
             LEFT JOIN `users` u ON u.id = o.user_id
             WHERE DATE(o.created_at) BETWEEN ? AND ?
             ORDER BY o.created_at DESC",
            [$dateFrom, $dateTo]
        );
    }

    /**
     * Get revenue by category.
     */
    public function getRevenueByCategory(): array
    {
        return $this->db->fetchAll(
            "SELECT c.name AS category_name,
                    COUNT(DISTINCT oi.order_id) AS order_count,
                    SUM(oi.quantity) AS items_sold,
                    SUM(oi.total_price) AS revenue
             FROM `order_items` oi
             JOIN `orders` o ON o.id = oi.order_id AND o.payment_status = 'paid'
             JOIN `products` p ON p.id = oi.product_id
             JOIN `categories` c ON c.id = p.category_id
             GROUP BY c.id, c.name
             ORDER BY revenue DESC"
        );
    }

    /**
     * Get daily revenue for a date range.
     */
    public function getDailyRevenue(string $dateFrom, string $dateTo): array
    {
        return $this->db->fetchAll(
            "SELECT DATE(created_at) AS date,
                    COUNT(*) AS order_count,
                    SUM(total_amount) AS revenue
             FROM `orders`
             WHERE payment_status = 'paid'
               AND DATE(created_at) BETWEEN ? AND ?
             GROUP BY DATE(created_at)
             ORDER BY date ASC",
            [$dateFrom, $dateTo]
        );
    }

    /**
     * Get inventory valuation report.
     */
    public function getInventoryReport(): array
    {
        return $this->db->fetchAll(
            "SELECT p.name, p.sku, p.stock_count, p.cost_price, p.price,
                    (p.stock_count * COALESCE(p.cost_price, 0)) AS stock_value,
                    c.name AS category_name, p.origin_country
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.is_active = 1
             ORDER BY stock_value DESC"
        );
    }

    /**
     * Get payment method distribution.
     */
    public function getPaymentMethodStats(): array
    {
        return $this->db->fetchAll(
            "SELECT payment_method,
                    COUNT(*) AS count,
                    SUM(total_amount) AS total
             FROM `orders`
             WHERE payment_status = 'paid'
             GROUP BY payment_method
             ORDER BY total DESC"
        );
    }
}