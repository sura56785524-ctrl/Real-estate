<?php
/**
 * ================================================================
 * Product Class — OOP Model for Product Management
 * Handles catalog queries, search, filters, CRUD, stock tracking
 * ================================================================
 */

class Product
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── CATALOG QUERIES ────────────────────────────────────────

    /**
     * Get products with filtering, sorting, and pagination.
     */
    public function getCatalog(array $filters = [], int $page = 1, int $perPage = PRODUCTS_PER_PAGE): array
    {
        $where  = 'p.is_active = 1';
        $params = [];
        $orderBy = 'p.created_at DESC';

        // Filter: Category
        if (!empty($filters['category_id'])) {
            $where .= ' AND p.category_id = ?';
            $params[] = (int) $filters['category_id'];
        }

        // Filter: Category slug
        if (!empty($filters['category_slug'])) {
            $where .= ' AND c.slug = ?';
            $params[] = $filters['category_slug'];
        }

        // Filter: Price range
        if (!empty($filters['min_price'])) {
            $where .= ' AND COALESCE(p.sale_price, p.price) >= ?';
            $params[] = (float) $filters['min_price'];
        }
        if (!empty($filters['max_price'])) {
            $where .= ' AND COALESCE(p.sale_price, p.price) <= ?';
            $params[] = (float) $filters['max_price'];
        }

        // Filter: In stock only
        if (!empty($filters['in_stock'])) {
            $where .= ' AND p.stock_count > 0';
        }

        // Filter: Featured only
        if (!empty($filters['featured'])) {
            $where .= ' AND p.is_featured = 1';
        }

        // Filter: Search
        if (!empty($filters['search'])) {
            $where .= ' AND (p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ?)';
            $searchTerm = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
        }

        // Sorting
        if (!empty($filters['sort'])) {
            $sortOptions = [
                'price_asc'    => 'COALESCE(p.sale_price, p.price) ASC',
                'price_desc'   => 'COALESCE(p.sale_price, p.price) DESC',
                'name_asc'     => 'p.name ASC',
                'name_desc'    => 'p.name DESC',
                'newest'       => 'p.created_at DESC',
                'oldest'       => 'p.created_at ASC',
                'popular'      => 'p.total_sold DESC',
                'rating'       => 'p.view_count DESC',
            ];
            $orderBy = $sortOptions[$filters['sort']] ?? 'p.created_at DESC';
        }

        // Count total
        $countSql = "SELECT COUNT(*) FROM `products` p
                     LEFT JOIN `categories` c ON c.id = p.category_id
                     WHERE {$where}";
        $totalItems = (int) $this->db->fetchColumn($countSql, $params);

        $pagination = paginate($totalItems, $perPage, $page);

        // Fetch products
        $sql = "SELECT p.*, c.name AS category_name, c.slug AS category_slug,
                       COALESCE(p.sale_price, p.price) AS effective_price,
                       CASE WHEN p.sale_price IS NOT NULL AND p.sale_price < p.price
                            THEN ROUND(((p.price - p.sale_price) / p.price) * 100)
                            ELSE 0 END AS discount_percent
                FROM `products` p
                LEFT JOIN `categories` c ON c.id = p.category_id
                WHERE {$where}
                ORDER BY {$orderBy}
                LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}";

        $products = $this->db->fetchAll($sql, $params);

        return [
            'products'   => $products,
            'pagination' => $pagination,
        ];
    }

    /**
     * Get featured products for the homepage.
     */
    public function getFeatured(int $limit = 8): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, c.name AS category_name,
                    COALESCE(p.sale_price, p.price) AS effective_price,
                    CASE WHEN p.sale_price IS NOT NULL AND p.sale_price < p.price
                         THEN ROUND(((p.price - p.sale_price) / p.price) * 100)
                         ELSE 0 END AS discount_percent
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.is_active = 1 AND p.is_featured = 1
             ORDER BY p.created_at DESC
             LIMIT ?",
            [$limit]
        );
    }

    /**
     * Get latest products.
     */
    public function getLatest(int $limit = 8): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, c.name AS category_name,
                    COALESCE(p.sale_price, p.price) AS effective_price,
                    CASE WHEN p.sale_price IS NOT NULL AND p.sale_price < p.price
                         THEN ROUND(((p.price - p.sale_price) / p.price) * 100)
                         ELSE 0 END AS discount_percent
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.is_active = 1
             ORDER BY p.created_at DESC
             LIMIT ?",
            [$limit]
        );
    }

    /**
     * Get best-selling products.
     */
    public function getBestSellers(int $limit = 8): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, c.name AS category_name,
                    COALESCE(p.sale_price, p.price) AS effective_price
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.is_active = 1 AND p.total_sold > 0
             ORDER BY p.total_sold DESC
             LIMIT ?",
            [$limit]
        );
    }

    /**
     * Get related products (same category, excluding current product).
     */
    public function getRelated(int $productId, int $categoryId, int $limit = 4): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, COALESCE(p.sale_price, p.price) AS effective_price
             FROM `products` p
             WHERE p.is_active = 1 AND p.category_id = ? AND p.id != ?
             ORDER BY RAND()
             LIMIT ?",
            [$categoryId, $productId, $limit]
        );
    }

    // ── SINGLE PRODUCT ─────────────────────────────────────────

    /**
     * Find a product by ID.
     */
    public function findById(int $id): ?array
    {
        return $this->db->fetchOne(
            "SELECT p.*, c.name AS category_name, c.slug AS category_slug,
                    COALESCE(p.sale_price, p.price) AS effective_price,
                    CASE WHEN p.sale_price IS NOT NULL AND p.sale_price < p.price
                         THEN ROUND(((p.price - p.sale_price) / p.price) * 100)
                         ELSE 0 END AS discount_percent
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.id = ?
             LIMIT 1",
            [$id]
        );
    }

    /**
     * Find a product by slug.
     */
    public function findBySlug(string $slug): ?array
    {
        return $this->db->fetchOne(
            "SELECT p.*, c.name AS category_name, c.slug AS category_slug,
                    COALESCE(p.sale_price, p.price) AS effective_price,
                    CASE WHEN p.sale_price IS NOT NULL AND p.sale_price < p.price
                         THEN ROUND(((p.price - p.sale_price) / p.price) * 100)
                         ELSE 0 END AS discount_percent
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.slug = ? AND p.is_active = 1
             LIMIT 1",
            [$slug]
        );
    }

    /**
     * Increment the view count for a product.
     */
    public function incrementViews(int $id): void
    {
        $this->db->query("UPDATE `products` SET `view_count` = `view_count` + 1 WHERE `id` = ?", [$id]);
    }

    // ── STOCK MANAGEMENT ───────────────────────────────────────

    /**
     * Check if a product has sufficient stock.
     */
    public function hasStock(int $productId, int $quantity = 1): bool
    {
        $stock = $this->db->fetchColumn(
            "SELECT `stock_count` FROM `products` WHERE `id` = ? AND `is_active` = 1",
            [$productId]
        );
        return $stock !== false && (int) $stock >= $quantity;
    }

    /**
     * Reduce stock after an order is placed.
     */
    public function reduceStock(int $productId, int $quantity): bool
    {
        $stmt = $this->db->query(
            "UPDATE `products`
             SET `stock_count` = `stock_count` - ?, `total_sold` = `total_sold` + ?
             WHERE `id` = ? AND `stock_count` >= ?",
            [$quantity, $quantity, $productId, $quantity]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * Restore stock (e.g., when an order is cancelled).
     */
    public function restoreStock(int $productId, int $quantity): void
    {
        $this->db->query(
            "UPDATE `products`
             SET `stock_count` = `stock_count` + ?, `total_sold` = GREATEST(`total_sold` - ?, 0)
             WHERE `id` = ?",
            [$quantity, $quantity, $productId]
        );
    }

    /**
     * Get low-stock products.
     */
    public function getLowStock(): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, c.name AS category_name
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.is_active = 1 AND p.stock_count <= p.low_stock_threshold AND p.stock_count > 0
             ORDER BY p.stock_count ASC"
        );
    }

    /**
     * Get out-of-stock products.
     */
    public function getOutOfStock(): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, c.name AS category_name
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE p.is_active = 1 AND p.stock_count <= 0
             ORDER BY p.name ASC"
        );
    }

    // ── CRUD (Admin) ───────────────────────────────────────────

    /**
     * Create a new product.
     */
    public function create(array $data): int
    {
        return $this->db->insert('products', [
            'category_id'        => (int) $data['category_id'],
            'name'               => clean($data['name']),
            'slug'               => createSlug($data['name']),
            'sku'                => clean($data['sku']),
            'description'        => $data['description'] ?? '',
            'short_desc'         => clean($data['short_desc'] ?? ''),
            'price'              => (float) $data['price'],
            'sale_price'         => !empty($data['sale_price']) ? (float) $data['sale_price'] : null,
            'cost_price'         => !empty($data['cost_price']) ? (float) $data['cost_price'] : null,
            'stock_count'        => (int) ($data['stock_count'] ?? 0),
            'low_stock_threshold'=> (int) ($data['low_stock_threshold'] ?? 5),
            'image'              => $data['image'] ?? null,
            'weight'             => !empty($data['weight']) ? (float) $data['weight'] : null,
            'origin_country'     => clean($data['origin_country'] ?? ''),
            'hs_code'            => clean($data['hs_code'] ?? ''),
            'is_featured'        => (int) ($data['is_featured'] ?? 0),
            'is_active'          => (int) ($data['is_active'] ?? 1),
        ]);
    }

    /**
     * Update a product.
     */
    public function update(int $id, array $data): bool
    {
        $allowed = [
            'category_id', 'name', 'sku', 'description', 'short_desc',
            'price', 'sale_price', 'cost_price', 'stock_count',
            'low_stock_threshold', 'image', 'weight', 'origin_country',
            'hs_code', 'is_featured', 'is_active'
        ];

        $updateData = [];
        foreach ($allowed as $field) {
            if (array_key_exists($field, $data)) {
                $updateData[$field] = $data[$field];
            }
        }

        if (isset($updateData['name'])) {
            $updateData['slug'] = createSlug($updateData['name']);
        }

        return $this->db->update('products', $updateData, '`id` = ?', [$id]) > 0;
    }

    /**
     * Delete a product (soft delete by deactivating).
     */
    public function delete(int $id): bool
    {
        return $this->db->update('products', ['is_active' => 0], '`id` = ?', [$id]) > 0;
    }

    /**
     * Get all products for admin (with pagination).
     */
    public function getAdminList(int $page = 1, int $perPage = 20, array $filters = []): array
    {
        $where  = '1=1';
        $params = [];

        if (!empty($filters['category_id'])) {
            $where .= ' AND p.category_id = ?';
            $params[] = (int) $filters['category_id'];
        }
        if (!empty($filters['search'])) {
            $where .= ' AND (p.name LIKE ? OR p.sku LIKE ?)';
            $s = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$s, $s]);
        }
        if (isset($filters['is_active'])) {
            $where .= ' AND p.is_active = ?';
            $params[] = (int) $filters['is_active'];
        }

        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM `products` p WHERE {$where}", $params
        );

        $pagination = paginate($total, $perPage, $page);

        $products = $this->db->fetchAll(
            "SELECT p.*, c.name AS category_name
             FROM `products` p
             LEFT JOIN `categories` c ON c.id = p.category_id
             WHERE {$where}
             ORDER BY p.created_at DESC
             LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}",
            $params
        );

        return ['products' => $products, 'pagination' => $pagination];
    }

    /**
     * Get price range for filter sidebar.
     */
    public function getPriceRange(): array
    {
        $result = $this->db->fetchOne(
            "SELECT MIN(COALESCE(sale_price, price)) AS min_price,
                    MAX(COALESCE(sale_price, price)) AS max_price
             FROM `products`
             WHERE `is_active` = 1"
        );
        return [
            'min' => (float) ($result['min_price'] ?? 0),
            'max' => (float) ($result['max_price'] ?? 10000),
        ];
    }

    /**
     * Get product statistics for admin dashboard.
     */
    public function getStats(): array
    {
        return [
            'total'        => $this->db->count('products'),
            'active'       => $this->db->count('products', '`is_active` = 1'),
            'featured'     => $this->db->count('products', '`is_featured` = 1'),
            'out_of_stock' => $this->db->count('products', '`stock_count` <= 0 AND `is_active` = 1'),
            'low_stock'    => $this->db->count('products', '`stock_count` > 0 AND `stock_count` <= `low_stock_threshold` AND `is_active` = 1'),
            'total_value'  => (float) $this->db->fetchColumn(
                "SELECT SUM(`stock_count` * `cost_price`) FROM `products` WHERE `is_active` = 1 AND `cost_price` IS NOT NULL"
            ),
        ];
    }
}