<?php
/**
 * ================================================================
 * User Class — OOP Model for User Management
 * Handles authentication, registration, profile, and admin ops
 * ================================================================
 */

class User
{
    private Database $db;
    private ?array $userData = null;

    /**
     * Constructor — inject Database singleton.
     */
    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── AUTHENTICATION ─────────────────────────────────────────

    /**
     * Register a new user account.
     * Returns the new user ID on success, or throws an exception.
     */
    public function register(array $data): int
    {
        // Check if email already exists
        if ($this->emailExists($data['email'])) {
            throw new RuntimeException('An account with this email already exists.');
        }

        // Validate required fields
        $this->validateRegistration($data);

        // Hash the password
        $hashedPassword = hashPassword($data['password']);

        // Generate email verification token
        $verifyToken = bin2hex(random_bytes(32));

        // Insert user into the database
        $userId = $this->db->insert('users', [
            'first_name'     => clean($data['first_name']),
            'last_name'      => clean($data['last_name']),
            'email'          => strtolower(trim($data['email'])),
            'phone'          => clean($data['phone'] ?? ''),
            'password'        => $hashedPassword,
            'role'           => 'customer',
            'address'        => clean($data['address'] ?? ''),
            'city'           => clean($data['city'] ?? ''),
            'state'          => clean($data['state'] ?? ''),
            'zip_code'       => clean($data['zip_code'] ?? ''),
            'country'        => clean($data['country'] ?? 'Ethiopia'),
            'email_verified' => 0,
            'verify_token'   => $verifyToken,
            'is_active'      => 1,
        ]);

        return $userId;
    }

    /**
     * Validate registration input data.
     */
    private function validateRegistration(array $data): void
    {
        $errors = [];

        if (empty($data['first_name']) || mb_strlen($data['first_name']) < 2) {
            $errors[] = 'First name must be at least 2 characters.';
        }
        if (empty($data['last_name']) || mb_strlen($data['last_name']) < 2) {
            $errors[] = 'Last name must be at least 2 characters.';
        }
        if (empty($data['email']) || !isValidEmail($data['email'])) {
            $errors[] = 'Please provide a valid email address.';
        }
        if (!empty($data['phone']) && !isValidPhone($data['phone'])) {
            $errors[] = 'Please provide a valid Ethiopian phone number.';
        }
        if (empty($data['password']) || mb_strlen($data['password']) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        }
        if (!isStrongPassword($data['password'])) {
            $errors[] = 'Password must contain uppercase, lowercase, and a digit.';
        }
        if ($data['password'] !== ($data['confirm_password'] ?? '')) {
            $errors[] = 'Passwords do not match.';
        }

        if (!empty($errors)) {
            throw new RuntimeException(implode('<br>', $errors));
        }
    }

    /**
     * Authenticate a user by email and password.
     * Returns user data array on success, or null on failure.
     */
    public function authenticate(string $email, string $password): ?array
    {
        $email = strtolower(trim($email));

        // Check for brute-force lockout
        if ($this->isLockedOut($email)) {
            throw new RuntimeException(
                'Too many failed login attempts. Please try again in ' . (LOGIN_LOCKOUT_TIME / 60) . ' minutes.'
            );
        }

        // Find user by email
        $user = $this->db->fetchOne(
            "SELECT * FROM `users` WHERE `email` = ? AND `is_active` = 1 LIMIT 1",
            [$email]
        );

        if (!$user || !verifyPassword($password, $user['password'])) {
            // Record failed attempt
            $this->recordFailedAttempt($email);
            return null;
        }

        // Clear failed attempts on successful login
        $this->clearFailedAttempts($email);

        // Update last login timestamp
        $this->db->update('users', ['last_login' => date('Y-m-d H:i:s')], '`id` = ?', [$user['id']]);

        // Remove password from returned data
        unset($user['password']);
        $this->userData = $user;

        return $user;
    }

    /**
     * Create a user session after successful authentication.
     */
    public function createSession(array $user): void
    {
        // Regenerate session ID to prevent fixation attacks
        session_regenerate_id(true);

        $_SESSION['user_id']         = (int) $user['id'];
        $_SESSION['user_email']      = $user['email'];
        $_SESSION['user_first_name'] = $user['first_name'];
        $_SESSION['user_last_name']  = $user['last_name'];
        $_SESSION['user_role']       = $user['role'];
        $_SESSION['user_avatar']     = $user['avatar'] ?? null;
        $_SESSION['logged_in_at']    = time();
        $_SESSION['ip_address']      = $_SERVER['REMOTE_ADDR'] ?? '';
        $_SESSION['user_agent']      = $_SERVER['HTTP_USER_AGENT'] ?? '';
    }

    /**
     * Destroy the current user session (logout).
     */
    public function destroySession(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }

        session_destroy();
    }

    /**
     * Validate that the current session is still valid.
     * Checks IP and User-Agent to prevent session hijacking.
     */
    public function validateSession(): bool
    {
        if (!isLoggedIn()) {
            return false;
        }

        // Optional: IP check (can be disabled for mobile users)
        // if (($_SESSION['ip_address'] ?? '') !== ($_SERVER['REMOTE_ADDR'] ?? '')) {
        //     $this->destroySession();
        //     return false;
        // }

        // Session timeout after 2 hours of inactivity
        $maxLifetime = 7200; // 2 hours
        if (isset($_SESSION['logged_in_at']) && (time() - $_SESSION['logged_in_at']) > $maxLifetime) {
            $this->destroySession();
            return false;
        }

        return true;
    }

    // ── BRUTE FORCE PROTECTION ─────────────────────────────────

    /**
     * Record a failed login attempt.
     */
    private function recordFailedAttempt(string $email): void
    {
        $key = 'login_attempts_' . md5($email);
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['count' => 0, 'first_attempt' => time()];
        }
        $_SESSION[$key]['count']++;
        $_SESSION[$key]['last_attempt'] = time();
    }

    /**
     * Check if the user is locked out due to too many failed attempts.
     */
    private function isLockedOut(string $email): bool
    {
        $key = 'login_attempts_' . md5($email);
        if (!isset($_SESSION[$key])) {
            return false;
        }

        $attempts = $_SESSION[$key];

        // Check if lockout period has expired
        if (isset($attempts['last_attempt']) &&
            (time() - $attempts['last_attempt']) > LOGIN_LOCKOUT_TIME) {
            $this->clearFailedAttempts($email);
            return false;
        }

        return $attempts['count'] >= MAX_LOGIN_ATTEMPTS;
    }

    /**
     * Clear failed login attempts.
     */
    private function clearFailedAttempts(string $email): void
    {
        $key = 'login_attempts_' . md5($email);
        unset($_SESSION[$key]);
    }

    // ── PASSWORD RESET ─────────────────────────────────────────

    /**
     * Generate a password reset token for a user.
     * Returns the token, or null if the email doesn't exist.
     */
    public function generateResetToken(string $email): ?string
    {
        $email = strtolower(trim($email));

        $user = $this->findByEmail($email);
        if (!$user) {
            return null;
        }

        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $this->db->update('users', [
            'reset_token'   => $token,
            'reset_expires' => $expires,
        ], '`id` = ?', [$user['id']]);

        return $token;
    }

    /**
     * Validate a password reset token.
     * Returns the user data if the token is valid.
     */
    public function validateResetToken(string $token): ?array
    {
        if (empty($token)) {
            return null;
        }

        $user = $this->db->fetchOne(
            "SELECT `id`, `email`, `first_name`, `last_name`, `reset_expires`
             FROM `users`
             WHERE `reset_token` = ? AND `reset_expires` > NOW() AND `is_active` = 1
             LIMIT 1",
            [$token]
        );

        return $user ?: null;
    }

    /**
     * Reset a user's password using a valid token.
     */
    public function resetPassword(string $token, string $newPassword): bool
    {
        $user = $this->validateResetToken($token);
        if (!$user) {
            throw new RuntimeException('Invalid or expired reset token.');
        }

        if (!isStrongPassword($newPassword)) {
            throw new RuntimeException('Password must contain uppercase, lowercase, and a digit (min 8 chars).');
        }

        $hashed = hashPassword($newPassword);

        $this->db->update('users', [
            'password'      => $hashed,
            'reset_token'   => null,
            'reset_expires' => null,
        ], '`id` = ?', [$user['id']]);

        return true;
    }

    /**
     * Change a user's password (when logged in, requires current password).
     */
    public function changePassword(int $userId, string $currentPassword, string $newPassword): bool
    {
        $user = $this->findById($userId);
        if (!$user) {
            throw new RuntimeException('User not found.');
        }

        // Verify current password
        $fullUser = $this->db->fetchOne("SELECT `password` FROM `users` WHERE `id` = ?", [$userId]);
        if (!verifyPassword($currentPassword, $fullUser['password'])) {
            throw new RuntimeException('Current password is incorrect.');
        }

        if (!isStrongPassword($newPassword)) {
            throw new RuntimeException('New password must contain uppercase, lowercase, and a digit (min 8 chars).');
        }

        $hashed = hashPassword($newPassword);
        $this->db->update('users', ['password' => $hashed], '`id` = ?', [$userId]);

        return true;
    }

    // ── CRUD OPERATIONS ────────────────────────────────────────

    /**
     * Find a user by their ID.
     */
    public function findById(int $id): ?array
    {
        return $this->db->fetchOne(
            "SELECT `id`, `first_name`, `last_name`, `email`, `phone`, `role`,
                    `address`, `city`, `state`, `zip_code`, `country`, `avatar`,
                    `email_verified`, `is_active`, `last_login`, `created_at`, `updated_at`
             FROM `users`
             WHERE `id` = ?
             LIMIT 1",
            [$id]
        );
    }

    /**
     * Find a user by their email.
     */
    public function findByEmail(string $email): ?array
    {
        return $this->db->fetchOne(
            "SELECT `id`, `first_name`, `last_name`, `email`, `phone`, `role`,
                    `address`, `city`, `state`, `zip_code`, `country`, `avatar`,
                    `email_verified`, `is_active`, `last_login`, `created_at`
             FROM `users`
             WHERE `email` = ?
             LIMIT 1",
            [strtolower(trim($email))]
        );
    }

    /**
     * Check if an email already exists in the database.
     */
    public function emailExists(string $email): bool
    {
        return $this->db->exists('users', '`email` = ?', [strtolower(trim($email))]);
    }

    /**
     * Update user profile information.
     */
    public function updateProfile(int $userId, array $data): bool
    {
        $allowed = ['first_name', 'last_name', 'phone', 'address', 'city', 'state', 'zip_code', 'country'];
        $updateData = [];

        foreach ($allowed as $field) {
            if (isset($data[$field])) {
                $updateData[$field] = clean($data[$field]);
            }
        }

        if (empty($updateData)) {
            return false;
        }

        $affected = $this->db->update('users', $updateData, '`id` = ?', [$userId]);

        // Update session data if the logged-in user updated their own profile
        if ($userId === currentUserId()) {
            if (isset($updateData['first_name'])) {
                $_SESSION['user_first_name'] = $updateData['first_name'];
            }
            if (isset($updateData['last_name'])) {
                $_SESSION['user_last_name'] = $updateData['last_name'];
            }
        }

        return $affected > 0;
    }

    /**
     * Update user avatar.
     */
    public function updateAvatar(int $userId, string $avatarPath): bool
    {
        // Delete old avatar if it exists
        $user = $this->findById($userId);
        if ($user && !empty($user['avatar'])) {
            deleteFile($user['avatar']);
        }

        $affected = $this->db->update('users', ['avatar' => $avatarPath], '`id` = ?', [$userId]);

        if ($userId === currentUserId()) {
            $_SESSION['user_avatar'] = $avatarPath;
        }

        return $affected > 0;
    }

    // ── ADMIN OPERATIONS ───────────────────────────────────────

    /**
     * Get all users with pagination and optional filters.
     */
    public function getAllUsers(int $page = 1, int $perPage = USERS_PER_PAGE, array $filters = []): array
    {
        $where = '1=1';
        $params = [];

        // Filter by role
        if (!empty($filters['role'])) {
            $where .= ' AND `role` = ?';
            $params[] = $filters['role'];
        }

        // Filter by status
        if (isset($filters['is_active'])) {
            $where .= ' AND `is_active` = ?';
            $params[] = (int) $filters['is_active'];
        }

        // Search by name or email
        if (!empty($filters['search'])) {
            $where .= ' AND (
                `first_name` LIKE ? OR
                `last_name` LIKE ? OR
                `email` LIKE ? OR
                `phone` LIKE ?
            )';
            $searchTerm = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }

        // Get total count for pagination
        $totalCount = $this->db->fetchColumn(
            "SELECT COUNT(*) FROM `users` WHERE {$where}",
            $params
        );

        $pagination = paginate($totalCount, $perPage, $page);

        // Get users
        $users = $this->db->fetchAll(
            "SELECT `id`, `first_name`, `last_name`, `email`, `phone`, `role`,
                    `is_active`, `email_verified`, `last_login`, `created_at`
             FROM `users`
             WHERE {$where}
             ORDER BY `created_at` DESC
             LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}",
            $params
        );

        return [
            'users'      => $users,
            'pagination' => $pagination,
        ];
    }

    /**
     * Toggle user active status (ban/unban).
     */
    public function toggleActive(int $userId): bool
    {
        $user = $this->findById($userId);
        if (!$user) return false;

        $newStatus = $user['is_active'] ? 0 : 1;
        $this->db->update('users', ['is_active' => $newStatus], '`id` = ?', [$userId]);
        return true;
    }

    /**
     * Get user statistics for admin dashboard.
     */
    public function getStats(): array
    {
        return [
            'total_users'     => $this->db->count('users'),
            'active_users'    => $this->db->count('users', '`is_active` = 1'),
            'inactive_users'  => $this->db->count('users', '`is_active` = 0'),
            'total_customers' => $this->db->count('users', '`role` = ?', ['customer']),
            'total_admins'    => $this->db->count('users', '`role` = ?', ['admin']),
            'new_today'       => $this->db->count('users', 'DATE(`created_at`) = CURDATE()'),
            'new_this_week'   => $this->db->count('users', '`created_at` >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)'),
            'new_this_month'  => $this->db->count('users', '`created_at` >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)'),
        ];
    }

    /**
     * Delete a user account (soft-delete by deactivating).
     */
    public function deleteUser(int $userId): bool
    {
        // Don't allow deleting yourself
        if ($userId === currentUserId()) {
            throw new RuntimeException('You cannot delete your own account.');
        }

        return $this->db->update('users', ['is_active' => 0], '`id` = ?', [$userId]) > 0;
    }
}