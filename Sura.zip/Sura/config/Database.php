<?php
/**
 * ================================================================
 * Database Connection Class (Singleton Pattern)
 * Uses PDO with prepared statements for maximum security
 * ================================================================
 */

class Database
{
    private static ?Database $instance = null;
    private ?PDO $connection = null;
    private int $transactionDepth = 0;
    private int $queryCount = 0;
    private array $queryLog = [];
    private bool $enableLogging = false;

    /**
     * Private constructor to prevent direct instantiation.
     */
    private function __construct()
    {
        $this->connect();
    }

    /**
     * Prevent cloning of the singleton instance.
     */
    private function __clone() {}

    /**
     * Prevent unserialization of the singleton instance.
     */
    public function __wakeup()
    {
        throw new \RuntimeException('Cannot unserialize a singleton.');
    }

    /**
     * Get the singleton instance of the Database class.
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Establish the PDO database connection.
     */
    private function connect(): void
    {
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                DB_HOST,
                DB_PORT,
                DB_NAME,
                DB_CHARSET
            );

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
                PDO::MYSQL_ATTR_FOUND_ROWS   => true,
            ];

            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);

        } catch (PDOException $e) {
            error_log('Database Connection Error: ' . $e->getMessage());
            throw new RuntimeException(
                'Database connection failed. Please check your configuration.'
            );
        }
    }

    /**
     * Get the raw PDO connection object.
     */
    public function getConnection(): PDO
    {
        return $this->connection;
    }

    /**
     * Execute a query with optional bound parameters.
     * Returns the PDOStatement for further processing.
     */
    public function query(string $sql, array $params = []): PDOStatement
    {
        try {
            $this->queryCount++;
            $startTime = microtime(true);

            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);

            if ($this->enableLogging) {
                $this->queryLog[] = [
                    'sql'    => $sql,
                    'params' => $params,
                    'time'   => round((microtime(true) - $startTime) * 1000, 2) . 'ms',
                ];
            }

            return $stmt;

        } catch (PDOException $e) {
            error_log("Query Error: {$e->getMessage()} | SQL: {$sql} | Params: " . json_encode($params));
            throw new RuntimeException('A database error occurred. Please try again later.');
        }
    }

    /**
     * Fetch a single row from a SELECT query.
     */
    public function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = $this->query($sql, $params);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Fetch all rows from a SELECT query.
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }

    /**
     * Fetch a single scalar value.
     */
    public function fetchColumn(string $sql, array $params = [], int $column = 0): mixed
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchColumn($column);
    }

    /**
     * Insert a row into a table and return the last inserted ID.
     */
    public function insert(string $table, array $data): int
    {
        $columns = implode('`, `', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));

        $sql = "INSERT INTO `{$table}` (`{$columns}`) VALUES ({$placeholders})";

        $this->query($sql, array_values($data));
        return (int) $this->connection->lastInsertId();
    }

    /**
     * Update rows in a table.
     * Returns the number of affected rows.
     */
    public function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $setParts = [];
        $values = [];

        foreach ($data as $column => $value) {
            $setParts[] = "`{$column}` = ?";
            $values[]   = $value;
        }

        $sql = "UPDATE `{$table}` SET " . implode(', ', $setParts) . " WHERE {$where}";
        $allParams = array_merge($values, $whereParams);

        $stmt = $this->query($sql, $allParams);
        return $stmt->rowCount();
    }

    /**
     * Delete rows from a table.
     * Returns the number of affected rows.
     */
    public function delete(string $table, string $where, array $params = []): int
    {
        $sql = "DELETE FROM `{$table}` WHERE {$where}";
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }

    /**
     * Count rows in a table with optional conditions.
     */
    public function count(string $table, string $where = '1', array $params = []): int
    {
        $sql = "SELECT COUNT(*) FROM `{$table}` WHERE {$where}";
        return (int) $this->fetchColumn($sql, $params);
    }

    /**
     * Check if a record exists.
     */
    public function exists(string $table, string $where, array $params = []): bool
    {
        return $this->count($table, $where, $params) > 0;
    }

    /**
     * Begin a database transaction (supports nested transactions).
     */
    public function beginTransaction(): void
    {
        if ($this->transactionDepth === 0) {
            $this->connection->beginTransaction();
        } else {
            $this->connection->exec("SAVEPOINT trans_{$this->transactionDepth}");
        }
        $this->transactionDepth++;
    }

    /**
     * Commit the current transaction.
     */
    public function commit(): void
    {
        $this->transactionDepth--;
        if ($this->transactionDepth === 0) {
            $this->connection->commit();
        } else {
            $this->connection->exec("RELEASE SAVEPOINT trans_{$this->transactionDepth}");
        }
    }

    /**
     * Roll back the current transaction.
     */
    public function rollBack(): void
    {
        $this->transactionDepth--;
        if ($this->transactionDepth === 0) {
            $this->connection->rollBack();
        } else {
            $this->connection->exec("ROLLBACK TO SAVEPOINT trans_{$this->transactionDepth}");
        }
    }

    /**
     * Execute a callback within a transaction.
     */
    public function transaction(callable $callback): mixed
    {
        $this->beginTransaction();
        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (\Throwable $e) {
            $this->rollBack();
            throw $e;
        }
    }

    /**
     * Get the last inserted ID.
     */
    public function lastInsertId(): int
    {
        return (int) $this->connection->lastInsertId();
    }

    /**
     * Get total query count for this request.
     */
    public function getQueryCount(): int
    {
        return $this->queryCount;
    }

    /**
     * Enable/disable query logging.
     */
    public function setLogging(bool $enable): void
    {
        $this->enableLogging = $enable;
    }

    /**
     * Get the query log.
     */
    public function getQueryLog(): array
    {
        return $this->queryLog;
    }

    /**
     * Close the connection.
     */
    public function close(): void
    {
        $this->connection = null;
        self::$instance = null;
    }
}