<?php
/**
 * ================================================================
 * Global Helper Functions
 * Utility functions used throughout the application
 * ================================================================
 */

// ── SECURITY HELPERS ───────────────────────────────────────────

/**
 * Generate a CSRF token and store it in the session.
 */
function generateCsrfToken(): string
{
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Render a hidden CSRF input field.
 */
function csrfField(): string
{
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . generateCsrfToken() . '">';
}

/**
 * Validate the submitted CSRF token.
 */
function validateCsrfToken(?string $token = null): bool
{
    $token = $token ?? ($_POST[CSRF_TOKEN_NAME] ?? '');
    if (empty($_SESSION[CSRF_TOKEN_NAME]) || empty($token)) {
        return false;
    }
    $valid = hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
    // Regenerate token after validation
    unset($_SESSION[CSRF_TOKEN_NAME]);
    return $valid;
}

/**
 * Sanitize user input for safe display.
 */
function sanitize(mixed $data): string
{
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(strip_tags(trim((string) $data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Sanitize input and return it (alias for readability).
 */
function clean(string $value): string
{
    return sanitize($value);
}

/**
 * Hash a password using bcrypt.
 */
function hashPassword(string $password): string
{
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
}

/**
 * Verify a password against a hash.
 */
function verifyPassword(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}

// ── SESSION & AUTH HELPERS ─────────────────────────────────────

/**
 * Check if a user is logged in.
 */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if the logged-in user is an admin.
 */
function isAdmin(): bool
{
    return isLoggedIn() && ($_SESSION['user_role'] ?? '') === 'admin';
}

/**
 * Get the current user's ID from the session.
 */
function currentUserId(): ?int
{
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

/**
 * Get the current user's full name.
 */
function currentUserName(): string
{
    return ($_SESSION['user_first_name'] ?? '') . ' ' . ($_SESSION['user_last_name'] ?? '');
}

/**
 * Require user to be logged in; redirect to login page otherwise.
 */
function requireLogin(): void
{
    if (!isLoggedIn()) {
        setFlash('error', 'Please log in to access this page.');
        redirect('auth/login.php');
    }
}

/**
 * Require user to be an admin; redirect otherwise.
 */
function requireAdmin(): void
{
    if (!isAdmin()) {
        setFlash('error', 'Access denied. Admins only.');
        redirect('auth/login.php');
    }
}

// ── FLASH MESSAGE HELPERS ──────────────────────────────────────

/**
 * Set a flash message.
 */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'][$type] = $message;
}

/**
 * Get and clear flash messages.
 */
function getFlash(): array
{
    $flash = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flash;
}

/**
 * Render flash messages as Bootstrap alerts.
 */
function renderFlash(): string
{
    $flash = getFlash();
    $html = '';
    $typeMap = [
        'success' => 'success',
        'error'   => 'danger',
        'warning' => 'warning',
        'info'    => 'info',
    ];

    foreach ($flash as $type => $message) {
        $bsClass = $typeMap[$type] ?? 'info';
        $html .= '<div class="alert alert-' . $bsClass . ' alert-dismissible fade show" role="alert">';
        $html .= sanitize($message);
        $html .= '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        $html .= '</div>';
    }
    return $html;
}

// ── URL & REDIRECT HELPERS ─────────────────────────────────────

/**
 * Generate a full URL from a relative path.
 */
function url(string $path = ''): string
{
    return BASE_URL . ltrim($path, '/');
}

/**
 * Generate a URL for an asset file.
 */
function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

/**
 * Get the site logo URL.
 */
function logoUrl(): string
{
    return url(SITE_LOGO);
}

/**
 * Redirect to a URL (relative to BASE_URL).
 */
function redirect(string $path = '', int $statusCode = 302): never
{
    header('Location: ' . url($path), true, $statusCode);
    exit;
}

/**
 * Redirect back to the previous page.
 */
function redirectBack(): never
{
    $referer = $_SERVER['HTTP_REFERER'] ?? url();
    header('Location: ' . $referer);
    exit;
}

// ── FORMATTING HELPERS ─────────────────────────────────────────

/**
 * Format a number as Ethiopian Birr currency.
 */
function formatPrice(float|int $amount): string
{
    return CURRENCY_SYMBOL . ' ' . number_format((float) $amount, 2);
}

/**
 * Format a date for display.
 */
function formatDate(string $date, string $format = 'M d, Y'): string
{
    return date($format, strtotime($date));
}

/**
 * Format a datetime for display.
 */
function formatDateTime(string $datetime, string $format = 'M d, Y h:i A'): string
{
    return date($format, strtotime($datetime));
}

/**
 * Generate a unique order number.
 */
function generateOrderNumber(): string
{
    return 'ORD-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(4)));
}

/**
 * Generate a URL-friendly slug from a string.
 */
function createSlug(string $text): string
{
    $slug = strtolower(trim($text));
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    return trim($slug, '-');
}

/**
 * Truncate a string to a specified length.
 */
function truncateText(string $text, int $length = 100, string $suffix = '...'): string
{
    if (mb_strlen($text) <= $length) {
        return $text;
    }
    return mb_substr($text, 0, $length) . $suffix;
}

// ── IMAGE/FILE UPLOAD HELPERS ──────────────────────────────────

/**
 * Upload an image file.
 * Returns the relative path on success, or null on failure.
 */
function uploadImage(array $file, string $targetDir, string $prefix = ''): ?string
{
    // Validate file
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    // Check file size
    if ($file['size'] > MAX_FILE_SIZE) {
        setFlash('error', 'File size exceeds the maximum limit of ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB.');
        return null;
    }

    // Check MIME type
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    if (!in_array($mimeType, ALLOWED_IMAGE_TYPES)) {
        setFlash('error', 'Invalid file type. Allowed: JPEG, PNG, GIF, WebP.');
        return null;
    }

    // Create directory if it doesn't exist
    $fullDir = APP_ROOT . $targetDir;
    if (!is_dir($fullDir)) {
        mkdir($fullDir, 0755, true);
    }

    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename  = $prefix . uniqid('img_', true) . '.' . strtolower($extension);
    $destination = $fullDir . $filename;

    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return $targetDir . $filename;
    }

    return null;
}

/**
 * Delete an uploaded file.
 */
function deleteFile(string $relativePath): bool
{
    $fullPath = APP_ROOT . $relativePath;
    if (file_exists($fullPath) && is_file($fullPath)) {
        return unlink($fullPath);
    }
    return false;
}

/**
 * Get the URL for a product image, or a placeholder.
 */
function productImageUrl(?string $imagePath): string
{
    if ($imagePath && file_exists(APP_ROOT . $imagePath)) {
        return url($imagePath);
    }
    return url('assets/img/no-image.png');
}

// ── PAGINATION HELPER ──────────────────────────────────────────

/**
 * Calculate pagination values.
 * Returns [offset, totalPages, currentPage].
 */
function paginate(int $totalItems, int $perPage, int $currentPage = 1): array
{
    $totalPages  = max(1, (int) ceil($totalItems / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    $offset      = ($currentPage - 1) * $perPage;

    return [
        'offset'       => $offset,
        'total_pages'  => $totalPages,
        'current_page' => $currentPage,
        'per_page'     => $perPage,
        'total_items'  => $totalItems,
        'has_prev'     => $currentPage > 1,
        'has_next'     => $currentPage < $totalPages,
    ];
}

/**
 * Render Bootstrap pagination links.
 */
function renderPagination(array $pagination, string $baseUrl, array $extraParams = []): string
{
    if ($pagination['total_pages'] <= 1) return '';

    $html = '<nav aria-label="Page navigation"><ul class="pagination justify-content-center">';

    // Previous button
    $prevDisabled = $pagination['has_prev'] ? '' : ' disabled';
    $prevPage = max(1, $pagination['current_page'] - 1);
    $prevUrl = buildPaginationUrl($baseUrl, $prevPage, $extraParams);
    $html .= "<li class='page-item{$prevDisabled}'><a class='page-link' href='{$prevUrl}'>&laquo; Prev</a></li>";

    // Page numbers
    $startPage = max(1, $pagination['current_page'] - 2);
    $endPage = min($pagination['total_pages'], $pagination['current_page'] + 2);

    if ($startPage > 1) {
        $html .= "<li class='page-item'><a class='page-link' href='" . buildPaginationUrl($baseUrl, 1, $extraParams) . "'>1</a></li>";
        if ($startPage > 2) $html .= "<li class='page-item disabled'><span class='page-link'>...</span></li>";
    }

    for ($i = $startPage; $i <= $endPage; $i++) {
        $active = ($i === $pagination['current_page']) ? ' active' : '';
        $pageUrl = buildPaginationUrl($baseUrl, $i, $extraParams);
        $html .= "<li class='page-item{$active}'><a class='page-link' href='{$pageUrl}'>{$i}</a></li>";
    }

    if ($endPage < $pagination['total_pages']) {
        if ($endPage < $pagination['total_pages'] - 1) $html .= "<li class='page-item disabled'><span class='page-link'>...</span></li>";
        $html .= "<li class='page-item'><a class='page-link' href='" . buildPaginationUrl($baseUrl, $pagination['total_pages'], $extraParams) . "'>{$pagination['total_pages']}</a></li>";
    }

    // Next button
    $nextDisabled = $pagination['has_next'] ? '' : ' disabled';
    $nextPage = min($pagination['total_pages'], $pagination['current_page'] + 1);
    $nextUrl = buildPaginationUrl($baseUrl, $nextPage, $extraParams);
    $html .= "<li class='page-item{$nextDisabled}'><a class='page-link' href='{$nextUrl}'>Next &raquo;</a></li>";

    $html .= '</ul></nav>';
    return $html;
}

/**
 * Build a pagination URL with query parameters.
 */
function buildPaginationUrl(string $baseUrl, int $page, array $params = []): string
{
    $params['page'] = $page;
    return $baseUrl . '?' . http_build_query($params);
}

// ── VALIDATION HELPERS ─────────────────────────────────────────

/**
 * Validate an email address.
 */
function isValidEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate a phone number (Ethiopian format).
 */
function isValidPhone(string $phone): bool
{
    // Accepts +251XXXXXXXXX, 0XXXXXXXXX, or 09XXXXXXXX
    return (bool) preg_match('/^(\+251|0)(9|7)\d{8}$/', preg_replace('/[\s\-]/', '', $phone));
}

/**
 * Validate password strength.
 * Minimum 8 characters, at least one uppercase, one lowercase, one digit.
 */
function isStrongPassword(string $password): bool
{
    return mb_strlen($password) >= 8
        && preg_match('/[A-Z]/', $password)
        && preg_match('/[a-z]/', $password)
        && preg_match('/\d/', $password);
}

/**
 * Get a human-readable order status badge.
 */
function orderStatusBadge(string $status): string
{
    $badges = [
        'pending'    => '<span class="badge bg-warning text-dark">Pending</span>',
        'confirmed'  => '<span class="badge bg-info text-dark">Confirmed</span>',
        'processing' => '<span class="badge bg-primary">Processing</span>',
        'in_transit' => '<span class="badge bg-info">In Transit</span>',
        'delivered'  => '<span class="badge bg-success">Delivered</span>',
        'cancelled'  => '<span class="badge bg-danger">Cancelled</span>',
        'refunded'   => '<span class="badge bg-secondary">Refunded</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-dark">' . ucfirst($status) . '</span>';
}

/**
 * Get a human-readable payment status badge.
 */
function paymentStatusBadge(string $status): string
{
    $badges = [
        'unpaid'               => '<span class="badge bg-danger">Unpaid</span>',
        'pending_verification' => '<span class="badge bg-warning text-dark">Pending Verification</span>',
        'paid'                 => '<span class="badge bg-success">Paid</span>',
        'failed'               => '<span class="badge bg-danger">Failed</span>',
        'refunded'             => '<span class="badge bg-secondary">Refunded</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-dark">' . ucfirst($status) . '</span>';
}

// ── STOCK HELPERS ──────────────────────────────────────────────

/**
 * Get stock status display.
 */
function stockStatus(int $count, int $threshold = 5): string
{
    if ($count <= 0) {
        return '<span class="badge bg-danger">Out of Stock</span>';
    } elseif ($count <= $threshold) {
        return '<span class="badge bg-warning text-dark">Low Stock (' . $count . ')</span>';
    }
    return '<span class="badge bg-success">In Stock (' . $count . ')</span>';
}

// ── JSON RESPONSE HELPER ───────────────────────────────────────

/**
 * Send a JSON response and exit.
 */
function jsonResponse(array $data, int $statusCode = 200): never
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}