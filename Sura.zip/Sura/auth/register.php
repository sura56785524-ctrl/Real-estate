<?php
/**
 * ================================================================
 * Registration Page — New Customer Account Creation
 * Features: CSRF, validation, password strength meter
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect(isAdmin() ? 'admin/index.php' : 'user/dashboard.php');
}

$errors   = [];
$formData = [
    'first_name' => '',
    'last_name'  => '',
    'email'      => '',
    'phone'      => '',
    'address'    => '',
    'city'       => '',
    'country'    => 'Ethiopia',
];

// ── Handle Registration Form Submission ────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token. Please try again.';
    } else {
        // Capture form data
        $formData = [
            'first_name'       => $_POST['first_name'] ?? '',
            'last_name'        => $_POST['last_name'] ?? '',
            'email'            => $_POST['email'] ?? '',
            'phone'            => $_POST['phone'] ?? '',
            'password'         => $_POST['password'] ?? '',
            'confirm_password' => $_POST['confirm_password'] ?? '',
            'address'          => $_POST['address'] ?? '',
            'city'             => $_POST['city'] ?? '',
            'country'          => $_POST['country'] ?? 'Ethiopia',
        ];

        // Terms agreement check
        if (empty($_POST['agree_terms'])) {
            $errors[] = 'You must agree to the Terms & Conditions.';
        }

        if (empty($errors)) {
            try {
                $userModel = new User();
                $userId = $userModel->register($formData);

                if ($userId) {
                    setFlash('success', 'Account created successfully! Please sign in to continue.');
                    redirect('auth/login.php');
                }
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
}

$pageTitle = 'Create Account — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 50%, #415a77 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 2rem 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .register-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            max-width: 1100px;
        }
        .register-brand-side {
            background: linear-gradient(135deg, #1b4332, #2d6a4f);
            color: #fff;
            padding: 3rem 2rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .register-brand-side img { max-width: 120px; margin-bottom: 1.5rem; }
        .register-brand-side h2 { font-weight: 700; font-size: 1.3rem; text-align: center; }
        .register-form-side { padding: 2.5rem; }
        .register-form-side h3 { font-weight: 700; color: #1b263b; }
        .btn-register {
            background: linear-gradient(135deg, #1b4332, #2d6a4f);
            border: none; padding: 0.75rem; font-weight: 600;
            border-radius: 8px; transition: all 0.3s ease;
        }
        .btn-register:hover {
            background: linear-gradient(135deg, #2d6a4f, #40916c);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(45,106,79,0.4);
        }
        .password-strength-bar {
            height: 4px; border-radius: 2px;
            background: #e9ecef; margin-top: 4px; overflow: hidden;
        }
        .password-strength-fill {
            height: 100%; width: 0; border-radius: 2px;
            transition: width 0.3s, background 0.3s;
        }
        .strength-weak     { width: 25%; background: #dc3545; }
        .strength-fair     { width: 50%; background: #fd7e14; }
        .strength-good     { width: 75%; background: #ffc107; }
        .strength-strong   { width: 100%; background: #198754; }
        .feature-item { display: flex; align-items: start; gap: 0.75rem; margin-bottom: 1rem; }
        .feature-icon {
            width: 36px; height: 36px; border-radius: 50%;
            background: rgba(255,255,255,0.15); display: flex;
            align-items: center; justify-content: center; flex-shrink: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="register-card mx-auto">
            <div class="row g-0">
                <!-- Left Brand Side -->
                <div class="col-lg-4 d-none d-lg-flex register-brand-side">
                    <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>" class="img-fluid">
                    <h2><?= sanitize(SITE_NAME) ?></h2>
                    <p class="text-center mt-2" style="opacity:0.85;"><?= sanitize(SITE_TAGLINE) ?></p>

                    <div class="mt-4 w-100">
                        <div class="feature-item">
                            <div class="feature-icon"><i class="bi bi-truck"></i></div>
                            <div>
                                <strong class="small">Fast Delivery</strong>
                                <p class="small mb-0" style="opacity:0.8;">Nationwide import/export shipping</p>
                            </div>
                        </div>
                        <div class="feature-item">
                            <div class="feature-icon"><i class="bi bi-shield-check"></i></div>
                            <div>
                                <strong class="small">Secure Payments</strong>
                                <p class="small mb-0" style="opacity:0.8;">Chapa, SantimPay & Bank Transfer</p>
                            </div>
                        </div>
                        <div class="feature-item">
                            <div class="feature-icon"><i class="bi bi-box-seam"></i></div>
                            <div>
                                <strong class="small">Bulk Orders</strong>
                                <p class="small mb-0" style="opacity:0.8;">Wholesale pricing for businesses</p>
                            </div>
                        </div>
                        <div class="feature-item">
                            <div class="feature-icon"><i class="bi bi-headset"></i></div>
                            <div>
                                <strong class="small">24/7 Support</strong>
                                <p class="small mb-0" style="opacity:0.8;">Dedicated customer service team</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Form Side -->
                <div class="col-lg-8 register-form-side">
                    <!-- Mobile Logo -->
                    <div class="text-center d-lg-none mb-3">
                        <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>" style="max-width: 70px;">
                    </div>

                    <h3><i class="bi bi-person-plus me-2"></i>Create Account</h3>
                    <p class="text-muted small mb-3">Join us and start ordering quality stationery today</p>

                    <!-- Errors -->
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger alert-dismissible fade show py-2" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-1"></i>
                            <?php foreach ($errors as $error): ?>
                                <?= $error ?><br>
                            <?php endforeach; ?>
                            <button type="button" class="btn-close btn-close-sm" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?= renderFlash() ?>

                    <!-- Registration Form -->
                    <form method="POST" action="" novalidate id="registerForm">
                        <?= csrfField() ?>

                        <div class="row">
                            <!-- First Name -->
                            <div class="col-md-6 mb-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="first_name" name="first_name"
                                           placeholder="First Name" value="<?= sanitize($formData['first_name']) ?>" required>
                                    <label for="first_name"><i class="bi bi-person me-1"></i> First Name *</label>
                                </div>
                            </div>
                            <!-- Last Name -->
                            <div class="col-md-6 mb-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="last_name" name="last_name"
                                           placeholder="Last Name" value="<?= sanitize($formData['last_name']) ?>" required>
                                    <label for="last_name"><i class="bi bi-person me-1"></i> Last Name *</label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <!-- Email -->
                            <div class="col-md-6 mb-3">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="email" name="email"
                                           placeholder="Email" value="<?= sanitize($formData['email']) ?>" required>
                                    <label for="email"><i class="bi bi-envelope me-1"></i> Email Address *</label>
                                </div>
                            </div>
                            <!-- Phone -->
                            <div class="col-md-6 mb-3">
                                <div class="form-floating">
                                    <input type="tel" class="form-control" id="phone" name="phone"
                                           placeholder="Phone" value="<?= sanitize($formData['phone']) ?>">
                                    <label for="phone"><i class="bi bi-telephone me-1"></i> Phone (e.g., 0911...)</label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <!-- Password -->
                            <div class="col-md-6 mb-3">
                                <div class="form-floating position-relative">
                                    <input type="password" class="form-control" id="password" name="password"
                                           placeholder="Password" required autocomplete="new-password"
                                           oninput="checkPasswordStrength(this.value)">
                                    <label for="password"><i class="bi bi-lock me-1"></i> Password *</label>
                                    <span class="toggle-password" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;z-index:5;color:#6c757d;"
                                          onclick="togglePasswordVisibility('password', this)">
                                        <i class="bi bi-eye"></i>
                                    </span>
                                </div>
                                <div class="password-strength-bar">
                                    <div class="password-strength-fill" id="strengthFill"></div>
                                </div>
                                <small class="text-muted" id="strengthText">Min 8 chars, uppercase, lowercase, digit</small>
                            </div>
                            <!-- Confirm Password -->
                            <div class="col-md-6 mb-3">
                                <div class="form-floating position-relative">
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                                           placeholder="Confirm Password" required autocomplete="new-password">
                                    <label for="confirm_password"><i class="bi bi-lock-fill me-1"></i> Confirm Password *</label>
                                    <span class="toggle-password" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;z-index:5;color:#6c757d;"
                                          onclick="togglePasswordVisibility('confirm_password', this)">
                                        <i class="bi bi-eye"></i>
                                    </span>
                                </div>
                                <small class="text-danger d-none" id="matchError">Passwords do not match</small>
                            </div>
                        </div>

                        <div class="row">
                            <!-- Address -->
                            <div class="col-md-6 mb-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="address" name="address"
                                           placeholder="Address" value="<?= sanitize($formData['address']) ?>">
                                    <label for="address"><i class="bi bi-geo-alt me-1"></i> Address</label>
                                </div>
                            </div>
                            <!-- City -->
                            <div class="col-md-3 mb-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="city" name="city"
                                           placeholder="City" value="<?= sanitize($formData['city']) ?>">
                                    <label for="city"><i class="bi bi-building me-1"></i> City</label>
                                </div>
                            </div>
                            <!-- Country -->
                            <div class="col-md-3 mb-3">
                                <div class="form-floating">
                                    <select class="form-select" id="country" name="country">
                                        <option value="Ethiopia" <?= $formData['country'] === 'Ethiopia' ? 'selected' : '' ?>>Ethiopia</option>
                                        <option value="Kenya" <?= $formData['country'] === 'Kenya' ? 'selected' : '' ?>>Kenya</option>
                                        <option value="Djibouti" <?= $formData['country'] === 'Djibouti' ? 'selected' : '' ?>>Djibouti</option>
                                        <option value="Somalia" <?= $formData['country'] === 'Somalia' ? 'selected' : '' ?>>Somalia</option>
                                        <option value="Sudan" <?= $formData['country'] === 'Sudan' ? 'selected' : '' ?>>Sudan</option>
                                        <option value="Eritrea" <?= $formData['country'] === 'Eritrea' ? 'selected' : '' ?>>Eritrea</option>
                                        <option value="Other" <?= $formData['country'] === 'Other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                    <label for="country"><i class="bi bi-globe me-1"></i> Country</label>
                                </div>
                            </div>
                        </div>

                        <!-- Terms & Conditions -->
                        <div class="form-check mb-3">
                            <input type="checkbox" class="form-check-input" id="agree_terms" name="agree_terms" value="1" required>
                            <label class="form-check-label small" for="agree_terms">
                                I agree to the <a href="#" class="text-decoration-none" style="color:#2d6a4f;">Terms & Conditions</a>
                                and <a href="#" class="text-decoration-none" style="color:#2d6a4f;">Privacy Policy</a>
                            </label>
                        </div>

                        <!-- Submit -->
                        <button type="submit" class="btn btn-register text-white w-100 mb-3" id="registerBtn">
                            <span class="btn-text"><i class="bi bi-person-plus me-1"></i> Create Account</span>
                            <span class="spinner-border spinner-border-sm d-none" id="registerSpinner" role="status"></span>
                        </button>
                    </form>

                    <div class="text-center">
                        <p class="mb-0 text-muted small">
                            Already have an account?
                            <a href="<?= url('auth/login.php') ?>" class="fw-semibold text-decoration-none" style="color:#2d6a4f;">
                                Sign In <i class="bi bi-arrow-right"></i>
                            </a>
                        </p>
                    </div>

                    <div class="text-center mt-2">
                        <a href="<?= url() ?>" class="small text-muted text-decoration-none">
                            <i class="bi bi-arrow-left me-1"></i> Back to Shop
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        function togglePasswordVisibility(inputId, toggleEl) {
            const input = document.getElementById(inputId);
            const icon = toggleEl.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        }

        // Password strength meter
        function checkPasswordStrength(password) {
            const fill = document.getElementById('strengthFill');
            const text = document.getElementById('strengthText');
            let score = 0;

            if (password.length >= 8)      score++;
            if (/[A-Z]/.test(password))    score++;
            if (/[a-z]/.test(password))    score++;
            if (/\d/.test(password))       score++;
            if (/[^A-Za-z0-9]/.test(password)) score++;

            fill.className = 'password-strength-fill';
            if (score <= 1) {
                fill.classList.add('strength-weak');
                text.textContent = 'Weak password';
                text.className = 'small text-danger';
            } else if (score === 2) {
                fill.classList.add('strength-fair');
                text.textContent = 'Fair password';
                text.className = 'small text-warning';
            } else if (score === 3 || score === 4) {
                fill.classList.add('strength-good');
                text.textContent = 'Good password';
                text.className = 'small text-info';
            } else {
                fill.classList.add('strength-strong');
                text.textContent = 'Strong password ✓';
                text.className = 'small text-success';
            }

            if (password.length === 0) {
                fill.className = 'password-strength-fill';
                text.textContent = 'Min 8 chars, uppercase, lowercase, digit';
                text.className = 'small text-muted';
            }
        }

        // Password match check
        document.getElementById('confirm_password').addEventListener('input', function() {
            const match = document.getElementById('matchError');
            if (this.value && this.value !== document.getElementById('password').value) {
                match.classList.remove('d-none');
            } else {
                match.classList.add('d-none');
            }
        });

        // Form submit loading
        document.getElementById('registerForm').addEventListener('submit', function() {
            const btn = document.getElementById('registerBtn');
            const spinner = document.getElementById('registerSpinner');
            const btnText = btn.querySelector('.btn-text');
            btn.disabled = true;
            spinner.classList.remove('d-none');
            btnText.textContent = ' Creating account...';
        });
    </script>
</body>
</html>