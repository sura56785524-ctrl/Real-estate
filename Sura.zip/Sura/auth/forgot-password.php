<?php
/**
 * ================================================================
 * Forgot Password — Request a Password Reset Link
 * In production, this would send an email with a token link.
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';

if (isLoggedIn()) {
    redirect('user/dashboard.php');
}

$errors      = [];
$success     = false;
$email       = '';
$resetToken  = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token.';
    } else {
        $email = trim($_POST['email'] ?? '');

        if (empty($email) || !isValidEmail($email)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($errors)) {
            try {
                $userModel = new User();
                $token = $userModel->generateResetToken($email);

                // Always show success message to prevent email enumeration
                $success = true;

                // In production, you'd send an email here:
                // $resetLink = url('auth/reset-password.php?token=' . $token);
                // sendEmail($email, 'Password Reset', "Click here: {$resetLink}");

                // For development: store the token for display
                if ($token) {
                    $resetToken = $token;
                }

            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
}

$pageTitle = 'Forgot Password — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 50%, #415a77 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .forgot-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
            padding: 3rem;
        }
        .btn-reset {
            background: linear-gradient(135deg, #1b4332, #2d6a4f);
            border: none; padding: 0.75rem; font-weight: 600;
            border-radius: 8px; transition: all 0.3s ease;
        }
        .btn-reset:hover {
            background: linear-gradient(135deg, #2d6a4f, #40916c);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(45,106,79,0.4);
        }
        .lock-icon {
            width: 80px; height: 80px; border-radius: 50%;
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 1.5rem;
        }
        .lock-icon i { font-size: 2rem; color: #2d6a4f; }
    </style>
</head>
<body>
    <div class="container">
        <div class="forgot-card mx-auto text-center">
            <div class="lock-icon">
                <i class="bi bi-key"></i>
            </div>

            <h3 class="fw-bold mb-1" style="color:#1b263b;">Forgot Password?</h3>
            <p class="text-muted small mb-4">Enter your email and we'll help you reset your password.</p>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="bi bi-check-circle-fill me-1"></i>
                    If an account exists with that email, a password reset link has been sent.
                </div>

                <?php if ($resetToken): ?>
                    <!-- DEV ONLY: Show reset link (remove in production) -->
                    <div class="alert alert-info text-start small">
                        <strong><i class="bi bi-code-slash me-1"></i> Dev Mode — Reset Link:</strong><br>
                        <a href="<?= url('auth/reset-password.php?token=' . $resetToken) ?>" class="text-break">
                            <?= url('auth/reset-password.php?token=' . $resetToken) ?>
                        </a>
                    </div>
                <?php endif; ?>

                <a href="<?= url('auth/login.php') ?>" class="btn btn-reset text-white w-100 mt-2">
                    <i class="bi bi-box-arrow-in-right me-1"></i> Back to Login
                </a>
            <?php else: ?>
                <!-- Errors -->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger text-start py-2">
                        <i class="bi bi-exclamation-triangle-fill me-1"></i>
                        <?php foreach ($errors as $error): ?>
                            <?= sanitize($error) ?><br>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" novalidate class="text-start">
                    <?= csrfField() ?>

                    <div class="form-floating mb-3">
                        <input type="email" class="form-control" id="email" name="email"
                               placeholder="Email" value="<?= sanitize($email) ?>" required autofocus>
                        <label for="email"><i class="bi bi-envelope me-1"></i> Email Address</label>
                    </div>

                    <button type="submit" class="btn btn-reset text-white w-100 mb-3">
                        <i class="bi bi-send me-1"></i> Send Reset Link
                    </button>
                </form>
            <?php endif; ?>

            <div class="mt-3">
                <a href="<?= url('auth/login.php') ?>" class="small text-muted text-decoration-none">
                    <i class="bi bi-arrow-left me-1"></i> Back to Login
                </a>
                <span class="mx-2 text-muted">|</span>
                <a href="<?= url('auth/register.php') ?>" class="small text-muted text-decoration-none">
                    Create Account <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>