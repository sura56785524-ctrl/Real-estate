<?php
/**
 * ================================================================
 * Logout — Destroy Session & Redirect
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';

$userModel = new User();
$userModel->destroySession();

// Start a fresh session so we can set a flash message
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

setFlash('success', 'You have been logged out successfully.');
redirect('auth/login.php');