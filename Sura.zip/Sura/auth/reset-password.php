<?php
/**
 * ================================================================
 * Reset Password — Validate Token & Set New Password
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';

if (isLoggedIn()) {
    redirect('user/dashboard.php');
}

$errors    = [];
$success   = false;
$token     = $_GET['token'] ?? $_POST['token'] ?? '';
$validToken = false;
$tokenUser  = null;

// Validate the token on GET request
$userModel = new User();

if (!empty($token)) {
    $tokenUser = $userModel->validateResetToken($token);
    if ($tokenUser) {
        $validToken = true;
    }
}

// ── Handle Password Reset Form Submission ──────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token.';
    } else {
        $token           = $_POST['token'] ?? '';
        $newPassword     = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (empty($newPassword) || mb_strlen($newPassword) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        }
        if ($newPassword !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }

        if (empty($errors)) {
            try {
                $result = $userModel->resetPassword($token, $newPassword);
                if ($result) {
                    $success = true;
                    setFlash('success', 'Password reset successfully! Please sign in with your new password.');
                }
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        } else {
            // Re-validate token for form display
            $tokenUser = $userModel->validateResetToken($token);
            $validToken = $tokenUser ? true : false;
        }
    }
}

$pageTitle = 'Reset Password — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 50%, #415a77 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .reset-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
            padding: 3rem;
        }
        .btn-save {
            background: linear-gradient(135deg, #1b4332, #2d6a4f);
            border: none; padding: 0.75rem; font-weight: 600;
            border-radius: 8px; transition: all 0.3s ease;
        }
        .btn-save:hover {
            background: linear-gradient(135deg, #2d6a4f, #40916c);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(45,106,79,0.4);
        }
        .reset-icon {
            width: 80px; height: 80px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 1.5rem;
        }
        .reset-icon.pending { background: linear-gradient(135deg, #e8f5e9, #c8e6c9); }
        .reset-icon.pending i { font-size: 2rem; color: #2d6a4f; }
        .reset-icon.success { background: linear-gradient(135deg, #d4edda, #c3e6cb); }
        .reset-icon.success i { font-size: 2rem; color: #155724; }
        .reset-icon.error { background: linear-gradient(135deg, #f8d7da, #f5c6cb); }
        .reset-icon.error i { font-size: 2rem; color: #721c24; }
    </style>
</head>
<body>
    <div class="container">
        <div class="reset-card mx-auto text-center">

            <?php if ($success): ?>
                <!-- SUCCESS STATE -->
                <div class="reset-icon success">
                    <i class="bi bi-check-circle"></i>
                </div>
                <h3 class="fw-bold mb-2" style="color:#155724;">Password Reset!</h3>
                <p class="text-muted mb-4">Your password has been updated successfully.</p>
                <a href="<?= url('auth/login.php') ?>" class="btn btn-save text-white w-100">
                    <i class="bi bi-box-arrow-in-right me-1"></i> Sign In Now
                </a>

            <?php elseif ($validToken && $tokenUser): ?>
                <!-- VALID TOKEN — SHOW FORM -->
                <div class="reset-icon pending">
                    <i class="bi bi-shield-lock"></i>
                </div>
                <h3 class="fw-bold mb-1" style="color:#1b263b;">Set New Password</h3>
                <p class="text-muted small mb-3">
                    Hello <strong><?= sanitize($tokenUser['first_name']) ?></strong>,
                    enter your new password below.
                </p>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger text-start py-2">
                        <?php foreach ($errors as $error): ?>
                            <?= sanitize($error) ?><br>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" novalidate class="text-start">
                    <?= csrfField() ?>
                    <input type="hidden" name="token" value="<?= sanitize($token) ?>">

                    <div class="form-floating mb-3 position-relative">
                        <input type="password" class="form-control" id="password" name="password"
                               placeholder="New Password" required autofocus>
                        <label for="password"><i class="bi bi-lock me-1"></i> New Password</label>
                        <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;z-index:5;color:#6c757d;"
                              onclick="togglePwdVis('password', this)">
                            <i class="bi bi-eye"></i>
                        </span>
                    </div>

                    <div class="form-floating mb-3 position-relative">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                               placeholder="Confirm" required>
                        <label for="confirm_password"><i class="bi bi-lock-fill me-1"></i> Confirm Password</label>
                        <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;z-index:5;color:#6c757d;"
                              onclick="togglePwdVis('confirm_password', this)">
                            <i class="bi bi-eye"></i>
                        </span>
                    </div>

                    <div class="small text-muted mb-3">
                        <i class="bi bi-info-circle me-1"></i>
                        Min 8 characters with uppercase, lowercase, and a digit.
                    </div>

                    <button type="submit" class="btn btn-save text-white w-100">
                        <i class="bi bi-check-lg me-1"></i> Reset Password
                    </button>
                </form>

            <?php else: ?>
                <!-- INVALID/EXPIRED TOKEN -->
                <div class="reset-icon error">
                    <i class="bi bi-x-circle"></i>
                </div>
                <h3 class="fw-bold mb-2" style="color:#721c24;">Invalid or Expired Link</h3>
                <p class="text-muted mb-4">
                    This password reset link is no longer valid. Please request a new one.
                </p>
                <a href="<?= url('auth/forgot-password.php') ?>" class="btn btn-save text-white w-100 mb-3">
                    <i class="bi bi-envelope me-1"></i> Request New Link
                </a>
            <?php endif; ?>

            <div class="mt-3">
                <a href="<?= url('auth/login.php') ?>" class="small text-muted text-decoration-none">
                    <i class="bi bi-arrow-left me-1"></i> Back to Login
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePwdVis(id, el) {
            const inp = document.getElementById(id);
            const icon = el.querySelector('i');
            if (inp.type === 'password') {
                inp.type = 'text';
                icon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                inp.type = 'password';
                icon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        }
    </script>
</body>
</html>