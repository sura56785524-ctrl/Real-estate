<?php
/**
 * ================================================================
 * Login Page — User & Admin Authentication
 * Features: CSRF protection, brute-force lockout, remember me
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';

// If already logged in, redirect accordingly
if (isLoggedIn()) {
    redirect(isAdmin() ? 'admin/index.php' : 'user/dashboard.php');
}

$errors = [];
$email  = '';

// ── Handle Login Form Submission ───────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Validate CSRF token
    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token. Please try again.';
    } else {
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Basic validation
        if (empty($email) || empty($password)) {
            $errors[] = 'Please enter both email and password.';
        }

        if (empty($errors)) {
            try {
                $userModel = new User();
                $user = $userModel->authenticate($email, $password);

                if ($user) {
                    // Create session
                    $userModel->createSession($user);

                    // Set success flash
                    setFlash('success', 'Welcome back, ' . sanitize($user['first_name']) . '!');

                    // Redirect based on role
                    if ($user['role'] === 'admin') {
                        redirect('admin/index.php');
                    } else {
                        // Check if there's a redirect URL stored
                        $redirectUrl = $_SESSION['redirect_after_login'] ?? 'user/dashboard.php';
                        unset($_SESSION['redirect_after_login']);
                        redirect($redirectUrl);
                    }
                } else {
                    $errors[] = 'Invalid email or password.';
                }
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
}

// ── Page Meta ──────────────────────────────────────────────────
$pageTitle = 'Login — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 50%, #415a77 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            max-width: 960px;
            width: 100%;
        }
        .login-brand-side {
            background: linear-gradient(135deg, #1b4332, #2d6a4f);
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 3rem 2rem;
        }
        .login-brand-side img {
            max-width: 130px;
            margin-bottom: 1.5rem;
            filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3));
        }
        .login-brand-side h2 {
            font-weight: 700;
            font-size: 1.4rem;
            text-align: center;
            line-height: 1.4;
        }
        .login-brand-side p {
            opacity: 0.85;
            font-size: 0.95rem;
            text-align: center;
        }
        .login-form-side {
            padding: 3rem 2.5rem;
        }
        .login-form-side h3 {
            font-weight: 700;
            color: #1b263b;
            margin-bottom: 0.25rem;
        }
        .login-form-side .subtitle {
            color: #6c757d;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }
        .form-floating > .form-control:focus {
            border-color: #2d6a4f;
            box-shadow: 0 0 0 0.2rem rgba(45, 106, 79, 0.25);
        }
        .btn-login {
            background: linear-gradient(135deg, #1b4332, #2d6a4f);
            border: none;
            padding: 0.75rem;
            font-weight: 600;
            font-size: 1.05rem;
            letter-spacing: 0.5px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-login:hover {
            background: linear-gradient(135deg, #2d6a4f, #40916c);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(45,106,79,0.4);
        }
        .toggle-password {
            cursor: pointer;
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 5;
            color: #6c757d;
        }
        .divider {
            display: flex;
            align-items: center;
            margin: 1.25rem 0;
            color: #adb5bd;
            font-size: 0.85rem;
        }
        .divider::before, .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #dee2e6;
        }
        .divider::before { margin-right: 0.75rem; }
        .divider::after { margin-left: 0.75rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-card mx-auto">
            <div class="row g-0">
                <!-- Left Brand Side -->
                <div class="col-lg-5 d-none d-lg-flex login-brand-side">
                    <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>" class="img-fluid">
                    <h2><?= sanitize(SITE_NAME) ?></h2>
                    <p class="mt-2"><?= sanitize(SITE_TAGLINE) ?></p>
                    <div class="mt-4 text-center" style="opacity: 0.7;">
                        <i class="bi bi-shield-lock fs-1"></i>
                        <p class="mt-2 small">Your account is secured with<br>industry-standard encryption</p>
                    </div>
                </div>

                <!-- Right Form Side -->
                <div class="col-lg-7 login-form-side">
                    <!-- Mobile Logo -->
                    <div class="text-center d-lg-none mb-4">
                        <img src="<?= logoUrl() ?>" alt="<?= sanitize(SITE_NAME) ?>" style="max-width: 80px;">
                    </div>

                    <h3><i class="bi bi-box-arrow-in-right me-2"></i>Sign In</h3>
                    <p class="subtitle">Enter your credentials to access your account</p>

                    <!-- Error Messages -->
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger alert-dismissible fade show py-2" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-1"></i>
                            <?php foreach ($errors as $error): ?>
                                <?= sanitize($error) ?><br>
                            <?php endforeach; ?>
                            <button type="button" class="btn-close btn-close-sm" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Flash Messages -->
                    <?= renderFlash() ?>

                    <!-- Login Form -->
                    <form method="POST" action="" novalidate autocomplete="on" id="loginForm">
                        <?= csrfField() ?>

                        <!-- Email Field -->
                        <div class="form-floating mb-3">
                            <input
                                type="email"
                                class="form-control"
                                id="email"
                                name="email"
                                placeholder="name@example.com"
                                value="<?= sanitize($email) ?>"
                                required
                                autofocus
                                autocomplete="email"
                            >
                            <label for="email"><i class="bi bi-envelope me-1"></i> Email Address</label>
                        </div>

                        <!-- Password Field -->
                        <div class="form-floating mb-3 position-relative">
                            <input
                                type="password"
                                class="form-control"
                                id="password"
                                name="password"
                                placeholder="Password"
                                required
                                autocomplete="current-password"
                            >
                            <label for="password"><i class="bi bi-lock me-1"></i> Password</label>
                            <span class="toggle-password" onclick="togglePasswordVisibility('password', this)">
                                <i class="bi bi-eye"></i>
                            </span>
                        </div>

                        <!-- Remember Me & Forgot Password -->
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label small" for="remember">Remember me</label>
                            </div>
                            <a href="<?= url('auth/forgot-password.php') ?>" class="small text-decoration-none" style="color: #2d6a4f;">
                                Forgot Password?
                            </a>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-login text-white w-100 mb-3" id="loginBtn">
                            <span class="btn-text"><i class="bi bi-box-arrow-in-right me-1"></i> Sign In</span>
                            <span class="spinner-border spinner-border-sm d-none" id="loginSpinner" role="status"></span>
                        </button>
                    </form>

                    <div class="divider">or</div>

                    <!-- Register Link -->
                    <div class="text-center">
                        <p class="mb-0 text-muted small">
                            Don't have an account?
                            <a href="<?= url('auth/register.php') ?>" class="fw-semibold text-decoration-none" style="color: #2d6a4f;">
                                Create Account <i class="bi bi-arrow-right"></i>
                            </a>
                        </p>
                    </div>

                    <!-- Back to Shop -->
                    <div class="text-center mt-3">
                        <a href="<?= url() ?>" class="small text-muted text-decoration-none">
                            <i class="bi bi-arrow-left me-1"></i> Back to Shop
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        function togglePasswordVisibility(inputId, toggleEl) {
            const input = document.getElementById(inputId);
            const icon = toggleEl.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        }

        // Form submission with loading state
        document.getElementById('loginForm').addEventListener('submit', function() {
            const btn = document.getElementById('loginBtn');
            const spinner = document.getElementById('loginSpinner');
            const btnText = btn.querySelector('.btn-text');
            btn.disabled = true;
            spinner.classList.remove('d-none');
            btnText.textContent = ' Signing in...';
        });
    </script>
</body>
</html>