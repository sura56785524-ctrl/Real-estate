<?php
/**
 * ================================================================
 * User Dashboard — Overview of account, orders, quick actions
 * ================================================================
 */

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireLogin();

$userModel  = new User();
$orderModel = new Order();

$user      = $userModel->findById(currentUserId());
$stats     = $orderModel->getStats(currentUserId());
$recentOrders = $orderModel->getRecent(5, currentUserId());

$pageTitle = 'My Dashboard — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>
    <div class="container mt-3"><?= renderFlash() ?></div>

    <div class="container py-4">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-lg-3 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center py-4">
                        <div class="rounded-circle bg-success text-white d-inline-flex align-items-center justify-content-center mb-3"
                             style="width:70px;height:70px;font-size:1.8rem;">
                            <?= strtoupper(mb_substr($user['first_name'], 0, 1) . mb_substr($user['last_name'], 0, 1)) ?>
                        </div>
                        <h5 class="fw-bold mb-0"><?= sanitize($user['first_name'] . ' ' . $user['last_name']) ?></h5>
                        <small class="text-muted"><?= sanitize($user['email']) ?></small>
                        <p class="small text-muted mt-1">Member since <?= formatDate($user['created_at'], 'M Y') ?></p>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="<?= url('user/dashboard.php') ?>" class="list-group-item list-group-item-action active" style="background:#2d6a4f;border-color:#2d6a4f;">
                            <i class="bi bi-speedometer2 me-2"></i> Dashboard
                        </a>
                        <a href="<?= url('user/orders.php') ?>" class="list-group-item list-group-item-action">
                            <i class="bi bi-box-seam me-2"></i> My Orders
                            <span class="badge bg-success float-end"><?= $stats['total_orders'] ?></span>
                        </a>
                        <a href="<?= url('user/profile.php') ?>" class="list-group-item list-group-item-action">
                            <i class="bi bi-person-gear me-2"></i> Profile Settings
                        </a>
                        <a href="<?= url('shop.php') ?>" class="list-group-item list-group-item-action">
                            <i class="bi bi-bag me-2"></i> Continue Shopping
                        </a>
                        <a href="<?= url('auth/logout.php') ?>" class="list-group-item list-group-item-action text-danger">
                            <i class="bi bi-box-arrow-right me-2"></i> Logout
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-lg-9">
                <h4 class="fw-bold mb-4">
                    <i class="bi bi-speedometer2 me-2"></i>Welcome back, <?= sanitize($user['first_name']) ?>!
                </h4>

                <!-- Stats Cards -->
                <div class="row g-3 mb-4">
                    <div class="col-6 col-md-3">
                        <div class="card border-0 shadow-sm text-center py-3">
                            <div class="card-body p-2">
                                <i class="bi bi-box-seam fs-3 text-primary"></i>
                                <h4 class="fw-bold mb-0 mt-1"><?= $stats['total_orders'] ?></h4>
                                <small class="text-muted">Total Orders</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="card border-0 shadow-sm text-center py-3">
                            <div class="card-body p-2">
                                <i class="bi bi-clock fs-3 text-warning"></i>
                                <h4 class="fw-bold mb-0 mt-1"><?= $stats['pending'] ?></h4>
                                <small class="text-muted">Pending</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="card border-0 shadow-sm text-center py-3">
                            <div class="card-body p-2">
                                <i class="bi bi-truck fs-3 text-info"></i>
                                <h4 class="fw-bold mb-0 mt-1"><?= $stats['in_transit'] ?></h4>
                                <small class="text-muted">In Transit</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="card border-0 shadow-sm text-center py-3">
                            <div class="card-body p-2">
                                <i class="bi bi-check-circle fs-3 text-success"></i>
                                <h4 class="fw-bold mb-0 mt-1"><?= $stats['delivered'] ?></h4>
                                <small class="text-muted">Delivered</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Orders -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h6 class="fw-bold mb-0"><i class="bi bi-clock-history me-2"></i>Recent Orders</h6>
                        <a href="<?= url('user/orders.php') ?>" class="btn btn-sm btn-outline-success">View All</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($recentOrders)): ?>
                            <div class="text-center py-4">
                                <i class="bi bi-inbox text-muted fs-1"></i>
                                <p class="text-muted mt-2">No orders yet. <a href="<?= url('shop.php') ?>">Start shopping!</a></p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover mb-0 small">
                                    <thead class="bg-light">
                                        <tr>
                                            <th>Order #</th>
                                            <th>Date</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Payment</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recentOrders as $order): ?>
                                            <tr>
                                                <td class="fw-bold"><?= sanitize($order['order_number']) ?></td>
                                                <td><?= formatDate($order['created_at']) ?></td>
                                                <td class="fw-bold"><?= formatPrice($order['total_amount']) ?></td>
                                                <td><?= orderStatusBadge($order['status']) ?></td>
                                                <td><?= paymentStatusBadge($order['payment_status']) ?></td>
                                                <td>
                                                    <a href="<?= url('user/order-detail.php?id=' . $order['id']) ?>"
                                                       class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include INCLUDES_PATH . 'footer.php'; ?>
</body>
</html>