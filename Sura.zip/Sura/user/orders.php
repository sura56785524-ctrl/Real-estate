<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireLogin();

$orderModel = new Order();

$filters = [
    'status' => $_GET['status'] ?? '',
    'search' => $_GET['search'] ?? '',
];
$page = max(1, (int) ($_GET['page'] ?? 1));

$result     = $orderModel->getUserOrders(currentUserId(), $page, ORDERS_PER_PAGE, $filters);
$orders     = $result['orders'];
$pagination = $result['pagination'];

$pageTitle = 'My Orders — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>
    <div class="container mt-3"><?= renderFlash() ?></div>

    <div class="container py-4">
        <h4 class="fw-bold mb-4"><i class="bi bi-box-seam me-2"></i>My Orders</h4>

        <!-- Filters -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">Search Order #</label>
                        <input type="text" class="form-control form-control-sm" name="search"
                               value="<?= sanitize($filters['search']) ?>" placeholder="ORD-...">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold">Status</label>
                        <select class="form-select form-select-sm" name="status">
                            <option value="">All Statuses</option>
                            <?php foreach (['pending','confirmed','processing','in_transit','delivered','cancelled'] as $s): ?>
                                <option value="<?= $s ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>>
                                    <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-success btn-sm w-100" style="background:#2d6a4f;border-color:#2d6a4f;">
                            <i class="bi bi-search me-1"></i> Filter
                        </button>
                    </div>
                    <div class="col-md-2">
                        <a href="<?= url('user/orders.php') ?>" class="btn btn-outline-secondary btn-sm w-100">Clear</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Orders Table -->
        <?php if (empty($orders)): ?>
            <div class="text-center py-5">
                <i class="bi bi-inbox display-1 text-muted"></i>
                <h4 class="mt-3 text-muted">No orders found</h4>
                <a href="<?= url('shop.php') ?>" class="btn btn-success mt-2" style="background:#2d6a4f;">Start Shopping</a>
            </div>
        <?php else: ?>
            <div class="card border-0 shadow-sm">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>Order #</th>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td class="fw-bold small"><?= sanitize($order['order_number']) ?></td>
                                    <td class="small"><?= formatDate($order['created_at']) ?></td>
                                    <td>
                                        <?php
                                        $itemCount = $orderModel->db ?? Database::getInstance();
                                        $cnt = Database::getInstance()->fetchColumn(
                                            "SELECT SUM(quantity) FROM order_items WHERE order_id = ?", [$order['id']]
                                        );
                                        echo (int) $cnt . ' items';
                                        ?>
                                    </td>
                                    <td class="fw-bold"><?= formatPrice($order['total_amount']) ?></td>
                                    <td><?= orderStatusBadge($order['status']) ?></td>
                                    <td><?= paymentStatusBadge($order['payment_status']) ?></td>
                                    <td class="text-center">
                                        <a href="<?= url('user/order-detail.php?id=' . $order['id']) ?>"
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye me-1"></i>View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="mt-4">
                <?= renderPagination($pagination, 'user/orders.php', array_filter($filters)) ?>
            </div>
        <?php endif; ?>
    </div>

    <?php include INCLUDES_PATH . 'footer.php'; ?>
</body>
</html>