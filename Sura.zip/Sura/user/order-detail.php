<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireLogin();

$orderModel = new Order();
$orderId = (int) ($_GET['id'] ?? 0);
$order = $orderModel->findById($orderId);

if (!$order || (int) $order['user_id'] !== currentUserId()) {
    setFlash('error', 'Order not found.');
    redirect('user/orders.php');
}

$items = $orderModel->getOrderItems($orderId);
$errors = [];

// Handle receipt upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['receipt'])) {
    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token.';
    } else {
        $path = uploadImage($_FILES['receipt'], RECEIPT_IMG_PATH, 'receipt_');
        if ($path) {
            $orderModel->uploadReceipt($orderId, $path);
            setFlash('success', 'Receipt uploaded! We will verify your payment shortly.');
            redirect('user/order-detail.php?id=' . $orderId);
        } else {
            $errors[] = 'Failed to upload receipt. Please try again.';
        }
    }
}

$pageTitle = 'Order ' . sanitize($order['order_number']) . ' — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>
    <div class="container mt-3"><?= renderFlash() ?></div>

    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-bold mb-0">
                <i class="bi bi-receipt me-2"></i>Order <?= sanitize($order['order_number']) ?>
            </h4>
            <a href="<?= url('user/orders.php') ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i>Back to Orders
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $e): echo sanitize($e) . '<br>'; endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <!-- Order Info -->
            <div class="col-lg-8">
                <!-- Status Timeline -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white fw-bold"><i class="bi bi-geo-alt me-2"></i>Order Status</div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between text-center small">
                            <?php
                            $statuses = ['pending', 'confirmed', 'processing', 'in_transit', 'delivered'];
                            $currentIdx = array_search($order['status'], $statuses);
                            if ($order['status'] === 'cancelled') $currentIdx = -1;
                            foreach ($statuses as $idx => $s):
                                $done = $idx <= $currentIdx;
                                $color = $done ? '#2d6a4f' : '#dee2e6';
                            ?>
                                <div class="flex-fill">
                                    <div class="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                                         style="width:35px;height:35px;background:<?= $color ?>;color:#fff;">
                                        <i class="bi <?= $done ? 'bi-check' : 'bi-circle' ?>"></i>
                                    </div>
                                    <small class="mt-1 d-block" style="color:<?= $done ? '#2d6a4f' : '#adb5bd' ?>;">
                                        <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                    </small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php if ($order['status'] === 'cancelled'): ?>
                            <div class="alert alert-danger mt-3 mb-0 py-2">
                                <i class="bi bi-x-circle me-1"></i> This order was cancelled on <?= formatDateTime($order['cancelled_at']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Order Items -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white fw-bold"><i class="bi bi-bag me-2"></i>Order Items</div>
                    <div class="table-responsive">
                        <table class="table mb-0 small">
                            <thead class="bg-light">
                                <tr><th>Product</th><th class="text-center">Qty</th><th class="text-end">Price</th><th class="text-end">Total</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?= productImageUrl($item['product_image']) ?>" class="rounded" style="width:45px;height:45px;object-fit:cover;">
                                                <div>
                                                    <strong><?= sanitize($item['product_name']) ?></strong><br>
                                                    <small class="text-muted">SKU: <?= sanitize($item['product_sku']) ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center"><?= $item['quantity'] ?></td>
                                        <td class="text-end"><?= formatPrice($item['unit_price']) ?></td>
                                        <td class="text-end fw-bold"><?= formatPrice($item['total_price']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Shipping Info -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white fw-bold"><i class="bi bi-truck me-2"></i>Shipping Address</div>
                    <div class="card-body small">
                        <strong><?= sanitize($order['shipping_first_name'] . ' ' . $order['shipping_last_name']) ?></strong><br>
                        <?= sanitize($order['shipping_address']) ?><br>
                        <?= sanitize($order['shipping_city']) ?>, <?= sanitize($order['shipping_country']) ?><br>
                        <i class="bi bi-telephone me-1"></i><?= sanitize($order['shipping_phone']) ?>
                    </div>
                </div>
            </div>

            <!-- Right Sidebar -->
            <div class="col-lg-4">
                <!-- Payment Summary -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-dark text-white fw-bold"><i class="bi bi-receipt me-2"></i>Payment Summary</div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2 small"><span>Subtotal</span><span><?= formatPrice($order['subtotal']) ?></span></div>
                        <?php if ($order['discount_amount'] > 0): ?>
                            <div class="d-flex justify-content-between mb-2 small text-success"><span>Discount</span><span>-<?= formatPrice($order['discount_amount']) ?></span></div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between mb-2 small"><span>Shipping</span><span><?= $order['shipping_amount'] > 0 ? formatPrice($order['shipping_amount']) : '<span class="text-success">Free</span>' ?></span></div>
                        <div class="d-flex justify-content-between mb-2 small"><span>Tax (VAT)</span><span><?= formatPrice($order['tax_amount']) ?></span></div>
                        <hr>
                        <div class="d-flex justify-content-between"><span class="fw-bold fs-5">Total</span><span class="fw-bold fs-5 text-success"><?= formatPrice($order['total_amount']) ?></span></div>
                        <div class="mt-3">
                            <strong>Method:</strong> <?= sanitize(ucwords(str_replace('_', ' ', $order['payment_method'] ?? 'N/A'))) ?><br>
                            <strong>Status:</strong> <?= paymentStatusBadge($order['payment_status']) ?>
                        </div>
                    </div>
                </div>

                <!-- Receipt Upload (for bank transfers) -->
                <?php if (str_contains($order['payment_method'] ?? '', 'bank_transfer') && $order['payment_status'] !== 'paid'): ?>
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-warning text-dark fw-bold">
                            <i class="bi bi-upload me-2"></i>Upload Bank Receipt
                        </div>
                        <div class="card-body">
                            <?php if ($order['receipt_image']): ?>
                                <div class="mb-3 text-center">
                                    <img src="<?= url($order['receipt_image']) ?>" class="img-fluid rounded shadow-sm" style="max-height:200px;">
                                    <p class="small text-success mt-2"><i class="bi bi-check-circle me-1"></i>Receipt uploaded — pending verification</p>
                                </div>
                            <?php endif; ?>
                            <form method="POST" enctype="multipart/form-data">
                                <?= csrfField() ?>
                                <div class="mb-3">
                                    <input type="file" class="form-control form-control-sm" name="receipt" accept="image/*" required>
                                    <small class="text-muted">Upload a screenshot of your bank transfer receipt (JPG/PNG, max 5MB)</small>
                                </div>
                                <button class="btn btn-warning btn-sm w-100 fw-bold">
                                    <i class="bi bi-cloud-upload me-1"></i> Upload Receipt
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include INCLUDES_PATH . 'footer.php'; ?>
</body>
</html>