<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
requireLogin();

$userModel = new User();
$user = $userModel->findById(currentUserId());
$errors = [];
$section = $_GET['section'] ?? 'profile';

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken()) {
        $errors[] = 'Invalid security token.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'update_profile') {
            try {
                $userModel->updateProfile(currentUserId(), [
                    'first_name' => $_POST['first_name'] ?? '',
                    'last_name'  => $_POST['last_name'] ?? '',
                    'phone'      => $_POST['phone'] ?? '',
                    'address'    => $_POST['address'] ?? '',
                    'city'       => $_POST['city'] ?? '',
                    'state'      => $_POST['state'] ?? '',
                    'zip_code'   => $_POST['zip_code'] ?? '',
                    'country'    => $_POST['country'] ?? 'Ethiopia',
                ]);
                setFlash('success', 'Profile updated successfully!');
                redirect('user/profile.php');
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }

        if ($action === 'change_password') {
            try {
                $userModel->changePassword(
                    currentUserId(),
                    $_POST['current_password'] ?? '',
                    $_POST['new_password'] ?? ''
                );
                setFlash('success', 'Password changed successfully!');
                redirect('user/profile.php?section=password');
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
                $section = 'password';
            }
        }

        if ($action === 'update_avatar' && isset($_FILES['avatar'])) {
            $path = uploadImage($_FILES['avatar'], AVATAR_IMG_PATH, 'avatar_');
            if ($path) {
                $userModel->updateAvatar(currentUserId(), $path);
                setFlash('success', 'Avatar updated!');
                redirect('user/profile.php');
            } else {
                $errors[] = 'Failed to upload avatar.';
            }
        }
    }
}

$user = $userModel->findById(currentUserId()); // Refresh
$pageTitle = 'Profile Settings — ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <?php include INCLUDES_PATH . 'navbar.php'; ?>
    <div class="container mt-3"><?= renderFlash() ?></div>

    <div class="container py-4">
        <h4 class="fw-bold mb-4"><i class="bi bi-person-gear me-2"></i>Profile Settings</h4>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger"><?php foreach ($errors as $e): echo sanitize($e) . '<br>'; endforeach; ?></div>
        <?php endif; ?>

        <!-- Tabs -->
        <ul class="nav nav-tabs mb-4">
            <li class="nav-item">
                <a class="nav-link <?= $section === 'profile' ? 'active' : '' ?>" href="?section=profile">
                    <i class="bi bi-person me-1"></i>Profile
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $section === 'password' ? 'active' : '' ?>" href="?section=password">
                    <i class="bi bi-lock me-1"></i>Password
                </a>
            </li>
        </ul>

        <?php if ($section === 'profile'): ?>
            <!-- Profile Form -->
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="update_profile">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">First Name *</label>
                                <input type="text" class="form-control" name="first_name" value="<?= sanitize($user['first_name']) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Last Name *</label>
                                <input type="text" class="form-control" name="last_name" value="<?= sanitize($user['last_name']) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Email (read-only)</label>
                                <input type="email" class="form-control bg-light" value="<?= sanitize($user['email']) ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Phone</label>
                                <input type="tel" class="form-control" name="phone" value="<?= sanitize($user['phone'] ?? '') ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Address</label>
                                <textarea class="form-control" name="address" rows="2"><?= sanitize($user['address'] ?? '') ?></textarea>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">City</label>
                                <input type="text" class="form-control" name="city" value="<?= sanitize($user['city'] ?? '') ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">State</label>
                                <input type="text" class="form-control" name="state" value="<?= sanitize($user['state'] ?? '') ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Country</label>
                                <select class="form-select" name="country">
                                    <option value="Ethiopia" <?= ($user['country'] ?? '') === 'Ethiopia' ? 'selected' : '' ?>>Ethiopia</option>
                                    <option value="Kenya" <?= ($user['country'] ?? '') === 'Kenya' ? 'selected' : '' ?>>Kenya</option>
                                    <option value="Djibouti" <?= ($user['country'] ?? '') === 'Djibouti' ? 'selected' : '' ?>>Djibouti</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-success px-4" style="background:#2d6a4f;border-color:#2d6a4f;">
                                    <i class="bi bi-check-lg me-1"></i>Save Changes
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        <?php elseif ($section === 'password'): ?>
            <!-- Change Password Form -->
            <div class="card border-0 shadow-sm" style="max-width:500px;">
                <div class="card-body">
                    <form method="POST">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="change_password">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Current Password *</label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">New Password *</label>
                            <input type="password" class="form-control" name="new_password" required minlength="8">
                            <small class="text-muted">Min 8 chars, uppercase, lowercase, digit</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Confirm New Password *</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        <button class="btn btn-success" style="background:#2d6a4f;border-color:#2d6a4f;">
                            <i class="bi bi-lock me-1"></i>Update Password
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php include INCLUDES_PATH . 'footer.php'; ?>
</body>
</html>