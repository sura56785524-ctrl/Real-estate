/**
 * ================================================================
 * Cart JavaScript — AJAX Cart Operations
 * Handles add-to-cart, quantity updates, and real-time UI updates
 * ================================================================
 */

// ── Get Base URL from meta or default ──────────────────────────
const BASE_URL = document.querySelector('meta[name="base-url"]')?.content || '/import-export-stationery/';

/**
 * Add a product to the cart via AJAX.
 */
function addToCart(productId, quantity = 1, redirectToCheckout = false) {
    fetch(BASE_URL + 'cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `action=add&product_id=${productId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update cart badge
            updateCartBadge(data.cart_count);

            // Show success toast
            showToast(data.message, 'success');

            // Redirect to checkout if "Buy Now"
            if (redirectToCheckout) {
                window.location.href = BASE_URL + 'checkout.php';
            }
        } else {
            showToast(data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Cart Error:', error);
        showToast('Something went wrong. Please try again.', 'danger');
    });
}

/**
 * Update cart quantity via AJAX.
 */
function updateCartItem(productId, quantity) {
    fetch(BASE_URL + 'cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `action=update&product_id=${productId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.summary) {
            updateCartUI(data.summary);
            updateCartBadge(data.summary.item_count);
        } else {
            showToast(data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Update Error:', error);
    });
}

/**
 * Remove an item from the cart via AJAX.
 */
function removeCartItem(productId) {
    fetch(BASE_URL + 'cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `action=remove&product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Remove row from table
            const row = document.querySelector(`tr[data-product-id="${productId}"]`);
            if (row) {
                row.style.transition = 'opacity 0.3s';
                row.style.opacity = '0';
                setTimeout(() => {
                    row.remove();
                    // Check if cart is now empty
                    if (data.summary.item_count === 0) {
                        location.reload();
                    }
                }, 300);
            }

            if (data.summary) {
                updateCartUI(data.summary);
            }
            updateCartBadge(data.summary?.item_count || 0);
            showToast(data.message, 'success');
        }
    })
    .catch(error => {
        console.error('Remove Error:', error);
    });
}

/**
 * Update the cart badge in the navbar.
 */
function updateCartBadge(count) {
    const badge = document.getElementById('cartBadge');
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline-block' : 'none';
    }
}

/**
 * Update cart summary UI after AJAX changes.
 */
function updateCartUI(summary) {
    const formatPrice = (amount) => 'Br ' + parseFloat(amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    const el = (id) => document.getElementById(id);

    if (el('summarySubtotal'))  el('summarySubtotal').textContent  = formatPrice(summary.subtotal);
    if (el('summaryTax'))       el('summaryTax').textContent       = formatPrice(summary.tax_amount);
    if (el('summaryTotal'))     el('summaryTotal').textContent     = formatPrice(summary.grand_total);
    if (el('summaryItemCount')) el('summaryItemCount').textContent = summary.item_count;

    if (el('summaryShipping')) {
        el('summaryShipping').innerHTML = summary.free_shipping
            ? '<span class="text-success">Free</span>'
            : formatPrice(summary.shipping);
    }
}

/**
 * Show a Bootstrap toast notification.
 */
function showToast(message, type = 'success') {
    // Remove existing toasts
    document.querySelectorAll('.cart-toast').forEach(t => t.remove());

    const icons = {
        success: 'bi-check-circle-fill',
        danger: 'bi-exclamation-triangle-fill',
        warning: 'bi-exclamation-circle-fill',
        info: 'bi-info-circle-fill'
    };

    const toast = document.createElement('div');
    toast.className = 'cart-toast position-fixed top-0 end-0 m-3 alert alert-' + type + ' shadow-lg d-flex align-items-center gap-2';
    toast.style.cssText = 'z-index:9999; animation: slideIn 0.3s ease; min-width:280px; border-radius:10px;';
    toast.innerHTML = `
        <i class="bi ${icons[type] || icons.info} fs-5"></i>
        <span>${message}</span>
        <button type="button" class="btn-close btn-close-sm ms-auto" onclick="this.parentElement.remove()"></button>
    `;

    document.body.appendChild(toast);

    // Auto-remove after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ── Event Listeners ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

    // Add to Cart buttons (catalog / product cards)
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            const originalHtml = this.innerHTML;

            this.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Adding...';
            this.disabled = true;

            addToCart(productId, 1);

            setTimeout(() => {
                this.innerHTML = '<i class="bi bi-check-circle me-1"></i> Added!';
                setTimeout(() => {
                    this.innerHTML = originalHtml;
                    this.disabled = false;
                }, 1500);
            }, 500);
        });
    });

    // Cart page: Quantity +/- buttons
    document.querySelectorAll('.cart-qty-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const input = document.querySelector(`.cart-qty-input[data-product-id="${productId}"]`);
            let qty = parseInt(input.value) || 1;
            const max = parseInt(input.max) || 999;

            if (this.dataset.action === 'increase') {
                qty = Math.min(qty + 1, max);
            } else {
                qty = Math.max(qty - 1, 1);
            }

            input.value = qty;
            updateCartItem(productId, qty);
        });
    });

    // Cart page: Quantity input change
    document.querySelectorAll('.cart-qty-input').forEach(input => {
        input.addEventListener('change', function() {
            const productId = this.dataset.productId;
            let qty = Math.max(1, Math.min(parseInt(this.value) || 1, parseInt(this.max) || 999));
            this.value = qty;
            updateCartItem(productId, qty);
        });
    });

    // Cart page: Remove buttons
    document.querySelectorAll('.cart-remove-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Remove this item from your cart?')) {
                removeCartItem(this.dataset.productId);
            }
        });
    });
});

// ── CSS Animation ──────────────────────────────────────────────
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    .product-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important; }
    .product-name:hover { color: #2d6a4f !important; }
    .category-card:hover { transform: translateY(-5px); }
`;
document.head.appendChild(style);