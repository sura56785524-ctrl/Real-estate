/**
 * ================================================================
 * Main JavaScript — Global UI Functionality
 * Back-to-top, scroll effects, tooltips, etc.
 * ================================================================
 */

document.addEventListener('DOMContentLoaded', function() {

    // ── Back to Top Button ─────────────────────────────────────
    const backToTopBtn = document.getElementById('backToTop');
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            backToTopBtn.style.display = window.scrollY > 400 ? 'block' : 'none';
        });
    }

    // ── Initialize Bootstrap Tooltips ──────────────────────────
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltipTriggerList.forEach(el => new bootstrap.Tooltip(el));

    // ── Navbar Scroll Shadow ───────────────────────────────────
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('shadow');
            } else {
                navbar.classList.remove('shadow');
            }
        });
    }

    // ── Auto-dismiss alerts after 5 seconds ────────────────────
    document.querySelectorAll('.alert-dismissible').forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 5000);
    });

    // ── Lazy Image Loading ─────────────────────────────────────
    if ('IntersectionObserver' in window) {
        const lazyImages = document.querySelectorAll('img[data-src]');
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    observer.unobserve(img);
                }
            });
        });
        lazyImages.forEach(img => imageObserver.observe(img));
    }

    // ── Form Validation Visual Feedback ────────────────────────
    document.querySelectorAll('form[novalidate]').forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // ── Number Input: Prevent negative values ──────────────────
    document.querySelectorAll('input[type="number"]').forEach(input => {
        input.addEventListener('input', function() {
            if (this.min && parseInt(this.value) < parseInt(this.min)) {
                this.value = this.min;
            }
        });
    });

    console.log('%c🖊️ Import & Export Full Pack Stationery', 'color:#2d6a4f; font-size:16px; font-weight:bold;');
    console.log('%cBuilt with PHP 8, MySQL, Bootstrap 5', 'color:#6c757d;');
});